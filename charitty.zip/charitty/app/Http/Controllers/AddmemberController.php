<?php

namespace App\Http\Controllers;

use App\Addmember;
use DB;
use App\Register;
use Illuminate\Http\Request;

class AddmemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $memimg=$request->img->getClientOriginalName();
        $request->img->storeAs('public/member',$memimg);

        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;

        $name=$request->input('name');
        $dob=$request->input('dob');
        $gender=$request->input('gender');
        $adharno=$request->input('adharno');
        $yexpense=$request->input('yexpense');
        $spon_stat=0;
        $couse_id=$request->input('couse_id');
        $iname=$request->input('iname');
        if($couse_id==0)
        {
            $course=$request->input('cou');
            $check=DB::table('course')->where(['course'=>$course])->get();
            if(count($check)==0)
            {
                $user=DB::insert('insert into course (course) values (?)', [$course]);
                $couse_id=DB::table('course')->max('couse_id');
            }
        }
        else
        {
            $couse_id=$couse_id;
        }
        $data=new Addmember(['name'=>$name,'id'=>$user,'dob'=>$dob,'gender'=>$gender,'adharno'=>$adharno,'yexpense'=>$yexpense,'image'=>$memimg,'spon_stat'=>$spon_stat,'couse_id'=>$couse_id,'iname'=>$iname]);
       //return $data;
         $data->save();
        return back() ->with('success','Add Member successfully!');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Addmember  $addmember
     * @return \Illuminate\Http\Response
     */
    public function show(Addmember $addmember)
    {
        //
    }
    public function addmem(Request $request)
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        
        $memimg=$request->img->getClientOriginalName();
        $request->img->storeAs('public/member',$memimg);

      
        $name=$request->input('name');
        $dob=$request->input('dob');
        $gender=$request->input('gender');
        $adharno=$request->input('adharno');
        $yexpense=$request->input('yexpense');
        $spon_stat=0;
        $data=new Addmember(['name'=>$name,'id'=>$user,'dob'=>$dob,'gender'=>$gender,'adharno'=>$adharno,'yexpense'=>$yexpense,'image'=>$memimg,'spon_stat'=>$spon_stat]);
   //return $data;
       
         $data->save();
        return back() ->with('success','Add Member successfully!');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Addmember  $addmember
     * @return \Illuminate\Http\Response
     */
    public function edit(Addmember $addmember)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Addmember  $addmember
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Addmember $addmember)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Addmember  $addmember
     * @return \Illuminate\Http\Response
     */
    public function destroy(Addmember $addmember)
    {
        //
    }
}
