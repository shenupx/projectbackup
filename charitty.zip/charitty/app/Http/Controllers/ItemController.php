<?php

namespace App\Http\Controllers;

use App\Item;
use Illuminate\Http\Request;
use DB;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $item=$request->input('item');
        $iqty=$request->input('iqty');
        if($item==0)
        {
            $nitem=$request->input('nite');
            $items=new item(['item'=>$nitem,'iqty'=>$iqty]);
            $items->save();
            return back()->with('success','Item add successfully!');
        
        }
        else
        {
            $item=$item;
            //$check=DB::table('items')->where(['item_id'=>$item])-get();
            $check = item::where('item_id',$item)->first();
            $old=$check->iqty;
            $newqty=$old+$iqty;
            $items=DB::table('items')
            ->where('item_id', $item)
            ->update(['iqty' => $newqty]);
            //$items=new item(['item'=>$item,'iqty'=>$newqty]);
           // $items->save();
            return back()->with('success','Item add successfully!');
        }
        

        // $items=new Item(['item'=>$request->input('item'),
        // 'iqty'=>$request->input('iqty')]); 
        //return $items;   
       
        //return redirect()->back() ->with('alert','Successfully Added');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function show(Item $item)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function edit(Item $item)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Item $item)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Item  $item
     * @return \Illuminate\Http\Response
     */
    public function destroy(Item $item)
    {
        //
    }
    public function itemgrant($request_id)
    {
        return $request_id;
    }
}
