<?php

namespace App\Http\Controllers;

use App\Donation;
use App\Register;
use Illuminate\Http\Request;
use DB;

class DonationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $email=session()->get('email');
        $donation=new Donation(['email'=>$email,
        'item_id'=>$request->input('item_id'),
        'specitem'=>$request->input('specific'),
        'quantity'=>$request->input('quatity'),
        'id'=>$request->input('organization'),
        'district_id'=>$request->input('district_id'),

        ]);      
       $donation->save(); 
         return back()->with('success','Your Donation Recoded!');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Donation  $donation
     * @return \Illuminate\Http\Response
     */
    public function show(Donation $donation)
    {
         $donation=DB::table('donations')
        ->join('items','donations.item_id','=','items.item_id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->select('donations.*','items.item','tbl_district.district_name')
        ->get();
         $donation1=DB::table('donations')->get();
         foreach($donation1 as $don)
         {
          $email=$don->email;
         }
          $check = Register::where('email',$email)->first();
           $name=$check->name;
        return view('admin.donationview',['donation'=>$donation])->with('name',$name);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Donation  $donation
     * @return \Illuminate\Http\Response
     */
    public function edit(Donation $donation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Donation  $donation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Donation $donation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Donation  $donation
     * @return \Illuminate\Http\Response
     */
    public function destroy(Donation $donation)
    {
        //
    }
    public function donationdetail($donation_id)
    {
        $donid=$donation_id;
        $donation=DB::table('donations')
        ->join('items','donations.item_id','=','items.item_id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->select('donations.*','items.item','tbl_district.district_name','tbl_district.district_id')
        ->where('donations.donation_id','=',$donid)
        ->get();
        $donation1=DB::table('donations')->get();
         foreach($donation1 as $don)
         {
          $email=$don->email;
         }
          $check = Register::where('email',$email)->first();
           $name=$check->name;
        return view('admin.donationfdetail',['donation'=>$donation])->with('name',$name);
         
    }
    public function viewvolunteer( $donation_id)
    {
        
        // $donid=$request->input('id');
        // return $donid;
         $donid= $donation_id;
        $donate=DB::table('donations')->where('donations.donation_id','=',$donid)->get();
        foreach($donate as $donate)
        {
             $disid=$donate->district_id;
        }
          $vol=DB::table('registers')
        ->where('registers.district_id','=',$disid)
        ->where('registers.type','=',2)
        ->get();
       $voluntee=$vol;
       foreach ($voluntee as $voluntee)
       {
           $id=$voluntee->id;
           $check=DB::table('tbl_taskrequests')->where('tbl_taskrequests.donation_id','=',$donid)
           ->where('tbl_taskrequests.id','=',$id)->get();
            if(count($voluntee) == 0)
            {
                return back()->with('warning','Sorry No Volunteers Found in this district');
            }
            else
            {
                if(count($check) == 0)
                {
                   
                    return view('admin.assignjob',['voluntee'=>$vol])->with('donid',$donid);
                }
                else
                {
                    return back()->with('warning','request already send') ;
                }
            }
        }

    }


}
