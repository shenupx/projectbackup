<?php

namespace App\Http\Controllers;

use App\Payment;
use App\Event;
use Illuminate\Http\Request;
use App\Sponsorship;
use DB;
use App\Addmember;
use App\Bank;
class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $sess=session()->get('email');
        $email=$sess;
        
        // get values from blade
        $cardtype= $request->get('ctype');
        
        $coname= $request->get('name');
        $cnumber= $request->get('cnumber');
        
        $cvv= $request->get('cvv');
        $emonth= $request->get('emonth');
        $eyear= $request->get('eyear');
        $amount=$request->get('amount');
        $eid=$request->get('eid');
//get data from database
        $b=DB::table('banks')
        ->select('banks.*')
        ->where('card_id' ,'=', $cardtype)
        ->where('coname', '=', $coname)
        ->where('cardnumber', '=', $cnumber)
         ->where('cvv', '=', $cvv)
         ->where('mnth_id', '=', $emonth)
        ->where('yid', '=', $eyear)
        ->get();
        //return $b;
        //check data in db
        if(count($b) == 0){
            return back()->with('error','incorrect');;
       }
       else{

        $amount1=DB::select('select balance from banks where cardnumber = ?',[$cnumber]);
        $amount2=DB::select('select balance from banks where cardnumber = ?',['0000000000']);
        $amount3=DB::select('select damount from events where event_id = ?',[$eid]);



        //return $amount1;
        if($amount1[0]->balance > $amount){
            $rem=$amount1[0]->balance-$amount;

        $payment=new Payment([
            'email'=>$email,
            'event_id'=>$request->get('eid'),
            'namount'=>$amount,
            
            
        ]);
    

        $payment->save();
        $balance=$amount1[0]->balance-$amount;
        $adminbalance=$amount2[0]->balance+$amount;
        $eventbalance=$amount3[0]->damount+$amount;
        DB::update('update banks set balance = ? where cardnumber = ?',[$balance,$cnumber]);
        DB::update('update banks set balance = ? where cardnumber = ?',[$adminbalance,'0000000000']);
        DB::update('update events set damount = ? where event_id = ?',[$eventbalance,$eid]);
        if($eventbalance)
        return redirect('/donfe')->with('success','Donated');
        }
        else{
            return redirect()->back()->with('error','no balance');

        }
       }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(Payment $payment)
    {
       

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(Payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Payment $payment)
    {
        //
    }
    public function sponsorpayment(Request $request)
    {
         
        $sess=session()->get('email');
        $email=$sess;
        return $sid= $request->get('sponsid');
         $sponfee=$request->get('amountnew');
        // get values from blade
        $cardtype= $request->get('ctype');
        $coname= $request->get('name');
        $cnumber= $request->get('cnumber');
        
        $cvv= $request->get('cvv');
        $emonth= $request->get('emonth');
        $eyear= $request->get('eyear');
        $eid=$request->get('eid');
//get data from database
        $b=DB::table('banks')
        ->select('banks.*')
        ->where('card_id' ,'=', $cardtype)
        ->where('coname', '=', $coname)
        ->where('cardnumber', '=', $cnumber)
         ->where('cvv', '=', $cvv)
         ->where('mnth_id', '=', $emonth)
        ->where('yid', '=', $eyear)
        ->get();
       
        if(count($b) == 0){
            return back()->with('error','incorrect');;
       }
       else{
           
          $check = DB::table('sponsorships')->where('spons_id',$sid)->first();
          $mem=$check->mem_id;
        $add=Addmember::where('mem_id',$mem)->first(); 
        $id=$add->id;
        $acc=Bank::where('id',$id)->first();
        $accno=$acc->acnumber;
       
        $amount1=DB::select('select balance from banks where cardnumber = ?',[$cnumber]);
         $amount2=DB::select('select balance from banks where acnumber = ?',[$accno]);

        //return $amount1;
        if($amount1[0]->balance > $sponfee){
            
         $rem=$amount1[0]->balance-$sponfee;

            // $payment=new Payment([
            // 'email'=>$email,
            // 'event_id'=>$request->get('eid'),
            // 'namount'=>$amount]);
            // $payment->save();

             $adminbalance=$amount2[0]->balance+$sponfee;
            DB::update('update banks set balance = ? where cardnumber = ?',[$rem,$cnumber]);
            DB::update('update banks set balance = ? where acnumber = ?',[$adminbalance,$accno]);
            DB::update('update addmembers set spon_stat = ? where mem_id = ?',[1,$mem]);
            return view('donor.donhome')->with('success','Sponsored Successfully');
        }   
        else
        {
            return redirect()->back()->with('error','no balance');

        }
       }
    }
}
