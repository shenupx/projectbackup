<?php

namespace App\Http\Controllers;

use App\Benreg;
use Illuminate\Http\Request;

class BenregController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $imgPath="";
        if($request->hasFile('cero')&&$request->file('cero')->isValid()){
         $image= $request->file('cero');
         $imgPath=$image->store('/bcertificates/');
        }
         $imgPath2="";
        if($request->hasFile('cert')&&$request->file('cert')->isValid()){
         $image2= $request->file('cert');
         $imgPath2=$image2->store('/bcertificates/');
        }
        $imgPath1="";
        if($request->hasFile('certt')&&$request->file('certt')->isValid()){
         $image1= $request->file('certt');
         $imgPath1=$image1->store('/bcertificates/');
        }

        $Benreg=new Benreg(['id'=>$request->input('id'),
        'sdate'=>$request->input('sdate'),
        'owner'=>$request->input('owner'),
        'nop'=>$request->input('nop'),
        'btype'=>$request->input('btype'),
        'place'=>$request->input('place'),
        'cero'=>$imgPath,
        'cert'=>$imgPath2,
        'certt'=>$imgPath1
        ]);
        $Benreg->save();
        return redirect('/log_in');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Benreg  $benreg
     * @return \Illuminate\Http\Response
     */
    public function show(Benreg $benreg)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Benreg  $benreg
     * @return \Illuminate\Http\Response
     */
    public function edit(Benreg $benreg)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Benreg  $benreg
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Benreg $benreg)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Benreg  $benreg
     * @return \Illuminate\Http\Response
     */
    public function destroy(Benreg $benreg)
    {
        //
    }
}
