<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Register;
use DB;
use Carbon\Carbon;
use App\Addscholar;
use App\Addmember;


class PathController extends Controller
{
    public function register()
    {
     $state=DB::table('tbl_state')->get();
     return view('authenti.registration',['data'=>$state]);
        //return view('authenti.registration');
    }
 public function log_in()
    {
         return view('authenti.login');
    } public function donprofile()
    {
         return view('donor.donprofile');
    }
//  public function adbenview()
// {
//      return view('admin.admin_ben_view');
// }
     public function benprofile()
     {
          return view('ben.benprofile');
     }
     public function benregi()
     {
          return view('ben.benreg');
     }
     public function commonregi()
     {
          //$data['rid']=$regid;
          return view('authenti.comreg');
     }
     public function beneditp()
     {
          //$data['rid']=$regid;
          return view('ben.ben_editp');
     }   
     public function adminh()
     {
          return view('admin.adminhome');
     }
     public function adprofile()
     {
          $sess=session()->get('email');
          //return $sess;
          $user=DB::table('registers')
          ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
          ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
          ->select('registers.*','tbl_district.district_name','tbl_state.state_name')
          ->where('registers.email', '=', $sess)
          ->get();
          //return $user;
  
         // return view('donor.donprofile',compact('user')); 
           return view('admin.adprofile',['data'=>$user]);
     }
     public function volprofile()
     {

          return view('volunte.volprofile');
     }
     public function adscholar()
     {
          $course=DB::table('course')->get();
          return view('admin.adscholar',['course'=>$course]);
     }
     public function adchpass()
     {
          return view('admin.adchangepass');
     }
     public function donchangepass()
     {
          return view('donor.donchangepass');
     }
     public function volchangepass()
     {
          return view('volunte.volchangepass');
     }
     public function orgchangepass()
     {
          return view('ben.benchangepass');
     }
     public function benaddmem()
     {
          $sess=session()->get('email');
          $a = Register::where('email', $sess)->get();
          $course=DB::table('course')->get();
          //$id=$a->id;
          foreach($a as $obje)
          {
               if($obje->btype=='orphanage')
               {
                    
                    return view('ben.benaddstud',['course'=>$course]);
               }
               else
               {
                    return view('ben.benaddmem');
               }
          }
     }
     public function scholarview()
     {
          $scholar=DB::table('addscholars')
          ->join('course','course.couse_id','=','addscholars.couse_id')
          ->select('addscholars.*','course.course')
          ->get();
          // $scholar=DB::table('addscholars')->get();
          return view('ben.scholarview',['data'=>$scholar]);
          
     }
     public function requestneeds()
     {
          $item=DB::table('items')->get();
          $days=DB::table('days')->get();
          // return view('authenti.registration',['data'=>$state]);
          return view('ben.request',['item'=>$item,'data'=>$days]);
     }
     public function additem()
     {
          $item=DB::table('items')->get();
          return view('admin.add_item',['item'=>$item]);
     }
     public function requestview()
     {
          $reques=DB::table('requestneeds')
          ->join('registers','requestneeds.id','=','registers.id')
          ->join('items','requestneeds.item_id','=','items.item_id')
          ->join('days','requestneeds.day_id','=','days.day_id')
          ->select('requestneeds.*','registers.name','items.item','days.days')
          ->get();
          return view('admin.requestview',['data'=>$reques]);
     }
     public function addevent()
     {
          $tyevent=DB::table('type_events')->get();
          return view('admin.add_event',['type'=>$tyevent]);
     }
     public function viewevent()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->where('events.damount','<','events.amount')
          ->get();
          return view('admin.adview_event',['event'=>$event]);
     }
     public function donviewevent()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
           ->select('events.*','type_events.type')
           ->whereDate('edate', '<', Carbon::now()->toDateString())  
          ->get();          
          return view('donor.view_events',['event'=>$event]);
     }
     public function volviewevent()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->whereDate('edate', '>=', Carbon::now()->toDateString())
          ->get();
          return view('volunte.volview_events',['event'=>$event]);
     }
     public function volnonfund()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->where('events.tye_id', '=', 2 )
          ->whereDate('edate', '>=', Carbon::now()->toDateString())

          ->get();
          //return $event;
          return view('volunte.volnonfund',['event'=>$event]);
     }
     public function volfund()
     {
            $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->where('events.tye_id', '=', 1)
          ->whereDate('edate', '>=', Carbon::now()->toDateString())
          ->get(); 
          //return $event;
          return view('volunte.volfund',['event'=>$event]);
     }
     public function report()
     {
          $state=DB::table('tbl_state')->get(); 
          return view('volunte.volreport',['data'=>$state]);
     }
     public function donrequestview()
     {
          $reques=DB::table('requestneeds')
          ->join('registers','requestneeds.id','=','registers.id')
          ->join('items','requestneeds.item_id','=','items.item_id')
          ->join('days','requestneeds.day_id','=','days.day_id')
          ->select('requestneeds.*','registers.name','items.item','days.days')
          ->get();
          return view('donor.view_requests',['data'=>$reques]);
     }
     public function paypath($event_id)
     {
         //return $event_id;
          $eid=$event_id;
          $card=DB::table('tbl_cardtype')->get();
          $month=DB::table('tbl_month')->get();
          $year=DB::table('tbl_year')->get();
          return view('donor.payment',['card'=>$card,'month'=>$month,'year'=>$year])->with('eid',$eid);
     }
     public function account()
     {
          return view('ben.account');
     }
     public function userviewevent()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->get();
          return view('viewevent',['event'=>$event]);
     }
     public function volrequestview()
     {
          $reques=DB::table('requestneeds')
          ->join('registers','requestneeds.id','=','registers.id')
          ->join('items','requestneeds.item_id','=','items.item_id')
          ->join('days','requestneeds.day_id','=','days.day_id')
          ->select('requestneeds.*','registers.name','items.item','days.days')
          ->get();
          return view('volunte.volreqview',['data'=>$reques]);
     }
     public function benreqstat()
     {
          $sess=session()->get('email');
          $check = Register::where('email',$sess)->first();
          $user=$check->id;
          $reques=DB::table('requestneeds')
          ->join('registers','requestneeds.id','=','registers.id')
          ->join('items','requestneeds.item_id','=','items.item_id')
          ->join('days','requestneeds.day_id','=','days.day_id')
          ->select('requestneeds.*','registers.name','items.item','days.days')
          ->where('requestneeds.id','=',$user )
          ->get();
          return view('ben.viewreqtstat',['data'=>$reques]);
     }
     public function donfundevet()
     {
          $event=DB::table('events')
          ->join('type_events','events.tye_id','=','type_events.tye_id')
          ->select('events.*','type_events.type')
          ->where('events.tye_id', '=', 1 ) 
          ->whereDate('edate', '>=', Carbon::now()->toDateString())
          ->get();
         // return $event;
          return view('donor.donfevent',['event'=>$event]);
     }
     public function mydonations()
     {
          $sess=session()->get('email');
          $check = Register::where('email',$sess)->first();
          $user=$check->id;
          $reques=DB::table('payments')
          ->join('events','payments.event_id','=','events.event_id')
          ->select('payments.*','events.*')
          ->where('payments.email','=',$sess )
          ->get();
          return view('donor.mydonations',['mydon'=>$reques]);
     }
     public function viewmymem()
     {
          $sess=session()->get('email');
          $check = Register::where('email',$sess)->first();
          $user=$check->id;
          $reques=DB::table('addmembers')
          ->where('id','=',$user)
          ->get();
          return view('ben.viewmember',['data'=>$reques]);
     }
     public function scholarapply($scheme_id)
     {
          $sid=$scheme_id;
          $sess=session()->get('email');
          $check = Register::where('email',$sess)->first();
          $user=$check->id;
          $reques=DB::table('addmembers')
          ->where('id','=',$user)
          ->get();
          return view('ben.scholaraply',['mem'=>$reques])->with('sid',$sid);
     }
     public function donation()
     {
          $item=DB::table('items')->get();
          $names=DB::table('registers')
          ->where('registers.type','=',3)
          ->get();
          $dist=DB::table('tbl_district')->get();
          return view('donor.donationform',['items'=>$item,'user'=>$names,'dist'=>$dist]);
     }
     public function donvieworphanages()
     {
          $names=DB::table('registers')
          ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
          ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
  
          ->where('registers.type','=',3 )
          ->where('registers.btype','=','orphanage')
          ->where('registers.status','=',1)
          ->get();
          return view('donor.orphanageview',['orphanages'=>$names]);
     }
     public function orphans($id)
     {
           $mems=DB::table('addmembers')
           ->join('course','addmembers.couse_id','=','course.couse_id')
          ->where('addmembers.id','=',3)
          ->select('addmembers.*','course.course')
          ->get();
          
          return view('donor.orphmem',['members'=>$mems]);
              
          
     }
     public function oldageview()
     {
          $names=DB::table('registers')
          ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
          ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
  
          ->where('registers.type','=',3 )
          ->where('registers.btype','=','oldhome')
          ->where('registers.status','=',1)
          ->get();
          return view('donor.oldageview',['orphanages'=>$names]);
     }
     public function oldageh($id)
     {
          $id=$id;
          $mems=DB::table('addmembers')
          ->where('addmembers.id','=',$id)
          ->get();
          
          return view('donor.oldmem',['members'=>$mems]);
     }

}//end class
