<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PathController extends Controller
{
    public function register()
    {
        return view('authenti.registration');
    }
 public function log_in()
    {
         return view('authenti.login');
    } public function donprofile()
    {
         return view('donor.donprofile');
    }
 public function adbenview()
{
     return view('admin.admin_ben_view');
}
public function benprofile()
{
     return view('ben.benprofile');
}
public function benregi()
{
     return view('ben.benreg');
}
public function commonregi()
{
     //$data['rid']=$regid;
     return view('authenti.comreg');
}
    

}
