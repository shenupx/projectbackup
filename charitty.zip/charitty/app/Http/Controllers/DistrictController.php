<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\state;
use App\district;

class DistrictController extends Controller
{
    public function index()
    {
    //    return $state=DB::table('tbl_state')->get();
    //     return view('/nregister',['data'=>$state]);
    }
    public function cityajax(Request $request)
    {
        // return $request->all(); 
        $id = $request->get('distID');
        $district=district::where("state_id", $id)->get();
        return $district;
    }
    public function city()
    {
        $district=district::all();
        return View::make('state',['district'=>$district]);
    }
}
