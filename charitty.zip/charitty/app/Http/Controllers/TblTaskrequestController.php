<?php

namespace App\Http\Controllers;

use App\tbl_taskrequest;
use Illuminate\Http\Request;
use App\Register;
use DB;

class TblTaskrequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id=$request->get('id');
        $donid=$request->get('donid');
        $task=new tbl_taskrequest(['id'=>$id,
        'donation_id'=>$donid,
        'reqstatus'=>1,
        'onduty'=>0
        ]);
        $task->save();
        $taskt=DB::table('tbl_taskrequests')
        ->join('registers','tbl_taskrequests.id','=','registers.id')
        ->join('donations','tbl_taskrequests.donation_id','=','donations.donation_id')
        ->get();
        
        return view('admin.viewreqstat',['taskt'=>$taskt])->with('success','Task Request Send Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\tbl_taskrequest  $tbl_taskrequest
     * @return \Illuminate\Http\Response
     */
    public function show(tbl_taskrequest $tbl_taskrequest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\tbl_taskrequest  $tbl_taskrequest
     * @return \Illuminate\Http\Response
     */
    public function edit(tbl_taskrequest $tbl_taskrequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\tbl_taskrequest  $tbl_taskrequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tbl_taskrequest $tbl_taskrequest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\tbl_taskrequest  $tbl_taskrequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(tbl_taskrequest $tbl_taskrequest)
    {
        //
    }
    public function viewstat()
    {
                $taskt=DB::table('tbl_taskrequests')
        ->join('registers','tbl_taskrequests.id','=','registers.id')
        ->join('donations','tbl_taskrequests.donation_id','=','donations.donation_id')
        ->get();
        
        return view('admin.viewreqstat',['taskt'=>$taskt]);
    }
    public function viewnewreq()
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        
        $donor=DB::table('tbl_taskrequests')
       ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
       ->join('registers','registers.email','=','donations.email')
       ->select('registers.name')
       ->where('tbl_taskrequests.id','=',$user)

        ->get();
        foreach($donor as $don){
                 $name=$don->name;

        }
         $myreq=DB::table('tbl_taskrequests')
        ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
        ->join('registers','registers.id','=','donations.id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->join('items','donations.item_id','=','items.item_id')
        ->select('registers.*','donations.*','tbl_district.district_name','items.item','tbl_taskrequests.*')
        ->where('tbl_taskrequests.id','=',$user)
        ->where('tbl_taskrequests.reqstatus','=',1)
                ->get();
        return view('volunte.newtask',['myreq'=>$myreq])->with('donname',$name);


    }
    public function acceptreq($req_id)
    {
        $req= $req_id;
       
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
         DB::update('update tbl_taskrequests set accept = ?, onduty = ? where req_id = ?',[1,$user,$req]);
        
         $myreq=DB::table('tbl_taskrequests')
        ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
        ->get();
        foreach($myreq as $don)
        {
            $id=$don->donation_id;
            DB::update('update donations set volid = ? where donation_id = ?',[$user,$id]);
            DB::update('update tbl_taskrequests set reqstatus = ? where donation_id = ?',[0,$id]);

        }
        return back()->with('success','Accepted successfully');
    }
    public function rejectreq($req_id)
    {
        $req= $req_id;
        DB::update('update tbl_taskrequests set accept = ?where req_id = ?',[2,$req]);
        return back()->with('error','Rejected ');


    }
    public function viewacceptreq()
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        
        $donor=DB::table('tbl_taskrequests')
       ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
       ->join('registers','registers.email','=','donations.email')
       ->select('registers.name')
       ->where('tbl_taskrequests.id','=',$user)

        ->get();
        foreach($donor as $don){
                 $name=$don->name;

        }
         $myreq=DB::table('tbl_taskrequests')
        ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
        ->join('registers','registers.id','=','donations.id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->join('items','donations.item_id','=','items.item_id')
        ->select('registers.*','donations.*','tbl_district.district_name','items.item','tbl_taskrequests.*')
        ->where('tbl_taskrequests.onduty','=',$user)
        ->where('donations.deliverystat','=',0)
                ->get();
        return view('volunte.acceptedreq',['myreq'=>$myreq])->with('donname',$name);
    }
    public function viewmydonation()
    {
        $sess=session()->get('email');
         $myreq=DB::table('donations')
        ->join('registers','registers.id','=','donations.id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->join('items','donations.item_id','=','items.item_id')
        ->select('registers.*','donations.*','tbl_district.district_name','items.item')
        ->where('donations.email','=',$sess)
        ->get();
        return view('donor.mydonation',['data'=>$myreq]);

    }
    public function collected($donation_id)
    {
        $donid=$donation_id;
        DB::update('update donations set collectstat = ? where donation_id = ?',[1,$donid]);
        return back()->with('success','Collected successfully');

    }
    public function donationforme()
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;

        $donor=DB::table('tbl_taskrequests')
       ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
       ->join('registers','registers.email','=','donations.email')
       ->select('registers.name')
       ->where('tbl_taskrequests.id','=',$user)

        ->get();
        foreach($donor as $don){
                 $name=$don->name;

        }

        $mee=DB::table('donations')
        ->join('items','donations.item_id','=','items.item_id')
        ->join('registers','registers.id','=','donations.volid')
        ->select('registers.name as volname','donations.*','items.item')
       ->where('donations.id','=',$user)
        ->get();
        return view('ben.donationforme',['data'=>$mee])->with('donname',$mee);
    }
    public function dropping($donation_id)
    {
        $id= $donation_id;
        DB::update('update donations set deliverystat = ? where donation_id = ?',[1,$id]);
        return back()->with('success','Items Collected successfully');
    }
    public function completedtask()
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        
        $donor=DB::table('tbl_taskrequests')
       ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
       ->join('registers','registers.email','=','donations.email')
       ->select('registers.name')
       ->where('tbl_taskrequests.id','=',$user)

        ->get();
        foreach($donor as $don){
                 $name=$don->name;

        }
          $myreq=DB::table('tbl_taskrequests')
        ->join('donations','donations.donation_id','=','tbl_taskrequests.donation_id')
        ->join('registers','registers.id','=','donations.id')
        ->join('tbl_district','donations.district_id','=','tbl_district.district_id')
        ->join('items','donations.item_id','=','items.item_id')
        ->select('registers.*','donations.*','tbl_district.district_name','items.item','tbl_taskrequests.*')
        ->where('tbl_taskrequests.onduty','=',$user)
        ->where('donations.deliverystat','=',1)
         ->get();
        return view('volunte.completedtask',['myreq'=>$myreq])->with('donname',$name);
    }
}
