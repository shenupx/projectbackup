<?php

namespace App\Http\Controllers;

use App\Requestneeds;
use Illuminate\Http\Request;
use App\Register;
use DB;

class RequestneedsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        // $user=DB::table('registers')->where('email',$sess)->pluck('id');
        // $user = DB::table('registers')->where('reg_id', $reg_id)->first();
        // $name = DB::table('registers')->where('reg_id', $reg_id)->pluck('register_name');
        $requestneed=new requestneeds(['item_id'=>$request->input('item_id'),
        'specific'=>$request->input('specific'),
        'quatity'=>$request->input('quatity'),
        'day_id'=>$request->input('day_id'),
        'id'=>$user,
        'active'=>1        
        ]);       
       // return $requestneed;
        $requestneed->save();
        return back()->with('success','Request Send Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function show($request_id)
    {
        $sess=session()->get('email');
        $nid=$request_id;
        $req=DB::table('requestneeds')->where('request_id',$request_id)->get();
        foreach($req as $req)
        {
            $iid=$req->item_id;
            $qty=$req->quatity;
        }
        //return $nid;

        $item=DB::select('select iqty from items where item_id = ?',[$iid]);
        $itemqty=$item[0]->iqty;
        if($itemqty >$qty){
        $rem=$item[0]->iqty-$qty;
        DB::update('update items set iqty = ? where item_id ',[$rem,$iid]);
        DB::update('update requestneeds set active = ?, email = ? where request_id = ?',[0,$sess,$nid]);
        return back()->with('success','Request Granted successfully!');
        }
        else{
            return back()->with('error','Product Not Available!');

        }


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function edit(Requestneeds $requestneeds)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Requestneeds $requestneeds)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function destroy(Requestneeds $requestneeds)
    {
        //
    }
}
