<?php

namespace App\Http\Controllers;

use App\Sponsorship;
use App\Addmember;
use Illuminate\Http\Request;
use App\Register;
use DB;

class SponsorshipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $mem_id)
    {
        $sess=session()->get('email');
        $check = Register::where('email',$sess)->first();
        $user=$check->id;
        
         $memid=$mem_id;
        $sponoser=new Sponsorship(['id'=>$user,
        'mem_id'=>$memid]);    
        $sponoser->save();
        $sponsid=Sponsorship::max('id');

        $amount = Addmember::where('mem_id',$mem_id)->first();
        $donamount=$amount->yexpense;
        $card=DB::table('tbl_cardtype')->get();
        $month=DB::table('tbl_month')->get();
        $year=DB::table('tbl_year')->get();
         return view('donor.sponsorpayment',['card'=>$card,'month'=>$month,'year'=>$year])->with('amount',$donamount)
         ->with('sopons',$sponsid);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sponsorship  $sponsorship
     * @return \Illuminate\Http\Response
     */
    public function show(Sponsorship $sponsorship)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sponsorship  $sponsorship
     * @return \Illuminate\Http\Response
     */
    public function edit(Sponsorship $sponsorship)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sponsorship  $sponsorship
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sponsorship $sponsorship)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sponsorship  $sponsorship
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sponsorship $sponsorship)
    {
        //
    }
}
