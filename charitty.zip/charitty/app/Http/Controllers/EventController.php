<?php

namespace App\Http\Controllers;

use App\Event;
use Illuminate\Http\Request;
use DB;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $iconimg=$request->icon->getClientOriginalName();
        $request->icon->storeAs('public/event',$iconimg);

        $eventadd=new Event(['event_name'=>$request->input('ename'),
        'tye_id'=>$request->input('eventid'),
        'event_detail'=>$request->input('eventdetail'),
        'amount'=>$request->input('target'),
        'no_person'=>$request->input('novol'),
        'edate'=>$request->input('edate'),
        'etime'=>$request->input('etime'),
        'eplace'=>$request->input('eplace'),
        'icon'=>$iconimg,
        ]);       
        //return $eventadd;
        $eventadd->save();
        return back()->with('success','Event add successfully!');

    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(Event $event)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Event $event)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy(Event $event)
    {
        //
    }
    public function eventedit($event_id)
    {
        $id=$event_id;
        $tyevent=DB::table('type_events')->get();
        $newo=DB::table('events')
        ->join('type_events','events.tye_id','=','type_events.tye_id')
        ->select('events.*','type_events.type')
        ->where('event_id',$id)
        ->get();
       //return $newo;
     return view('admin.adevent_edit',['type'=>$tyevent,'newo'=>$newo]);
    }
    public function eventupdate(Request $request, $event_id)
    {
        $event=DB::table('events')->where('event_id',$event_id)->get();
        $event->event_name=$request->get('ename');
        $event->tye_id=$request->get('eventid');
        $event->amount=$request->get('target');
        $event->no_person=$request->get('novol');
        $event->edate=$request->get('edate');
        $event->event_detail=$request->get('eventdetail');
        //$event=Event::find($event_id);
        $event->save();
        return $event;
        //$rup->save();
    }
    public function eventdetail($event_id)
    {
        $id=$event_id;
        $tyevent=DB::table('type_events')->get();
        $newo=DB::table('events')
        ->join('type_events','events.tye_id','=','type_events.tye_id')
        ->select('events.*','type_events.type')
        ->where('event_id',$id)
        ->get();
       //return $newo;
     return view('admin.adevent_detailview',['newo'=>$newo]);
    }
}
