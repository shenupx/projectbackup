<?php

namespace App\Http\Controllers;

use App\ScholarApp;
use Illuminate\Http\Request;
use DB;

class ScholarAppController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $certificate=$request->cert->getClientOriginalName();
        $request->cert->storeAs('public/scholarcertificate',$certificate);

        $scholarapply=new ScholarApp(['mem_id'=>$request->input('mem_id'),
        'percent'=>$request->input('percentage'),
        'scheme_id'=>$request->input('sid'),
        'certificate'=>$certificate,
        'status'=>0
        ]);
      // return $scholarapply;       
         $scholarapply->save();
         return back()->with('success','Respose Recoded!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ScholarApp  $scholarApp
     * @return \Illuminate\Http\Response
     */
    public function show(ScholarApp $scholarApp)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ScholarApp  $scholarApp
     * @return \Illuminate\Http\Response
     */
    public function edit(ScholarApp $scholarApp)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ScholarApp  $scholarApp
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ScholarApp $scholarApp)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ScholarApp  $scholarApp
     * @return \Illuminate\Http\Response
     */
    public function destroy(ScholarApp $scholarApp)
    {
        //
    }
    public function viewschalrapp()
    {
        $schlarap=DB::table('addscholars')
          ->select('addscholars.*')
          ->get();
        //   return $schlarap;
        return view('admin.scholarapview',['apps'=>$schlarap]);
    }
    public function viewscholardetail($scheme_id)
    {
        $new= $scheme_id;
         $schlarap=DB::table('scholar_apps')
        ->join('addmembers','addmembers.mem_id','=','scholar_apps.mem_id')
         ->join('registers','registers.id','=','addmembers.id')
         ->select('scholar_apps.*','addmembers.*','registers.name as newname')
        ->where('scholar_apps.scheme_id','=',$new)
        ->get();
        // return $schlarap;
        return view('admin.applidetail',['newone'=>$schlarap])->with('sid',$new);
    }
    public function scholarselection($sid)
    {
        $sid=$sid;
        $scheme=DB::table('addscholars') ->where('addscholars.scheme_id','=',$sid)
        ->get();
        foreach($scheme as $scholar)
        {
            $percent=$scholar->percent;
            $course=$scholar->couse_id;
            $applicate=DB::table('scholar_apps')
            ->join('addmembers','addmembers.mem_id','=','scholar_apps.mem_id')
            ->join('registers','registers.id','=','addmembers.id')
            ->select('scholar_apps.*','addmembers.*','registers.name as newname')
            ->where('scholar_apps.percent','>=',$percent)
            -> where('addmembers.couse_id','=',$course)
            ->get();
            // return $applicate;
            return view('admin.selectedstud',['newone'=>$applicate]);
        }
     }
     public function grantscholor($sapp_id)
     {
          
         DB::update('update scholar_apps set status = ? where sapp_id = ?',[1,$sapp_id]);
         return back()->with('success','Scholarship granted success');


     }
}