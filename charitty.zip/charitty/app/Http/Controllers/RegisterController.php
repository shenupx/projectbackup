<?php

namespace App\Http\Controllers;

use App\Register;
use Crypt;
use Hash;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $regtister=Register::all(); //all is a facade it is already defined.
        $regdetails=Books::all();
        return view('admin.admin_ben_view',compact('regdetails'));
    }
    protected function validator(array $data)
    {
        return Validator::make($data, [
           // 'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:Register'],
            //'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $register=new Register(['name'=>$request->input('name'),
        'email'=>$request->input('email'),
        'phone'=>$request->input('phone'),
        'state'=>$request->input('state'),
        'dist'=>$request->input('dist'),
        'type'=>$request->input('type'),
        'password'=>Hash::make($request->get('password')),
        //'password'=>$request->input('password'),
        'status'=>$request->input('status')
        ]);
        $register->save();
        $utype=$request->get('type');
        $regid=Register::max('id');
       // $qwerty = session()
        if(($utype==1)||($utype==2))
        {
            //return $regid;
          
           return view('authenti.comreg',compact('regid'));
           //return view('authenti.comreg')->with($regid);

        }
        else
        {
            return view('ben.benreg',compact('regid'));
            //return redirect('ben.benreg',Compact($regid));
        }
       // return redirect('/log_in');
    }
 
    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit(Register $register)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Register $register)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
    public function profile(Register $register)
    {
        
    }
}
