<?php

namespace App\Http\Controllers;

use App\Register;
use App\district;
use Session;
use DB;
use Hash;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cover_photo=$request->img->getClientOriginalName();
        $request->img->storeAs('public/profile',$cover_photo);

        $adimg=$request->adimg->getClientOriginalName();
        $request->adimg->storeAs('public/adhar',$adimg);

        $register=new Register(['name'=>$request->input('name'),
        'email'=>$request->input('email'),
        'password'=>Hash::make($request->input('password')),
        'phone'=>$request->input('phone'),

        'district_id'=>$request->input('district'),
        'type'=>$request->input('type'),
        'sdate'=>$request->input('sdate'),
        'owner'=>$request->input('owner'),
        'nop'=>$request->input('nop'),
        'btype'=>$request->input('btype'),
        'ocb'=>$request->input('cero'),
        'dob'=>$request->input('dob'),
        'gender'=>$request->input('gender'),
        'adharno'=>$request->input('adharno'),
        'occup'=>$request->input('occup'),
        'wname'=>$request->input('wname'),
       
       'img'=>$cover_photo,
       'adimg'=>$adimg,
        
        //'password'=>$request->input('password'),
        'status'=>$request->input('status')
        ]);
       
        
        $register->save();
        return redirect('/log_in');



    //     $utype=$request->get('type');
    //     $regid=Register::max('id');
    //    // $qwerty = session()
    //     if(($utype==1)||($utype==2))
    //     {
    //         //return $regid;
          
    //        return view('authenti.comreg',compact('regid'));
    //        //return view('authenti.comreg')->with($regid);

    //     }
    //     else
    //     {
    //         return view('ben.benreg',compact('regid'));
    //         //return redirect('ben.benreg',Compact($regid));
    //     }
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit(Register $register)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Register $register)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
    public function checkEmail(Request $request){
        $data = $request->all();
        $usersCount = register::where('email',$data['email'])->count();
        if($usersCount>0){
            echo "false";
        }else{
            echo "true";die;
        }

    }
    public function regview()
    {
        $register=Register::all(); //all is a facade it is already defined.
        $regdetails=Register::all();
        return view('admin.admin_ben_view',compact('regdetails'));
    }
    
    public function checkstat($id)
    {
        $stat=Register::find($id);
        $stat->status=1;
        $stat->save();
        return redirect('/adbenview');
    }
    public function blockuser($id)
    {
        $stat=Register::find($id);
        $stat->status=0;
        $stat->save();
        return back()->with("Success","Blocked Successfully");
    }
    public function adorgview()
    {
        $register=Register::all(); //all is a facade it is already defined.
        $regdetails=Register::all();
        return view('admin.adorg_view',compact('regdetails'));
    }
    public function addonview()
    {
        $register=Register::all(); //all is a facade it is already defined.
        $regdetails=Register::all();
        return view('admin.addon_view',compact('regdetails'));
    }
    public function advolview()
    {
        $register=Register::all(); //all is a facade it is already defined.
        $regdetails=Register::all();
        return view('admin.advol_view',compact('regdetails'));
    }
    // public function adminprofile($email)
    // {
    //     $detail=Register::find($email)->post();
    //     return view('admin.adprofile',compact('detail'));
    // }
    public function adminedit($id)
    {
        $regist=Register::find($id);
        return view('admin.adprofile_edit',compact('regist'));
    }
    public function checkLogin(Request $request){
        $data = $request->all();
        $usersCount = register::where('email',$data['email'])->count();
        if($usersCount>0){
            echo "true";
        }
        else
        {
            echo "false";die;
        }

    }
    public function adminupdate(Request $request, $id)
    {
        $rup=Register::find($id);
        $rup->name=$request->get('name');
        $rup->email=$request->get('email');
        $rup->phone=$request->get('phone');
        $rup->save();
        return redirect('/adprofile');
    }
    public function changepass(Request $request)
    {   
        $email = $request->get('email');
        $password = $request->get('curpass');
        $newpass = Hash::make($request->get('newpass'));
        $a = Register::where('email', $email)->get();
        foreach ($a as $object)
        {
            if(Hash::check($password, $object->password))
           {
            $object->password=$newpass;
            $object->save();
            return redirect('/log_in');
           }
           else {
            return redirect('/adchpass')->with('error','Entered Password is incorrect');
           }
        }
    }
    public function profile(Request $request)
    {
        // return "hi";
        $sess=session()->get('email');
        //return $sess;
        $user=DB::table('registers')
        ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
        ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
        ->select('registers.*','tbl_district.district_name','tbl_state.state_name')
        ->where('registers.email', '=', $sess)
        ->get();
        //return $user;

       // return view('donor.donprofile',compact('user')); 
        return view('donor.donprofile',['data'=>$user]); 

     
 
    }
    public function donproupdate(Request $request, $id)
    {
        $data=Register::find($id);
        $cover_photo=$request->img->getClientOriginalName();
        $request->img->storeAs('public/profile',$cover_photo);

        $adimg=$request->adimg->getClientOriginalName();
        $request->adimg->storeAs('public/adhar',$adimg);
        $data->name=$request->get('name');
        $data->email=$request->get('email');
        $data->phone=$request->get('phone');
        $data->dob=$request->get('dob');
        $data->gender=$request->get('gender');
        $data->adharno=$request->get('adharno');
        $data->occup=$request->get('occup');
        $data->wname=$request->get('wname');
        $data->img=$cover_photo;
        $data->adimg=$adimg;
        //return $data;
       $data->save();
       return redirect('/donprofile');
    }
    public function donchangepass(Request $request)
    {   
        $sess=session()->get('email');
        $password = $request->get('curpass');
        $newpass = Hash::make($request->get('newpass'));
        $a = Register::where('email', $sess)->get();
        foreach ($a as $object)
        {
            if(Hash::check($password, $object->password))
           {
            $object->password=$newpass;
            $object->save();
            return redirect('/log_in');
           }
           else {
            return redirect('donor.donchangepass')->with('success','Entered Password is incorrect');
           }
        }
    }
    public function volprofile(Request $request)
    {
        $sess=session()->get('email');
        $user=DB::table('registers')
        ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
        ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
        ->select('registers.*','tbl_district.district_name','tbl_state.state_name')
        ->where('registers.email', '=', $sess)
        ->get();
        return view('volunte.volprofile',compact('user')); 
       
     
 
    }
    public function volproupdate(Request $request, $id)
    {
        $data=Register::find($id);
        $cover_photo=$request->img->getClientOriginalName();
        $request->img->storeAs('public/profile',$cover_photo);

        $adimg=$request->adimg->getClientOriginalName();
        $request->adimg->storeAs('public/adhar',$adimg);
        $data->name=$request->get('name');
        $data->email=$request->get('email');
        $data->phone=$request->get('phone');
        $data->dob=$request->get('dob');
        $data->gender=$request->get('gender');
        $data->adharno=$request->get('adharno');
        $data->occup=$request->get('occup');
        $data->wname=$request->get('wname');
        $data->img=$cover_photo;
        $data->adimg=$adimg;
       // return $data;
        $data->save();
       return redirect('/donprofile');
    }
    public function volchangepass(Request $request)
    {   
        $sess=session()->get('email');
        $password = $request->get('curpass');
        $newpass = Hash::make($request->get('newpass'));
        $a = Register::where('email', $sess)->get();
        foreach ($a as $object)
        {
            if(Hash::check($password, $object->password))
           {
            $object->password=$newpass;
            $object->save();
            return redirect('/log_in');
           }
           else {
            return redirect('volunte.volchangepass')->with('success','Entered Password is incorrect');
           }
        }
    }
    // ben starts

    public function benprofile(Request $request)
    {
        $sess=session()->get('email');
        $user=DB::table('registers')
        ->join('tbl_district','registers.district_id','=','tbl_district.district_id')
        ->join('tbl_state','tbl_district.state_id','=','tbl_state.state_id')
        ->select('registers.*','tbl_district.district_name','tbl_state.state_name')
        ->where('registers.email', '=', $sess)
        ->get();
        return view('ben.benprofile',compact('user')); 
       
     
 
    }
    public function benproupdate(Request $request, $id)
    {
        $data=Register::find($id);
        $cover_photo=$request->img->getClientOriginalName();
        $request->img->storeAs('public/profile',$cover_photo);

        $adimg=$request->adimg->getClientOriginalName();
        $request->adimg->storeAs('public/adhar',$adimg);
        $data->name=$request->get('name');
        $data->email=$request->get('email');
        $data->phone=$request->get('phone');
        $data->dob=$request->get('dob');
        $data->gender=$request->get('gender');
        $data->adharno=$request->get('adharno');
        $data->occup=$request->get('occup');
        $data->wname=$request->get('wname');
        $data->img=$cover_photo;
        $data->adimg=$adimg;
        return $data;
       // $data->save();
        //return redirect('/donprofile');
    }
    public function benpasschange(Request $request)
    {   
        $sess=session()->get('email');
        $password = $request->get('curpass');
        $newpass = Hash::make($request->get('newpass'));
        $a = Register::where('email', $sess)->get();
        foreach ($a as $object)
        {
            if(Hash::check($password, $object->password))
           {
            $object->password=$newpass;
            $object->save();
            return redirect('/log_in');
           }
           else {
            return redirect('ben.benchangepass')->with('success','Entered Password is incorrect');
           }
        }
    }
public function checkpasswd(Request $request)
{
        $sess=session()->get('email');
        $password = $request->all();
        $user = register::where('email',$sess)->get();
        foreach($user as $us)
        {
            if(Hash::check($password, $us->password))
            {
                echo "true";die;
            }
            else
            {
                echo "false";
            }
        }
}
}//end
