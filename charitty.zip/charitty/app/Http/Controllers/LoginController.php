<?php

namespace App\Http\Controllers;

//use App\Login;
use App\Register;
use Auth;
use Crypt;
use Session;
use Redirect;
use DB;
use Hash;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //return view("helow world");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       // return view('authenti.login');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    //     $email = $request->input('email');
    //     $password = $request->input('password');

    //      $checkLogin = DB::table('registers')->where(['email'=>$email,'password'=>$password])->get();

    //     if(count($checkLogin) > 0) 
    //     {
    //          }
        //return view('admin')->with(['name'=>" "]);
        // else {
    //    // echo "Login Failed!";
    //    return Redirect::route('/log_in')->with(['error'=> "Invalid email or Password!!"]);
    //      }   
   // }   
   
        $this->validate($request,[
            'email' => 'required',
            'password' => 'required',
         ]);
        $email = $request->get('email');
        session(['email' => $email]);
        $value = session('email');
        $password = $request->get('password');
        $a = Register::where('email', $email)->get();//where login is the model
               // return $a;
            //$name=$a->name;
            //return $password;
     foreach ($a as $object)
       {
           $name=$object->name;
           $img=$object->img;
           $btype=$object->btype;
           //$pass=Crypt::decrypt($request->password);
           if(Hash::check($password, $object->password))
           {
                
                 if($object->type == 0 && $object->status == 1 )
                 {
                    session_start();
                    session(['email'=>$email,'name'=>$name,'img'=>$img]);
                     //return view('admin.adminhome',['data'=>$a]);
                     return view('admin.adminhome');
                    }
                  elseif($object->type == 1 && $object->status == 1)
                  {
                    session_start();
                    session(['email'=>$email,'name'=>$name,'img'=>$img]);
                    //$request->session()->put('email',$email); 
                     return view('donor.donhome');
                  }
                  elseif($object->type == 2 && $object->status == 1)
                  {
                    session_start();
                    session(['email'=>$email,'name'=>$name,'img'=>$img]);
                     return view('volunte.volhome');
                  }
                  elseif($object->type == 3 && $object->status == 1)
                  {
                    session_start();
                    session(['email'=>$email,'name'=>$name,'img'=>$img,'btype'=>$btype]);
                     return view('ben.benhome');
                  }
                   else {
                    return back() ->with('error','Your Blocked / Not Approved !');
                   }
           }
            else
            {
                return back() ->with('error','Invalid User name / Password !');
            }
         
        }
  
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(Login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(Login $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(Login $login)
    {
        //
    }
    public function logout(Request $request)
    {    
        Session::flush();
        Auth::logout(); 
        return Redirect::to('log_in');   
    //     Auth::logout();
    // session()->flush();
    // session_unset();
    //   return Redirect::route('log_in');
    }
}
