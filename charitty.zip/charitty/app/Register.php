<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    protected $fillable = [
        'name','email','phone','state','dist','type','password','status','remember_token'];
}
