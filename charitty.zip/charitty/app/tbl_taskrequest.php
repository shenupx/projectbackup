<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_taskrequest extends Model
{
    public $fillable=['id','donation_id','reqstatus','accept','onduty'];

}
