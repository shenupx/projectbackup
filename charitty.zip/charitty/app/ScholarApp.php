<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScholarApp extends Model
{
    protected $fillable = ['mem_id','percent','scheme_id','certificate','status'];

}
