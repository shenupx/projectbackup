<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
    protected $fillable = [
        'bankname','branchname','acholder','acnumber',
        'ifsc','id','card_id','coname','cardnumber','cvv',
    'mnth_id','yid','balance'];
}
