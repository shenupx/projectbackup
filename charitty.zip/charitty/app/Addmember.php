<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addmember extends Model
{
    protected $fillable = ['name','id','dob','gender','adharno','yexpense','spon_stat','image','couse_id','iname'];
}
