<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Benreg extends Model
{
    protected $fillable = [
        'id','sdate','owner','nop','btype','place','cero','cert','certt'];
}
