<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $fillable = [
        'event_name','tye_id','event_detail','amount','no_person','edate',
        'etime','eplace','icon','damount'];
}
