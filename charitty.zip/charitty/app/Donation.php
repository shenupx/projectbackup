<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donation extends Model
{
    public $fillable=['email','item_id','specitem','quantity','id','district_id','volid','collectstat','deliverystat'];

}
