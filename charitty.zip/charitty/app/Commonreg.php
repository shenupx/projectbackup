<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Commonreg extends Model
{
    protected $fillable = [
        'id','dob','gender','adharno','occup','wname','img','adimg'];
}
