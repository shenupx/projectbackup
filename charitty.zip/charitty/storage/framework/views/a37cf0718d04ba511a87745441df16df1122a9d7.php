<?php /* H:\main project\charitty\resources\views/volunte/newtask.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> New Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Donor name</th>
            <th scope="col">Item Name</th>
            <th scope="col">District</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    
    <?php $__currentLoopData = $myreq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <tr>
            <th scope="row">1</th>
            <td><?php echo e($donname); ?></td>
            <td><?php echo e($reg->item); ?></td>
            <td><?php echo e($reg->district_name); ?></td>
            <td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($reg->req_id); ?>">Get Details</button></td>
        </tr>
            <div class="modal fade" id="exampleModal<?php echo e($reg->req_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Donor Name: <?php echo e($donname); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="paragraph-agileits-w3layouts mt-3">
                Item Name: <?php echo e($reg->item); ?>  </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                District Name : <?php echo e($reg->district_name); ?> </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                email Id: <?php echo e($reg->email); ?> </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                Phone : <?php echo e($reg->phone); ?> </p>
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="<?php echo e(route('acceptreq',$reg->req_id)); ?>" class="btn btn-primary">Accept</a>
                <a href="<?php echo e(route('acceptreq',$reg->req_id)); ?>" class="btn btn-danger">Reject</a>
            </div>
        </div>
    </div>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.volheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>