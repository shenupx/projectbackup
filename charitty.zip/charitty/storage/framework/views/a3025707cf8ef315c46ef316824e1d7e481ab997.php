<?php /* H:\main project\charitty\resources\views/donor/oldmem.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<section class="cards-section">
<div class="card-columns">
<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/member/<?php echo e($evt->image); ?>" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title"><?php echo e($evt->name); ?></h5>
    <p class="card-text">Date of Birth : <?php echo e($evt->dob); ?></p>
    <a href="#" class="btn more mt-3" data-toggle="modal" data-target="#exampleModal<?php echo e($evt->mem_id); ?>">Read More</a>
            <!-- Modal -->
    <div class="modal fade" id="exampleModal<?php echo e($evt->mem_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel1"><?php echo e($evt->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                            </button>
                </div>
                <div class="modal-body">
                    <img class="card-img-top" src="../../../storage/member/<?php echo e($evt->image); ?>" alt="Card image cap">
                    <p class="paragraph-agileits-w3layouts ">Date of Birth: <?php echo e($evt->dob); ?></p>
                    <p class="paragraph-agileits-w3layouts ">Gender : <?php echo e($evt->gender); ?></p>
                    
                    <p class="paragraph-agileits-w3layouts ">Adhar Number :<?php echo e($evt->adharno); ?></p>
                    <p class="paragraph-agileits-w3layouts ">Yearly Expense :<?php echo e($evt->yexpense); ?></p>
                    <a href="<?php echo e(route('sponsor',$evt->mem_id)); ?>" class="btn more mt-3" >Become a Sponsor</a>
                   

                   

                </div>
            </div>
        </div>
    </div>
    <!-- /Modal -->
        </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>