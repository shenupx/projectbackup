<?php /* H:\main project\charitty\resources\views/admin/selectedstud.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Congratulations </h4>
<table class="table">
<thead class="thead-dark">
    <tr>
        <th scope="col">#</th>
        <th scope="col">Organization Name</th>
        <th scope="col">Student Name</th>
        <th scope="col">Details</th>
    </tr>
</thead>
<tbody>

<?php $__currentLoopData = $newone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <tr>
        <th scope="row">1</th>
        <td><?php echo e($reg->newname); ?></td>
        <td><?php echo e($reg->name); ?></td>
        <td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($reg->mem_id); ?>">Get Details</button></td>
    </tr>
        <div class="modal fade" id="exampleModal<?php echo e($reg->mem_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e($reg->newname); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <img src="../../../storage/scholarcertificate/<?php echo e($reg->certificate); ?>" class="img-fluid" alt="Responsive image">
            <p class="paragraph-agileits-w3layouts mt-3">
            Email : <?php echo e($reg->name); ?> </p>
            
            <p class="paragraph-agileits-w3layouts mt-3">
            Aadhar Number :<?php echo e($reg->adharno); ?> </p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <a href="<?php echo e(route('grant',$reg->sapp_id)); ?>" class="btn btn-primary">Grant Scholarship</a>
        </div>
    </div>
</div>

</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>