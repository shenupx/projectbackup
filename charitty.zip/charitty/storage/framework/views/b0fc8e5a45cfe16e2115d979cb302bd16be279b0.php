<?php /* H:\main project\charitty\resources\views/donor/oldageview.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Old Age Home</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Email Id</th>
            <th scope="col">Phone</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    <?php $__currentLoopData = $orphanages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td><?php echo e($use->name); ?></td>
            <td><?php echo e($use->email); ?></td>
            <td><?php echo e($use->phone); ?></td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($use->id); ?>">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal<?php echo e($use->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($use->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <img src="../../../storage/profile/<?php echo e($use->img); ?>" class="img-fluid" alt="Responsive image">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Email : <?php echo e($use->email); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Phone : <?php echo e($use->phone); ?> </p>
                    
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <a href="<?php echo e(route('oldageh',$use->id)); ?>" class="btn btn-primary">View Members</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>