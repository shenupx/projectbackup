<?php /* H:\main project\charitty\resources\views/ben/benaddstud.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<script src="js/jquery.js"></script>
<div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">Add New Student</h4>
                    <form action="/addmem" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="scheme">Student Name</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name of Member" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme">Date of Birth</label>
                                <input type="date" name="dob" class="form-control" id="dob" placeholder="Date of Birth" required="">
                            </div>
                               
                            <!-- <div class="form-group col-md-6">
                                <label for="education">Education Qualification</label>
                                <select id="couse_id" name="couse_id" class="form-control">
                                <option value="0" disabled selected>Select Course</option>
									<?php if(isset($course)): ?>

									<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($cc->couse_id); ?>"><?php echo e($cc->course); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                    
                                </select>
                            </div> -->
                        </div>
                        <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="">Gender</label>
                                <select id="gender" name="gender" class="form-control" required>
                                <option value="0" disabled selected>Select Gender</option>
                                <option value="male"> Male</option>
                                <option value="female"> Female</option>
                                </select>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme">Class/Course</label>
                                <select id="couse_id" name="couse_id" class="form-control" required>
                                <option value="#" disabled selected>Select Course</option>
									<?php if(isset($course)): ?>

									<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($cc->couse_id); ?>"><?php echo e($cc->course); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                    <option value="0">Others </option>
                                </select>
                                </div>
                                </div>
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Specify Your Course</label><input type='text' name='cou' class='form-control' id='cou' placeholder='Enter Course Name' />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>
                          
                        <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="scheme">Institute Name</label>
                                <input type="text" name="iname" class="form-control" id="iname" placeholder="Institute Name" required="">
                        </div>                           
                         <div class="form-group col-md-6">
                                <label for="scheme">Aadhar Number</label>
                                <input type="text" name="adharno" class="form-control" id="adharno" placeholder="Aadhar Number of Student" required="">
                         </div>
                        </div>

                        <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="scheme">Yearly Expense</label>
                                <input type="text" name="yexpense" class="form-control" id="yexpense" placeholder="Yearly Expense of member" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme">Image</label>
                                <input type="file" name="img" class="form-control" id="img" placeholder="Member Image" required="">
                            </div>
                            
                            </div>
                    
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
                    </form>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>