<?php /* H:\main project\charitty\resources\views/authenti/registration.blade.php */ ?>
<link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" />

   <?php $__env->startSection('content'); ?>

	<!-- Main Content -->
	<div class="main">
		<div class="main-w3l">
			<!-- <h3 class="logo-w3">Register Now</h3> -->
			<div class="w3layouts-main">
				<h2><span>Register now</span></h2>
					<form  action="<?php echo e(route('newreg.store')); ?>" method="post" id="reg_form">
						<?php echo csrf_field(); ?>
                  <input placeholder="Full Name" name="name" id="name" type="text" required="">
						<input placeholder="Email" name="email" id="email" type="email" required="">
						<input placeholder="Phone Number" name="phone" id="phone" type="text" required="">
						<input placeholder="State" name="state" id="state" type="text" required="">
						<input placeholder="district" name="dist" id="dist" type="text" required="">
						<select name="type" id="type">
									<option value="sel"  disabled selected>Select your type</option>
                            <option value="1">Donor</option>
                            <option value="2">Volunteer</option>
									 <option value="3">Organization</option>
                        </select> </br>  </br>
						<input placeholder="Password" name="password" type="password"  id="password1" required="">
						<input  name="status" type="hidden" value="0"  id="status">
						<input placeholder="Confirm Password" name="password2" type="password"   required="">
						<input type="submit" value="Register" name="submit">
					</form>
					<script src="<?php echo e(asset('js/validate/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validate/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validate/jquery.validate.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/validate/additional-methods.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/validate/validations.js')); ?>"></script>
			</div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>