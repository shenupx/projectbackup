<?php /* H:\main project\charitty\resources\views/viewevent.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="admin/css/style4.css">

<section class="cards-section">
<div class="card-columns">
<?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/event/<?php echo e($evt->icon); ?>" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title"><?php echo e($evt->event_name); ?></h5>
    <p class="card-text"><?php echo e($evt->event_detail); ?></p>
            <!-- Modal -->
   
        </div>
    </div>
   
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>