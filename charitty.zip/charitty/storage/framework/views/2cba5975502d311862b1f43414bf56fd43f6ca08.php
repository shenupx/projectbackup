<?php /* H:\main project\charitty\resources\views/admin/add_item.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<script src="js/jquery.js"></script>
<script src="js/validate/jquery.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<!-- <script src="js/main.js"></script>
	<script src="js/passtrength.js"></script> -->
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="card-header">Add Item </h4> <br>
    <form action="/additems" method="post" name="items" id="items">
    <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Item Name</label>
            <div class="col-sm-10">
            <select id="item" name="item" class="form-control" required>
                                <option value="" >Select item</option>
									<?php if(isset($item)): ?>

									<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($cc->item_id); ?>"><?php echo e($cc->item); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                   <br> <option value="0">Others </option>
                                <</select>
                                </div>   </div>
        
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Enter new Item</label><input type='text' name='nite' class='form-control' id='nite' placeholder='Enter item Name' required />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>
         
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="iqty" name="iqty" placeholder="No.of Items" required>
            </div>
        </div>          
                               
        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Add Item</button>
            </div>
        </div>
    </form>
    <script>
jQuery().ready(function(){
    //alert("test");
    jQuery("#items").validate({
			rules:{
            item:{
                required:true
            },
            iqty:{
                required:true,
                number:true,
            }
        },
        messages:{
            item:{
                required: "Please Select Item"
                
            },
            iqty:{
                required: "Please Enter Quantity",
                number: "enter Only number "
            }
        }

			});
		});
	</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>