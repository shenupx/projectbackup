<?php /* H:\main project\charitty\resources\views/admin/adscholar.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>  -->
<script src="js/jquery.js"></script>

<div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">Add New Scholarship Scheme</h4>
                    <form action="/scholar" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="scheme">Name of Scheme</label>
                                <input type="text" name="nscheme" class="form-control" id="nscheme" placeholder="Name of Scheme" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="education">Education Qualification</label>
                                <select id="couse_id" name="couse_id" class="form-control" required>
                                <option value="" >Select Course</option>
									<?php if(isset($course)): ?>

									<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($cc->couse_id); ?>"><?php echo e($cc->course); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                    <option value="0">Others </option>
                                </select>
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Specify Your Course</label><input type='text' name='cou' class='form-control' id='cou' placeholder='Enter Course Name' />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>
                            
                        </div>
                        </div>
                        <div class="form-row">
                        
                            <div class="form-group col-md-6">
                                <label for="scheme">Maximum No of Persons</label>
                                <input type="text" name="nop" class="form-control" id="nop" placeholder="Maximum Number of Persons" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme">Award</label>
                                <input type="text" name="award" class="form-control" id="award" placeholder="Award (Maximum Amount)" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <label for="inputAddress">Description</label>
                            <textarea class="form-control" name="detail" id="detail" placeholder="Details" required> </textarea>
                        </div>
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
                    </form>
                </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>