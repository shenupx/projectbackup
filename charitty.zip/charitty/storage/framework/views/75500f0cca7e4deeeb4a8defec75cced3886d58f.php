<?php /* H:\main project\charitty\resources\views/donor/mydonations.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">My donations</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Date</th>
            <th scope="col">Amount</th>
            <th scope="col">To</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    <?php $__currentLoopData = $mydon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td><?php echo e($use->created_at); ?></td>
            <td><?php echo e($use->namount); ?></td>
            <td><?php echo e($use->event_name); ?></td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>