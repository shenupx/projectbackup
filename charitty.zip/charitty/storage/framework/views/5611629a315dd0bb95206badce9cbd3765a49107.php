<?php /* H:\main project\charitty\resources\views/donor/payment.blade.php */ ?>
<?php if(session()->has('email')): ?>

<!DOCTYPE html>
<html>
<head>
<title>Donate</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="http://127.0.0.1:8000/pay/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="http://127.0.0.1:8000/pay/css/creditly.css" type="text/css" media="all" />
<link rel="stylesheet" href="http://127.0.0.1:8000/pay/css/easy-responsive-tabs.css">
<script src="http://127.0.0.1:8000/pay/js/jquery.min.js"></script>
</head>
<body>
	<div class="main">	
	<div class="w3_agile_main_grids">
			<div class="agile_main_top_grid">
				<div class="agileits_w3layouts_main_top_grid_left">
					<a href="/donfe"><img src="http://127.0.0.1:8000/pay/images/1.png" alt=" " /></a>
				</div>
				<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="w3_agileits_main_top_grid_right">
					<h3>Checkout Form</h3>
				</div>
				<div class="clear"> </div>
				<!-- <div class="wthree_total">
					<h2>total to pay <span><i>Rs.</i>	<input class=" form-control" type="text" name="amount"></span></h2>
				</div> -->
			</div>
			<div class="agileinfo_main_bottom_grid">
				<div id="horizontalTab">
					<ul class="resp-tabs-list">
						<li><img src="http://127.0.0.1:8000/pay/images/1.jpg" alt=" " /></li>
						<li><img src="http://127.0.0.1:8000/pay/images/2.jpg" alt=" " /></li>
					</ul>
					<div class="resp-tabs-container">
						<div class="agileits_w3layouts_tab1">
							<!-- form starts -->
							<form action="/paycvb" method="post" class="creditly-card-form agileinfo_form">
							<?php echo csrf_field(); ?>
							<div class="wthree_total">
					<h2>total to pay <span><i>Rs.</i>	<input class=" form-control" pattern= “^[0–9]$” type="number"  name="amount" required></span></h2>
				</div>
								<section class="creditly-wrapper wthree, w3_agileits_wrapper">
									<div class="credit-card-wrapper">
										<div class="first-row form-group">
										<div class="controls">
											
										<input class="billing-address-name form-control" type="hidden" name="eid"  value="<?php echo e($eid); ?>">

												<label class="control-label">Card Type</label>
												<Select class="billing-address-name form-control" type="text" id="ctype" name="ctype" required>
													<option value="" disabled >Card Type</option>
													<?php if(isset($card)): ?>
													<?php $__currentLoopData = $card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($cc->card_id); ?>"><?php echo e($cc->card); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</select>
											</div>
											<div class="controls">
												<label class="control-label">Name on Card</label>
												<input class="billing-address-name form-control" type="text" name="name" placeholder="Name on the card" required >

											</div>
											<div class="w3_agileits_card_number_grids">
												<div class="w3_agileits_card_number_grid_left">
													<div class="controls">
														<label class="control-label">Card Number</label>
														<input class="number credit-card-number form-control" type="text" name="cnumber"
																	  inputmode="numeric" autocomplete="cc-number"  autocompletetype="cc-number" x-autocompletetype="cc-number"
																	  placeholder="&#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149;">
													</div>
												</div>
												<div class="w3_agileits_card_number_grid_right">
													<div class="controls">
														<label class="control-label">CVV</label>
														<input class="security-code form-control"Â·
																	  inputmode="numeric"
																	  type="text" name="cvv"
																	  placeholder="&#149;&#149;&#149;" required >
													</div>
												</div>
												<div class="clear"> </div>
											</div>
											<div class="w3_agileits_card_number_grids">
												<div class="w3_agileits_card_number_grid_left">
													<div class="controls">
														<label class="control-label">Expery Month</label>
														<Select class="billing-address-name form-control" type="text" name="emonth" required>
														<option value="" disabled >-- Month --</option>
													<?php if(isset($month)): ?>
													<?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($month->mnth_id); ?>"><?php echo e($month->month); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</select>
													</div>
												</div>
												<div class="w3_agileits_card_number_grid_right">
													<div class="controls">
														<label class="control-label">Expiry Year</label>
														<Select class="billing-address-name form-control" type="text" name="eyear" required>
														<option value="" disabled >-- Year --</option>
														<?php if(isset($year)): ?>
													<?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($year->yid); ?>"><?php echo e($year->year); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endif; ?>
												</select>
														
													</div>
												</div>
												<div class="clear"> </div>
											</div>
										</div>
										<button class="btn btn-primary" type="submit">Make  payment</button>
									</div>
								</section>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<!-- credit-card -->
		<script type="text/javascript" src="http://127.0.0.1:8000/pay/js/creditly.js"></script>
		<script type="text/javascript">
			$(function() {
			  var creditly = Creditly.initialize(
				  '.creditly-wrapper .expiration-month-and-year',
				  '.creditly-wrapper .credit-card-number',
				  '.creditly-wrapper .security-code',
				  '.creditly-wrapper .card-type');

			  $(".creditly-card-form .submit").click(function(e) {
				e.preventDefault();
				var output = creditly.validate();
				if (output) {
				  // Your validated credit card output
				  console.log(output);
				}
			  });
			});
		</script>
	<!-- //credit-card -->
	<!-- tabs -->
	<script src="http://127.0.0.1:8000/pay/js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true,   // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function(event) { // Callback function if tab is switched
				var $tab = $(this);
				var $info = $('#tabInfo');
				var $name = $('span', $info);
				$name.text($tab.text());
				$info.show();
				}
			});
		});
	</script>
	<!-- //tabs -->
</body>
</html>
<?php endif; ?>