<?php /* H:\main project\charitty\resources\views/ben/scholarview.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Available Scholarships</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Scheme</th>
            <th scope="col">Amount</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
    <tr>
    <th scope="row"><?php print ++$pos; ?></th>
    <td><?php echo e($dd->nscheme); ?></td>
    <td><?php echo e($dd->award); ?></td>
    <td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($dd->scheme_id); ?>">Get Details</button></td>
    
</tr>
<div class="modal fade" id="exampleModal<?php echo e($dd->scheme_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($dd->nscheme); ?></h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <img src="images/ban4.jpg" class="img-fluid" alt="Responsive image">
    <p class="paragraph-agileits-w3layouts mt-3">
    Amount : <?php echo e($dd->award); ?> </p>
    <p class="paragraph-agileits-w3layouts mt-3">
    Availability : <?php echo e($dd->nop); ?> </p>
    <p class="paragraph-agileits-w3layouts mt-3">
    Details : <?php echo e($dd->detail); ?> </p>
</div>
<div class="modal-footer">
<!-- <?php echo e(route('approve',$dd->scheme_id)); ?> -->
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <a href="<?php echo e(route('scholarapply',$dd->scheme_id)); ?>" class="btn btn-primary">Apply</a>
</div>
</div>
</div>
    </tbody>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>