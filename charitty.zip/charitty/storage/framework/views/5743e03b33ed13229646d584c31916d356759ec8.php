<?php /* H:\main project\charitty\resources\views/volunte/volreport.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- <link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" /> -->

<script src="js/jquery.js"></script>
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="card-header">Report Street Peoples</h4> <br>

    <form action="/savereport" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group row">
    <label for="state" class="col-sm-2 col-form-label"> State </label>
    <div class="col-sm-10">
		<select name="state" id="state" class="form-control" required>
		<option value=""  >Select your State</option>
		<?php if(isset($data)): ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($state->state_id); ?>"><?php echo e($state->state_name); ?> </option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
        </select> </br>  </br>
</div>
</div>
<div class="form-group row">
    <label for="district" class="col-sm-2 col-form-label"> District </label>
    <div class="col-sm-10">
    <select name="district" id="district" class="form-control" required>
           <option value=""  >Select your District</option>
    </select> </br>  </br>
</div>
</div>  
<div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Details</label>
    <div class="col-sm-10">
        <textarea class="form-control" id="details" name="details" placeholder=" Details" required></textarea>
    </div>
</div>    
    <div class="form-group row">
    <label for="" class="col-sm-2 col-form-label">land Mark </label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="lmark" name="lmar" placeholder="Land Mark" required>
        </div>    
</div>         
<div class="form-group row">
    <label for="" class="col-sm-2 col-form-label">Upload Image </label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="image" name="image" placeholder="" required>
        </div>    
</div>
    <div class="form-group row">
        <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Report</button>
        </div>
        </div>
    </form>
</div>
<script src="js/validate/jquery.js"></script>
		<script src="js/ajax.js"></script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.volheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>