<?php /* H:\main project\charitty\resources\views/ben/donationforme.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">My donations</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Donor Name</th>
            <th scope="col">Item</th>
            <th scope="col">Volunteer Name</th>
            <th scope="col"> Status</th>

        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>new</td>
            <td><?php echo e($use->item); ?></td>
            <td><?php echo e($use->volname); ?></td>
            <?php if($use->collectstat == 1 && $use->deliverystat == 0): ?>
            <td><a href="<?php echo e(route('dropping',$use->donation_id)); ?> " class="btn btn-success">Dropped</a></td>
            <?php elseif($use->deliverystat == 1): ?>
            <td><button type="button" disabled class="btn btn-warning">Dropped</button></td>
            <?php else: ?>
            <td><button type="button" disabled  class="btn btn-danger">Not Yet Collected</button></td>
            <?php endif; ?>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>