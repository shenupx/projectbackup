<?php /* H:\main project\charitty\resources\views/ben/viewreqtstat.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests Status</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Requested Item</th>
            <th scope="col">Quatity</th>
            <th scope="col">Status</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($use->active==1): ?>
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td><?php echo e($use->item); ?></td>
            <td><?php echo e($use->quatity); ?></td>
            <td><p class="btn btn-primary">Granted</p></td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($use->request_id); ?>">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal<?php echo e($use->request_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($use->item); ?> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Item Name : <?php echo e($use->item); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Quatititty : <?php echo e($use->quatity); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Speicific : <?php echo e($use->specific); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Within : <?php echo e($use->days); ?> </p>
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <p class="btn btn-primary">Granted</p>
                </div>
            </div>
        </div>
       <?php else: ?>
       <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td><?php echo e($use->item); ?></td>
            <td><?php echo e($use->quatity); ?></td>
            <td><p class="btn btn-primary">Pending</p></td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($use->request_id); ?>">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal<?php echo e($use->request_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($use->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Item Name : <?php echo e($use->item); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Quatititty : <?php echo e($use->quatity); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Speicific : <?php echo e($use->specific); ?> </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Within : <?php echo e($use->days); ?> </p>
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <p class="btn btn-primary">Pending</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>