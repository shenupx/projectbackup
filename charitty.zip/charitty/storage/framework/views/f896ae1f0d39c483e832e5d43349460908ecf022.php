<?php /* H:\main project\charitty\resources\views/volunte/volnonfund.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<section class="cards-section">
<div class="card-columns">
<?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($evt->amount > $evt->damount): ?>
<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/event/<?php echo e($evt->icon); ?>" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title"><?php echo e($evt->event_name); ?></h5>
    <p class="card-text"><?php echo e($evt->event_detail); ?></p>
    <a href="#" class="btn more mt-3" data-toggle="modal" data-target="#exampleModal<?php echo e($evt->event_id); ?>">Read More</a>
            <!-- Modal -->
    <div class="modal fade" id="exampleModal<?php echo e($evt->event_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel1"><?php echo e($evt->event_name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                            </button>
                </div>
                <div class="modal-body">
                    <img class="card-img-top" src="../../../storage/event/<?php echo e($evt->icon); ?>" alt="Card image cap">
                    
                    <p class="paragraph-agileits-w3layouts "><?php echo e($evt->event_detail); ?></p>
                    <?php if($evt->tye_id==1): ?>
                    <p class="paragraph-agileits-w3layouts ">Goal Rs.<?php echo e($evt->amount); ?></p>
                    <p class="paragraph-agileits-w3layouts ">Target Date<?php echo e($evt->tdate); ?></p>
                    <a href="" class="btn more mt-3" >Donate Now</a>
                    <?php else: ?>
                    <p class="paragraph-agileits-w3layouts ">No.of Volunteers Needed :<?php echo e($evt->no_person); ?></p>
                    <p class="paragraph-agileits-w3layouts ">Event Date:<?php echo e($evt->edate); ?></p>
                    <a href="" class="btn more mt-3" >Become a Volunteer</a>

                    <?php endif; ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- /Modal -->
        </div>
    </div>
   
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.volheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>