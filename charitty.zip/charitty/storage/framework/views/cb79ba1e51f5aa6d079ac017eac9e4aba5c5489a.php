<?php /* H:\main project\charitty\resources\views/admin/admin_ben_view.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt top">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                            <h1>view Oraganizations </h1>
                            </div>
</div>
</div>
</section>
</section

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>