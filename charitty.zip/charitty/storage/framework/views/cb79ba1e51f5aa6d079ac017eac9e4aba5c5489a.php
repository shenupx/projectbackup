<?php /* H:\main project\charitty\resources\views/admin/admin_ben_view.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4"> Request to be Approved</h4>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr><?php $pos=0; ?>
                                <th scope="col">Sl.No</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Details</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        
                        <?php $__currentLoopData = $regdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($reg->status==0): ?>
                              
                            <tr>
                                <th scope="row"><?php print ++$pos; ?></th>
                                <td><?php echo e($reg->name); ?></td>
                                <td><?php echo e($reg->email); ?></td>
                                <td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal<?php echo e($reg->id); ?>">Get Details</button></td>
                                <td><button type="button" class="btn btn-secondary">Waiting </button></td>
                            </tr>
                             <div class="modal fade" id="exampleModal<?php echo e($reg->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($reg->name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="../../../storage/profile/<?php echo e($reg->img); ?>" class="img-fluid" alt="Responsive image">
                                    <p class="paragraph-agileits-w3layouts mt-3">
                                    Email : <?php echo e($reg->email); ?> </p>
                                    <p class="paragraph-agileits-w3layouts mt-3">
                                    Phone : <?php echo e($reg->phone); ?> </p>
                                    <p class="paragraph-agileits-w3layouts mt-3">
                                    Aadhar Number : <?php echo e($reg->adharno); ?> </p>
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-success">Verify</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <a href="<?php echo e(route('approve',$reg->id)); ?>" class="btn btn-primary">Approve</a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?> 
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                                          
                    <!-- popup content -->
                    
          	
      
          	
                              
                              <!-- <tr>
                                  <td><a href="basic_table.html#"></a></td>
                                  <td class="hidden-phone"></td>
                                  <td><?php echo e($reg->phone); ?></td>
                                  <td><a href="<?php echo e(route('approve',$reg->id)); ?>"><span class="label label-info label-mini">Approve</span></a></td>
                                                              </tr>
                              </tbody>
                              
                          </table> -->
                          
                      <!-- <form class="form-horizontal style-form" method="get">
                     
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control">
                              </div>
                          </div>
                          </form> </div></div></div> -->
                          </section>
                          </section>
<!-- <section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt top">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                            <h1>view Oraganizations </h1>

                            </div> -->
</div>
</div>
</section>
</section

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>