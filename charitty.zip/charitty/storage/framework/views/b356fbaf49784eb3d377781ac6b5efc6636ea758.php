<?php /* H:\main project\charitty\resources\views/admin/donationfdetail.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="row">
<!-- Profile -->
<div class="outer-w3-agile col-xl mt-3">
    <div class="profile-main-w3ls">
        <div class="profile-pic wthree">
        
            <h3>Donor Name : <?php echo e($name); ?></h3> 
            <?php $__currentLoopData = $donation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($don->item_id ==0): ?>
            
        </div>
        <div class="w3-message">
            
            <p> Item Name :<?php echo e($don->specitem); ?></p> 
            <p> Quatity : <?php echo e($don->quantity); ?></p> 
            <p> Current Place : <?php echo e($don->district_name); ?></p> 
            
            <div class="w3ls-touch">
            <a href="<?php echo e(route('viewvolnteer',$don->donation_id)); ?>" class="btn btn-primary">Search Volunteer</a>
            <?php else: ?>
        <div class="w3-message">
            
            <p> Item Name :<?php echo e($don->item); ?></p> 
            <p> Quatity : <?php echo e($don->quantity); ?></p> 
            <p> Current Place : <?php echo e($don->district_name); ?> </p> 
            <div class="w3ls-touch">
            <!-- <input type="hidden" name="id" id="id" value="<?php echo e($don->donation_id); ?>" /> -->
            <?php if($don->deliverystat==0): ?>
            <a href="<?php echo e(route('viewvolnteer',$don->donation_id)); ?>" class="btn btn-primary">Search Volunteer</a>
            <?php else: ?>
            <button  class="btn btn-primary" disabled >Task Completed</button>
            <?php endif; ?>
            <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>
<!--// Profiile -->
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>