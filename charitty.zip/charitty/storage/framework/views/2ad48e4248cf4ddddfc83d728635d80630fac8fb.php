<?php /* H:\main project\charitty\resources\views/ben/benprofile.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<?php
use App\Register;
$sess=session()->get('email');
$a=Register::where('email',$sess)->get();

foreach($a as $object)
{
    $id=$object->id;
    $name=$object->name;
    $email=$object->email;
    $phone=$object->phone;
    $state=$object->state;
    $dist=$object->dist;
  
   //echo "<p>" .+ echo $name; .+"{{csrf_field(0}} </p>"; 
}
?>

<p> Name: <?php echo $name; ?> <?php echo e(csrf_field()); ?> </p>
<p> Email: <?php echo $email; ?> <?php echo e(csrf_field()); ?> </p>
<p> Phone : <?php echo $phone; ?> <?php echo e(csrf_field()); ?> </p>
<p> State: <?php echo $state; ?> <?php echo e(csrf_field()); ?> </p>
<p> District: <?php echo $dist; ?> <?php echo e(csrf_field()); ?> </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>