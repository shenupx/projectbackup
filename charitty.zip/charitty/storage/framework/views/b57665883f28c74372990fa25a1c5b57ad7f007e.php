<?php /* H:\main project\charitty\resources\views/admin/adminhome.blade.php */ ?>
<!-- <?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
     <!-- Stats --> 
    <!-- <div class="outer-w3-agile col-xl">
        <div class="stat-grid p-3 d-flex align-items-center justify-content-between bg-primary">
            <div class="s-l">
                <h5>Donations</h5>
                <p class="paragraph-agileits-w3layouts text-white">New Donations from Donors</p>
            </div>
            <div class="s-r">
                <h6>340
                    <i class="far fa-edit"></i>
                </h6>
            </div>
        </div>
        <div class="stat-grid p-3 mt-3 d-flex align-items-center justify-content-between bg-success">
            <div class="s-l">
                <h5>New Registrations</h5>
                <p class="paragraph-agileits-w3layouts">Waitting for Approval</p>
            </div>
            <div class="s-r">
                <h6>250
                    <i class="far fa-smile"></i>
                </h6>
            </div>
        </div>
        <div class="stat-grid p-3 mt-3 d-flex align-items-center justify-content-between bg-danger">
            <div class="s-l">
                <h5>Scholarship Applications</h5>
                <p class="paragraph-agileits-w3layouts">Total Applications</p>
            </div>
            <div class="s-r">
                <h6>232
                    <i class="fas fa-tasks"></i>
                </h6>
            </div>
        </div>
        <div class="stat-grid p-3 mt-3 d-flex align-items-center justify-content-between bg-warning">
            <div class="s-l">
                <h5>Total Users</h5>
                <p class="paragraph-agileits-w3layouts">Total Users of this site</p>
            </div>
            <div class="s-r">
                <h6>190
                    <i class="fas fa-users"></i>
                </h6>
            </div>
        </div>
    </div>
  -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>