<?php /* H:\main project\charitty\resources\views/admin/adevent_detailview.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $newo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h3><?php echo e($evt->event_name); ?></h3>
<p>Event Type: <?php echo e($evt->type); ?></p>
<p> Event Details: <?php echo e($evt->event_detail); ?></p>

<?php if($evt->tye_id==1): ?>
    <p>Target Amount: <?php echo e($evt->amount); ?></p>
    <p>Target Date: <?php echo e($evt->tdate); ?></p>
<?php else: ?>
    <p>No.of Volunteers Needed: <?php echo e($evt->no_person); ?></p>
    <p>Event Date: <?php echo e($evt->edate); ?></p>
<?php endif; ?>
<a href="/viewevent" class="btn btn-primary">Back</a>
<a href="<?php echo e(route('eventedit',$evt->event_id)); ?>" class="btn btn-primary">Edit Event</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>