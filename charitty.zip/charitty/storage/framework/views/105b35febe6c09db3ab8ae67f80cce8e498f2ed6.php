<?php /* H:\main project\charitty\resources\views/admin/donationview.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Donations</h4>
<table class="table">
    <thead class="thead-dark">
        <tr><?php $pos=0; ?>
            <th scope="col">Sl.No</th>
            <th scope="col">Donor Name</th>
            <th scope="col">Item </th>
            <th scope="col">Quatity</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $donation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>           
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td><?php echo e($name); ?></td>
            <td><?php echo e($donation->item); ?></td>
            <td><?php echo e($donation->quantity); ?></td>
            <td><a href="<?php echo e(route('donationdetails',$donation->donation_id)); ?>" class="btn btn-dark" >Get Details</a></td>
        </tr>
        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>