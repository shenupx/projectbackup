<?php /* H:\main project\charitty\resources\views/authenti/comreg.blade.php */ ?>
<link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" />

   <?php $__env->startSection('content'); ?>

	<!-- Main Content -->
	<div class="main">
		<div class="main-w3l">
			<!-- <h3 class="logo-w3">Register Now</h3> -->
			<div class="w3layouts-main">
				<h2><span>Edit Your Profile </span></h2>
                
					<form  action="<?php echo e(route('commonreg.store')); ?>" method="post" enctype="multipart/form-data" id="common_form">
						<?php echo e(csrf_field()); ?>

                     
                        <input placeholder="Date of Birth" name="dob" id="dob" type="date" >
                        <select name="gender" id="gender">
									<option value="sel"  disabled selected>Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
									 <option value="other">Other</option>
                        </select>
                        <input placeholder="Aadhar Number" name="adharno" id="adharno"   type="number" required="">
                        
                        <select name="occup" id="occup">
									<option value="sel"  disabled selected>Select Occupation</option>
                            <option value="student">Student</option>
                            <option value="employee">Employe</option>
									 <option value="other">Other</option>
                        </select> </br>  </br>
                        <input placeholder="Institute/Employer Name" name="wname" id="wname" type="text" required="">
                        <input placeholder="Photo" name="img" id="img" type="file" required="">
						<input placeholder="Aadhar Copy" name="adimg" id="adimg" type="file" required="">
						<input  name="id" type="hidden"  id="rid" value="<?php echo e($regid); ?>" >
						<input type="submit" value="Register" name="submit">
					</form>
					<script src="<?php echo e(asset('js/validate/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validate/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validate/jquery.validate.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/validate/additional-methods.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/validate/validations.js')); ?>"></script>
			</div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>