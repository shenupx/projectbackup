<?php /* H:\main project\charitty\resources\views/donor/mydonation.blade.php */ ?>
<?php $__env->startSection('content'); ?>



<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Requested Item</th>
            <th scope="col">Quatity</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $use): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <tr>
            <th scope="row">1</th>
            <td><?php echo e($use->name); ?></td>
            <td><?php echo e($use->item); ?></td>
            <td><?php echo e($use->quantity); ?></td>
            
            <?php if($use->collectstat==0): ?>
        <td><a href="<?php echo e(route('collect',$use->donation_id)); ?> " class="btn btn-success">Collected</a></td>
        <?php else: ?>
        <td><button type="button" disabled class="btn btn-danger">Collected</button></td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>