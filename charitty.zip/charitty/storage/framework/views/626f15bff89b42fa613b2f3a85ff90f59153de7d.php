<?php /* H:\main project\charitty\resources\views/admin/assignjob.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Assign Task</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col"></th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
    <tbody>
    
    <?php $__currentLoopData = $voluntee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
        <tr>
            <th scope="row">1</th>
            <td><?php echo e($reg->name); ?></td>
            <td><?php echo e($reg->email); ?></td>
            <td><?php echo e($reg->phone); ?></td> 
            <td><a href="/reqtask?id=<?php echo e($reg->id); ?>&donid=<?php echo e($donid); ?>" class="btn btn-primary" >Request Task</a></td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>