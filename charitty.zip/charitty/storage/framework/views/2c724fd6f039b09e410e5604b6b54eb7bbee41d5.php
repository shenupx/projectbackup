<?php /* H:\main project\charitty\resources\views/admin/adview_event.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Events</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Event Name</th>
            <th scope="col">Event Type</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    
    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <th scope="row">1</th>
            <td><?php echo e($evt->event_name); ?></td>
            <td><?php echo e($evt->type); ?></td>
            <td><a href="<?php echo e(route('eventdetail',$evt->event_id)); ?>" class="btn btn-primary">Get Details</a></td>
        </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>