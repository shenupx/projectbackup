<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
}); //for index page
Route::get('/about', function () {
    return view('about');
}); //for normal user about
Route::get('/gallery', function () {
    return view('gallery');
});//for normal user gallery
Route::get('/contact', function () {
    return view('contact');
}); //for normal user contact
Route::get('/news', function () {
    return view('news');
}); //for normal user news
Route::get('/validate', function () {
    return view('validations');
}) ;//for validate 
Route::get('/register','PathController@register');
Route::get('/benregi','PathController@benregi');
Route::get('/commonregi/{regid}','PathController@commonregi'); //redirect to register page
Route::get('/adminhome','PathController@adminh');
Route::get('/volhome','PathController@volh'); 
Route::get('/benhome','PathController@benh');  
Route::get('/donhome','PathController@donh'); 
Route::get('/donprofile','PathController@donprofile'); 
Route::get('/adbenview','PathController@adbenview'); 
Route::get('/benprofile','PathController@benprofile'); 
Route::get('/volprofile','PathController@volprofile'); 
Route::get('/log_in','PathController@log_in'); //redirect to login page
Route::resource('newreg','RegisterController'); //for register controller
Route::resource('logc','LoginController'); //for login controller
Route::get('/logout','\App\Http\Controllers\LoginController@logout');
Route::resource('commonreg','CommonregController');
Route::resource('benreg','BenregController');

