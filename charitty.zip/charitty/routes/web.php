<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
}); //for index page
Route::get('/about', function () {
    return view('about');
}); //for normal user about
Route::get('/gallery', function () {
    return view('gallery');
});//for normal user gallery
Route::get('/contact', function () {
    return view('contact');
}); //for normal user contact
Route::get('/news', function () {
    return view('news');
}); //for normal user news
Route::get('/validate', function () {
    return view('validations');
}) ;//for validate 
Route::get('/nregister','PathController@register');
//Route::get('/benregi','PathController@benregi');
//Route::get('/commonregi/{regid}','PathController@commonregi'); //redirect to register page

Route::get('/adbenview','RegisterController@regview'); 
Route::get('/benprofile','PathController@benprofile'); 
Route::get('/volprofile','PathController@volprofile'); 
Route::get('/log_in','PathController@log_in')->name('log_in'); //redirect to login page

Route::resource('newreg','RegisterController'); //for register controller

Route::resource('logc','LoginController'); //for login controller
Route::get('/logout','\App\Http\Controllers\LoginController@logout');
Route::resource('commonreg','CommonregController');
Route::resource('benreg','BenregController');
Route::post('/city/ajax','DistrictController@cityajax');
Route::match(['GET','Post'],'check','RegisterController@checkEmail');
Route::match(['GET','Post'],'logincheck','RegisterController@checkLogin');
Route::match(['GET','Post'],'passcheck','RegisterController@checkpasswd');
Route::any('benedit{id}','RegisterController@edit')->name('benedit'); //ben edit page
Route::any('adminedit{id}','RegisterController@adminedit')->name('adminedit');

Route::any('approve{id}','RegisterController@checkstat')->name('approve');
Route::any('block{id}','RegisterController@blockuser')->name('block');
Route::get('/adorgview','RegisterController@adorgview');
Route::get('/advolview','RegisterController@advolview');
Route::get('/addonview','RegisterController@addonview');
// Route::any('myprofile{email}','RegisterController@adminprofile')->name('myprofile');
Route::get('/adprofile','PathController@adprofile');
Route::any('/contactstore','ContactsController@store');

//Route::get('beneditp','PathController@beneditp')

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
// Admin routes
Route::any('adminupdate{id}','RegisterController@adminupdate')->name('adminupdate');
Route::get('/adminhome','PathController@adminh');
Route::any('approve{id}','RegisterController@checkstat')->name('approve');
Route::any('block{id}','RegisterController@blockuser')->name('block');
Route::get('/adscholar','PathController@adscholar');
Route::get('/adchpass','PathController@adchpass');
Route::any('/changepass','RegisterController@changepass');
Route::any('/additem','PathController@additem');
Route::any('/additems','ItemController@store');
Route::any('/requestview','PathController@requestview');
Route::any('/addevent','PathController@addevent');
Route::any('/viewevent','PathController@viewevent');
Route::any('/adevnt','EventController@store');
Route::any('eventedit{event_id}','EventController@eventedit')->name('eventedit');
Route::any('eventdetail{event_id}','EventController@eventdetail')->name('eventdetail');
Route::any('eventupdate{event_id}','EventController@eventupdate')->name('eventupdate');


//Route::any('chanpass','RegisterController@changepass')->name('changepass');
// Admin routes ends

// Donor Routes Starts
Route::get('/donhome','PathController@donh');
Route::get('/donprofile','RegisterController@profile');
Route::any('donupdate{id}','RegisterController@donproupdate')->name('donupdate');
Route::any('/passchange','RegisterController@donchangepass');
Route::any('/donchangepass','PathController@donchangepass');
Route::any('/eventsview','PathController@donviewevent');
Route::any('/viwreqt','PathController@donrequestview');
Route::any('/donfe','PathController@donfundevet');
Route::any('/mydon','PathController@mydonations');

// Route::get('/donprofile','PathController@donprofile');
// Donor Routes Ends

// Volunteer Routes Starts
Route::get('/volhome','PathController@volh'); 
Route::get('/volprofile','RegisterController@volprofile');
Route::any('volupdate{id}','RegisterController@volproupdate')->name('volupdate');
Route::any('/volchangepass','PathController@volchangepass');
Route::any('/volpass','RegisterController@volchangepass');
Route::any('/volviewevent','PathController@volviewevent');
Route::any('/volnonfund','PathController@volnonfund');
Route::any('/volfund','PathController@volfund');
Route::any('/report','PathController@report');
Route::any('/savereport','ReportController@store');
Route::any('/volreq','PathController@volrequestview');
// Volunteer Routes Ends

// Organization Routes Starts 
Route::get('/benhome','PathController@benh');
Route::any('/orgchangepass','PathController@orgchangepass');
Route::get('/benprofile','RegisterController@benprofile');
Route::any('benproupdate{id}','RegisterController@benproupdate')->name('benupdate');
Route::any('/benpass','RegisterController@benpasschange');
Route::get('/benaddmem','PathController@benaddmem');
Route::any('/addmem','AddmemberController@store');
Route::any('/requestneeds','PathController@requestneeds');
Route::any('/sendreqt','RequestneedsController@store');
Route::any('/viewstat','PathController@benreqstat');
Route::any('/viewmymem','PathController@viewmymem');
Route::any('/oldaddmem','AddmemberController@addmem');


// Organization Routes Ends
// Scholarship Controller
Route::any('/grant{sapp_id}','ScholarAppController@grantscholor')->name('grant');
Route::any('/scholar','AddscholarController@store');
Route::get('/scholarview','PathController@scholarview');
Route::any('/scholarapply{scheme_id}','PathController@scholarapply')->name('scholarapply');
Route::any('/aplyscholar','ScholarAppController@store');
Route::any('/viewschalrapp','ScholarAppController@viewschalrapp');
Route::any('/viewsholardetail{scheme_id}','ScholarAppController@viewscholardetail')->name('viewapp');
Route::any('/viewgratendstud{sid}','ScholarAppController@scholarselection')->name('selection');

Route::any('/donhome', function () {
    return view('donor.donhome');
});
Route::any('/adhome', function () {
    return view('admin.adminhome');
});
Route::any('/volhome', function () {
    return view('volunte.volhome');
});
// Scholarship Controller Ends

Route::get('/payment/{id}','PathController@paypath');
Route::get('/account','PathController@account');
Route::any('/store','BankController@store');
Route::any('/paycvb','PaymentController@store');
Route::any('/donpay','PaymentController@sponsorpayment');

Route::any('/userevent','PathController@userviewevent');
Route::any('/grantreq{request_id}','RequestneedsController@show')->name('grantreq');

Route::any('/donation','PathController@donation');

Route::any('/storedonation','DonationController@store');
Route::any('/viewdonation','DonationController@show');
Route::any('/donationdetails{donation_id}','DonationController@donationdetail')->name('donationdetails');
Route::any('/viewvolnteer{donation_id}','DonationController@viewvolunteer')->name('viewvolnteer');
Route::any('/reqtask','TblTaskrequestController@store');
Route::any('/viewdonstatus','TblTaskrequestController@viewstat');
Route::any('/viewreqnew','TblTaskrequestController@viewnewreq');

Route::any('/orphanages','PathController@donvieworphanages');
Route::any('/orphans{id}','PathController@orphans')->name('orphans');
Route::any('/sponsor{mem_id}','SponsorshipController@store')->name('sponsor');
Route::any('/acceptreq{req_id}','TblTaskrequestController@acceptreq')->name('acceptreq');
Route::any('/rejectreq{req_id}','TblTaskrequestController@rejectreq')->name('rejectreq');
Route::any('/viewacceptreq','TblTaskrequestController@viewacceptreq');
Route::any('/viewmydonation','TblTaskrequestController@viewmydonation');
Route::any('/collect{donation_id}','TblTaskrequestController@collected')->name('collect');
Route::any('/donationforme','TblTaskrequestController@donationforme');
Route::any('/dropping{donation_id}','TblTaskrequestController@dropping')->name('dropping');
Route::any('/oldhome','PathController@oldageview');
Route::any('/oldageh{id}','PathController@oldageh')->name('oldageh');
Route::any('/completedtask','TblTaskrequestController@completedtask');



