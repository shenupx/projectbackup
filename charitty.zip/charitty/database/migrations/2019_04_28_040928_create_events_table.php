<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {
            $table->bigIncrements('event_id');
            $table->string('event_name');
            $table->biginteger('tye_id')->unsigned();
            $table->foreign('tye_id')->references('tye_id')->on('type_events');
            $table->string('event_detail');
            $table->string('amount');
            $table->string('no_person');
            $table->date('edate');
            $table->string('etime');
            $table->string('eplace');
            $table->string('icon');
            $table->string('damount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events');
    }
}
