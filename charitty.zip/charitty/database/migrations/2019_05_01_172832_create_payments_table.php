<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->bigIncrements('pay_id');
            $table->string('email');
            $table->biginteger('event_id')->unsigned()->nullable();
            $table->foreign('event_id')->references('event_id')->on('events');
            $table->biginteger('id')->unsigned()->nullable();
            $table->foreign('id')->references('id')->on('registers');
            $table->string('amount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
