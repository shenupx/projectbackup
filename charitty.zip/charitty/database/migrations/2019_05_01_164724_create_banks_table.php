<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBanksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('banks', function (Blueprint $table) {
            $table->bigIncrements('bank_id');
            $table->string('bankname');
            $table->string('branchname');
            $table->string('acholder');
            $table->string('acnumber');
            $table->string('ifsc');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->biginteger('card_id')->unsigned()->nullable();
            $table->foreign('card_id')->references('card_id')->on('tbl_cardtype');
            $table->string('coname')->nullable();
            $table->string('cardnumber')->nullable();
            $table->string('cvv')->nullable();
            $table->biginteger('mnth_id')->unsigned()->nullable();
            $table->foreign('mnth_id')->references('mnth_id')->on('tbl_month');
            $table->biginteger('yid')->unsigned()->nullable();
            $table->foreign('yid')->references('yid')->on('tbl_year');
            $table->string('balance')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('banks');
    }
}
