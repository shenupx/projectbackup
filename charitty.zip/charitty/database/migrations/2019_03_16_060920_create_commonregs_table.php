<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommonregsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('commonregs', function (Blueprint $table) {
            $table->bigIncrements('crid');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->date('dob');
            $table->string('gender');
            $table->string('adharno');
            $table->string('occup');
            $table->string('wname');
            $table->string('img');
            $table->string('adimg');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('commonregs');
    }
}
