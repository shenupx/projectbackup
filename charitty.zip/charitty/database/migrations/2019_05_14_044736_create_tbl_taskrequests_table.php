<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblTaskrequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_taskrequests', function (Blueprint $table) {
            $table->bigIncrements('req_id');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->biginteger('donation_id')->unsigned();
            $table->foreign('donation_id')->references('donation_id')->on('donations');
            $table->biginteger('reqstatus');
            $table->biginteger('accept');
            $table->biginteger('onduty');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_taskrequests');
    }
}
