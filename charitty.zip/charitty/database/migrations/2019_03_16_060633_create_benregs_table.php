<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBenregsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('benregs', function (Blueprint $table) {
            $table->bigIncrements('brid');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->date('sdate');
            $table->string('owner');
            $table->integer('nop');
            $table->string('btype');
            $table->string('place');
            $table->string('cero');
            $table->string('cert');
            $table->string('certt');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('benregs');
    }
}
