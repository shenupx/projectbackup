<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddmembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addmembers', function (Blueprint $table) {
            $table->bigIncrements('mem_id');
            $table->string('name');
            $table->date('dob');
            $table->string('adharno');
            $table->string('yexpense');
            $table->string('spon_stat');
            $table->string('image');
            $table->biginteger('couse_id')->unsigned()->nullable();
            $table->foreign('couse_id')->references('couse_id')->on('course');
            $table->string('iname')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addmembers');
    }
}
