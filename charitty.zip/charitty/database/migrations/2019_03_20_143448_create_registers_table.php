<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->biginteger('district_id')->unsigned();
            $table->foreign('district_id')->references('district_id')->on('tbl_district');
            $table->string('type');
            $table->date('sdate')->nullable();
            $table->string('owner')->nullable();
            $table->string('btype')->nullable();
            $table->string('ocb')->nullable();
            $table->string('dob')->nullable();
            $table->string('gender')->nullable();
            $table->string('adharno')->nullable();
            $table->string('occup')->nullable();
            $table->string('wname')->nullable();
            $table->string('img')->nullable();
            $table->string('adimg')->nullable();
            $table->string('remember_token')->nullable();
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registers');
    }
}
