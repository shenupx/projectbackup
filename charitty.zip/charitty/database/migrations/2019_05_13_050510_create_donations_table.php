<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDonationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('donations', function (Blueprint $table) {
            $table->bigIncrements('donation_id');
            $table->string('email');
            $table->biginteger('item_id')->unsigned()->nullable();
            $table->foreign('item_id')->references('item_id')->on('items');
            $table->string('specitem');
            $table->biginteger('quantity');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->biginteger('district_id')->unsigned();
            $table->foreign('district_id')->references('district_id')->on('tbl_district');
            $table->biginteger('volid');
            $table->integer('collectstat');
            $table->integer('deliverystat');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('donations');
    }
}
