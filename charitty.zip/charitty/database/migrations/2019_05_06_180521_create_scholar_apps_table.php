<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScholarAppsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('scholar_apps', function (Blueprint $table) {
            $table->bigIncrements('sapp_id');
            $table->biginteger('mem_id')->unsigned();
            $table->foreign('mem_id')->references('mem_id')->on('addmembers');
            $table->string('percent');
            $table->biginteger('scheme_id')->unsigned();
            $table->foreign('scheme_id')->references('scheme_id')->on('addscholars');
            $table->stirng('certificate');
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('scholar_apps');
    }
}
