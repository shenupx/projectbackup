

jQuery().ready(function(){
    //alert("test");
    jQuery("#reg_form").validate({
        rules:{
            name:{
                required:true,
                lettersonly: true,
                minlength:4

            },
            password:{
                required:true,
                minlength:8,
                pwcheck: true
            },
            phone:{
                required:true,
                phoneno:true
            },
            email:{
                required:true,
                email:true,
                remote:"/check"
            },
            type: { valueNotEquals:"sel" },
            state:{valueNotEquals:"0"},
            district:{valueNotEquals:"0"},

            sdate:{
                required:true,
                minAge:18
           },
            owner:{
                required:true,
                lettersonly: true,
                minlength:4
            },

            nop:{
                required:true,
                nop:true
            },
            btype:{valueNotEquals:"sel"},

            place:{
                required:true,
                lettersonly: true,
                minlength:4
            },

            dob:{
                required:true,
                minAge:18
            },

            gender:{ valueNotEquals: "gender" },

            adharno:{
                required:true,
                nop:true
            },

            occup:{ valueNotEquals: "sel" },

            wname:{
                required:true,
                lettersonly: true,
                minlength:4
            }



        },
        messages:{

            wname:{
                required: "Please enter the Employee/institute name",
                lettersonly: "Only alphabets allowed",
                minlength: "place must contain atleast 4 charachter"
            }, 

            occup:{
                valueNotEquals: "Select Your occupation"
            },

            adharno:{
                required:"Enter a number",
                nop:"Enter in digits"
            },

            gender:{
                valueNotEquals: "Select Your Gender"
            },

            dob:{
                required: "Please enter your Date of Birth",
                minAge: "You Must be atleast 18 years old"
            },


            place:{
                required: "Please enter place",
                lettersonly: "Only alphabets allowed",
                minlength: "place must contain atleast 4 charachter"
            }, 

            district:{ valueNotEquals:"Please Select Organization Type" },

            nop:{
                required:"Enter a number",
                nop:"Enter in digits"
            },

            owner:{
                required: "Please enter owner name",
                lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 4 charachter"
            }, 

            sdate:{
                required: "Please enter starting date",
                minAge: "Should be minimum 5 years"
            },
            name:{
                required: "Please enter your name",
                lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 4 charachter"
            }, 
            password:{
                required:"Plese provide Your Password",
                minlength:"Your Password must be Atleast 8 charachters long",
                pwcheck:"Atleast 1 character and 1 digit"
            },
            email:{
                required: "Please enter your Email",
                email: "Please enter valid Email",
                remote: "Email already exist"
                
            },
            type:{ valueNotEquals:"Please Select Your Type" },
            state:{ valueNotEquals:"Please Select State" },
            district:{ valueNotEquals:"Please Select State" }
        }

    });


   jQuery('#myPassword').passtrength({
        minChars: 4,
        passwordToggle: true,
        tooltip: true,
        eyeImg : "images/eye.svg"
      });

// for common registration
//  jQuery("#log_form").validate({
//         rules:{
//             email:{
//                 required:true,
//                 email:true,
//                 remote:"/logincheck"
//             }
//         },
//         messages:{
//             email:{
//                 required: "Please enter your Email",
//                 email: "Email do not Exist",
//                // remote: "Email already exist"
                
//             }
//         }

//     });
    //common registration ends
    // ben registration start
    //     jQuery("#ben_regform").validate({
    //     rules:{
    //         sdate:{
    //             required:true,
    //             minAge: 5

    //         },
    //         owner:{
    //             required:true,
    //             lettersonly: true,
    //             minlength:4

    //         },
    //         nop:{
    //             required:true,
    //             digits:true,
    //             minlength:10
    //         },
    //         btype:{ valueNotEquals: "btype"  },
    //         place:{
    //             required:true,
    //         }
    //     },
    //     messages:{
    //         sdate:{
    //             required: "select Starting Date",
    //             minAge: "The organization should be 5 year experience"
    //         },
    //         owner:{
    //             required: "Please enter owner name",
    //             lettersonly: "Only alphabets allowed",
    //             minlength: "Your name must contain atleast 4 charachter"
    //         },
    //         nop:{
    //             required: "Enter Number of persons in your organization",
    //             isNumber: "It should be a number",
    //             minlength:"minimum 10 members required"
    //         },
    //         btype:{
    //             valueNotEquals:"Select Your type"
    //         },
    //         place:{
    //             required: "Place Required"
    //         }
    //     }

    // });

    //ben registration ends
});
 











//  jQuery().ready(function(){
//     //alert("test");
//     jQuery("#reg_form").validate({
//         rules:{
//             name:{
//                 required:true,
//                 lettersonly: true,
//                 minlength:4

//             }
//         },
//         messages:{
//             name:{
//                 required: "Please enter your name",
//                 lettersonly: "Only alphabets allowed",
//                 minlength: "Your name must contain atleast 2 charachter"
//             }
//         }

//     });
// });



