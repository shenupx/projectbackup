@extends('layouts.userheader')
@section('content')
<link rel="stylesheet" href="admin/css/style4.css">

<section class="cards-section">
<div class="card-columns">
@foreach($event as $evt)

<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/event/{{$evt->icon}}" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title">{{$evt->event_name}}</h5>
    <p class="card-text">{{$evt->event_detail}}</p>
            <!-- Modal -->
   
        </div>
    </div>
   
    </div>
    @endforeach
</section>

@endsection