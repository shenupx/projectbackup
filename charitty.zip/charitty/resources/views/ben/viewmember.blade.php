@extends('layouts.benheader')
@section('content')


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests Status</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Name</th>
            <th scope="col">Date of Birth</th>
            <th scope="col">Gender</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    @foreach($data as $use)
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$use->name}}</td>
            <td>{{$use->dob}}</td>
            <td>{{$use->gender}}</td>
            
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal{{$use->mem_id}}">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal{{$use->mem_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{$use->name}} </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <img class="card-img-top" src="../../../storage/member/{{$use->image}}" alt="Card image cap">

                    <p class="paragraph-agileits-w3layouts mt-3">
                    Date of Birth: {{$use->dob}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Gender : {{$use->gender}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Yearly Expense : {{$use->yexpense}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Aadhar Number : {{$use->adharno}} </p>
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    
                </div>
            </div>
        </div>
       
        @endforeach
    </tbody>
</table>


@endsection