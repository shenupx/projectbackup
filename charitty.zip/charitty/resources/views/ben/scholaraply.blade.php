@extends('layouts.benheader')
@section('content')

<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
<h4 class="card-header">Scholarship Application </h4> <br>
<form action="/aplyscholar" method="post" enctype="multipart/form-data">
@csrf
    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Select Student</label>
        <div class="col-sm-10">
        <select id="item_id" name="mem_id" class="form-control">
    <option value="#" disabled selected>Select Student</option>
        @foreach($mem as $cc)
        <option value="{{$cc->mem_id}}">{{$cc->name}} </option>
        @endforeach
       
</select>

</div>
            </div>
            
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Percentage</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="percentage" name="percentage" placeholder="Enter Aggregate Percentage" required>
                </div>
              <br><br>
                <label for="inputPassword3" class="col-sm-2 col-form-label">Upload Certificate</label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="cert" name="cert"  required>
                </div>
                <input type="hidden" class="form-control" id="sid" name="sid" value="{{$sid}}" >

            </div>   
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Apply</button>
                </div>
            </div>
        </form>
        </div>
@endsection