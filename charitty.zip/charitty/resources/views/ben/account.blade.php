@extends('layouts.benheader')
@section('content')
<div class="outer-w3-agile col-xl mt-3">
    <h4 class="tittle-w3-agileits mb-4">Add Account Details</h4>
    <form action="/store" method="post">
    @csrf
        <div class="form-group">
            <label for="curpass">Bank Name </label>
            <input type="text" class="form-control" name="bank" id="bank" placeholder="Bank Name" required=""> 
        </div>
        <div class="form-group">
            <label for="curpass">Branch Name </label>
            <input type="text" class="form-control" name="branch" id="branch" placeholder="Branch Name" required=""> 
        </div>
        <div class="form-group">
            <label for="curpass">Account Holder Name </label>
            <input type="text" class="form-control" name="ahname" id="ahname" placeholder="Account Holder Name" required=""> 
        </div>
             <div class="form-group">
            <label for="newpass">Account  Number</label>
            <input type="text" class="form-control" id="acnum" name="acnum" placeholder="Account Number" required=""> 
        </div>
        <div class="form-group">
            <label for="newpass">IFSC Code</label>
            <input type="text" class="form-control" id="ifsc" name="ifsc" placeholder="ifsc code" required=""> 
        </div>
        <button class="btn btn-primary btn-lg btn-block " type="submit">Add Bank Details</button>

    </form>
</div>
@endsection