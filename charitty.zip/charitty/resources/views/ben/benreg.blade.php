@extends('layouts.userheader')
<?php
//use App\Register;
?>
<link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" />

   @section('content')

	<!-- Main Content -->
	<div class="main">
		<div class="main-w3l">
			<!-- <h3 class="logo-w3">Register Now</h3> -->
			<div class="w3layouts-main">
				<h2><span>Edit Your Profile</span></h2>
					<form  action="{{route('benreg.store')}}" method="post" enctype="multipart/form-data" id="ben_regform">
					{{ csrf_field() }}
                        <input placeholder="Starting Date" name="sdate" id="sdate" type="date" >
						<input placeholder="Owner Name" name="owner" id="owner" type="text" required="">
                       
						<input placeholder="Number of Persons" name="nop" id="nop" type="number" required="">
                        <select name="btype" id="btype">
									<option value="sel"  disabled selected>Select Type</option>
                            <option value="orphanage">Orphanage</option>
                            <option value="oldhome">Oldage Home</option>
                        </select> </br>  </br>
                        <input placeholder="Place" name="place" id="place" type="text" required="">
                        <input placeholder="certicate1" name="cero" id="cero" type="file" required="">
						<input placeholder="certicate3" name="cert" id="cert" type="file" required="">
                        <input placeholder="certicate3" name="certt" id="certt" type="file" required="">
						<input  name="id" type="hidden"  id="rid" value="{{ $regid }}" >
						<input type="submit" value="Register" name="submit">
					</form>
					<script src="{{ asset('js/validate/jquery.js') }}"></script>
    <script src="{{ asset('js/validate/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/validate/jquery.validate.min.js') }}"></script>
	<script src="{{ asset('js/validate/additional-methods.min.js') }}"></script>
	<script src="{{ asset('js/validate/validations.js') }}"></script>
	<script src="js/main.js"></script>
	<script src="js/passtrength.js"></script>
			</div>

   @endsection