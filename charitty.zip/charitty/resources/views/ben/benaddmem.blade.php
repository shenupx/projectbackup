@extends('layouts.benheader')
@section('content')
<script src="js/jquery.js"></script>
<script src="js/jquery.validate.min.js"></script> 
	
	<script src="js/passtrength.js"></script>
<div class="outer-w3-agile mt-3">
    <h4 class="tittle-w3-agileits mb-4">Add New Member</h4>
    <form action="/oldaddmem" method="post" enctype="multipart/form-data" id="mem_add">
    @csrf
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="scheme">Member Name</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Name of Member" required="">
            </div>
            <div class="form-group col-md-6">
                <label for="scheme">Date of Birth</label>
                <input type="date" name="dob" class="form-control" id="dob" placeholder="Date of Birth" required="">
            </div>
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
                <label for="">Gender</label>
                <select id="gender" name="gender" class="form-control" required>
                <option value="0" disabled selected>Select Gender</option>
                <option value="male"> Male</option>
                <option value="female"> Female</option>
                </select>

            </div>
            <div class="form-group col-md-6">
                <label for="scheme">Aadhar Number</label>
                <input type="text" name="adharno" class="form-control" id="adharno" placeholder="Aadhar Number of Member" required="">
            </div>
            
        </div>
        <div class="form-row">
        <div class="form-group col-md-6">
                <label for="scheme">Yearly Expense</label>
                <input type="text" name="yexpense" class="form-control" id="yexpense" placeholder="Yearly Expense of member" required="">
            </div>
            <div class="form-group col-md-6">
                <label for="scheme">Image</label>
                <input type="file" name="img" class="form-control" id="img" placeholder="Member Image" required="">
            </div>
            </div>
        
                <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
    </form>
</div>
                <script>
jQuery().ready(function(){
    //alert("test");
    jQuery("#mem_add").validate({
			rules:{
            name:{
                required:true,
                lettersonly: true,
                minlength:4
                
            }
        },
        messages:{
            name:{
                required: "Please enter your name",
                lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 4 charachter"
                
            }
        }

			});
		});
	</script>
@endsection