@extends('layouts.userheader')
@section('content')

<link rel="stylesheet" href="login/css/style.css" type="text/css" media="all" />

<link rel="stylesheet" href="login/css/fontawesome-all.css">
<body>
	
	<!-- content -->
	<div class="sub-main-w3">
		<form action="{{route('logc.store')}}" method="POST" id="log_form">
			@csrf
			<div class="form-style-agile">
				<label>
					Username
					<i class="fas fa-user"></i>
				</label>
				<input placeholder="Email" name="email" id="email" type="email" required="" >
			</div>
			<div class="form-style-agile">
				<label>
					Password
					<i class="fas fa-unlock-alt"></i>
				</label>
				<input placeholder="Password" name="password" id="password" type="password" required="">
			</div>
			<!-- checkbox -->
			<div class="wthree-text">
				<ul>
					<li>
						<!-- switch -->
						<div class="checkout-w3l">
							<div class="demo5">
								<div class="switch demo3">
									<input type="checkbox">
									<label>
										<i></i>
									</label>
								</div>
							</div>
							<a href="#">Stay Signed In</a>
						</div>
						<!-- //checkout -->
					</li>
					<li>
						<a href="#">Forgot Password?</a>
					</li>
				</ul>
			</div>
			<!-- //switch -->
			<input type="submit" value="Log In">
		</form>
		<!-- <script src="{{ asset('js/validate/jquery.js') }}"></script>
    <script src="{{ asset('js/validate/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/validate/jquery.validate.min.js') }}"></script>
	<script src="{{ asset('js/validate/additional-methods.min.js') }}"></script>
	<script src="{{ asset('js/validate/validations.js') }}"></script> -->
	</div>

   @endsection