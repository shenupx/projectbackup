
@extends('layouts.donheader')
@section('content')

<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Orphanages</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Email Id</th>
            <th scope="col">Phone</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    @foreach($orphanages as $use)
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$use->name}}</td>
            <td>{{$use->email}}</td>
            <td>{{$use->phone}}</td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal{{$use->id}}">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal{{$use->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{$use->name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <img src="../../../storage/profile/{{$use->img}}" class="img-fluid" alt="Responsive image">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Email : {{$use->email}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Phone : {{$use->phone}} </p>
                    
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <a href="{{route('orphans',$use->id)}}" class="btn btn-primary">View Members</a>
                </div>
            </div>
        </div>
        @endforeach
    </tbody>
</table>
@endsection