@if(session()->has('email'))

<!DOCTYPE html>
<html>
<head>
<title>Sponsor</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="http://127.0.0.1:8000/pay/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="http://127.0.0.1:8000/pay/css/creditly.css" type="text/css" media="all" />
<link rel="stylesheet" href="http://127.0.0.1:8000/pay/css/easy-responsive-tabs.css">
<script src="http://127.0.0.1:8000/pay/js/jquery.min.js"></script>
</head>
<body>
	<div class="main">	
	<div class="w3_agile_main_grids">
			<div class="agile_main_top_grid">
				<div class="agileits_w3layouts_main_top_grid_left">
					<a href="/donfe"><img src="http://127.0.0.1:8000/pay/images/1.png" alt=" " /></a>
				</div>
				@include('flash-message')
				<div class="w3_agileits_main_top_grid_right">
					<h3>Checkout Form</h3>
				</div>
				<div class="clear"> </div>
				<!-- <div class="wthree_total">
					<h2>total to pay <span><i>Rs.</i>	<input class=" form-control" type="text" name="amount"></span></h2>
				</div> -->
			</div>
			<div class="agileinfo_main_bottom_grid">
				<div id="horizontalTab">
					<ul class="resp-tabs-list">
						<li><img src="http://127.0.0.1:8000/pay/images/1.jpg" alt=" " /></li>
						<li><img src="http://127.0.0.1:8000/pay/images/2.jpg" alt=" " /></li>
					</ul>
					<div class="resp-tabs-container">
						<div class="agileits_w3layouts_tab1">
							<!-- form starts -->
							
							<div class="wthree_total">
					<h2>total to pay <span><i>Rs.</i>	<input  type="text"  value="{{$amount}}" disabled  name="sponsefee" /></span></h2>
				</div>
								<section class="creditly-wrapper wthree, w3_agileits_wrapper">
									<div class="credit-card-wrapper">
										<div class="first-row form-group">
										<div class="controls">
										<form action="/donpay" method="post" class="creditly-card-form agileinfo_form">
							@csrf
							<input  type="hidden"  value="{{$amount}}"   name="amountnew" />
										<input class="billing-address-name form-control" type="hidden" name="eid"  value="">
													<input type="hidden" name="sponsid" value="{{$sopons}}" />
												<label class="control-label">Card Type</label>
												<Select class="billing-address-name form-control" type="text" id="ctype" name="ctype" required>
													<option value="" disabled >Card Type</option>
													@isset($card)
													@foreach($card as $cc)
													<option value="{{$cc->card_id}}">{{$cc->card}} </option>
													@endforeach
													@endisset
												</select>
											</div>
											<div class="controls">
												<label class="control-label">Name on Card</label>
												<input class="billing-address-name form-control" type="text" name="name" placeholder="Name on the card" required>

											</div>
											<div class="w3_agileits_card_number_grids">
												<div class="w3_agileits_card_number_grid_left">
													<div class="controls">
														<label class="control-label">Card Number</label>
														<input class="number credit-card-number form-control" type="text" name="cnumber"
																	  inputmode="numeric"  autocomplete="cc-number" autocompletetype="cc-number" x-autocompletetype="cc-number" required
																	  placeholder="&#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149;">
													</div>
												</div>
												<div class="w3_agileits_card_number_grid_right">
													<div class="controls">
														<label class="control-label">CVV</label>
														<input class="security-code form-control"Â·
																	  inputmode="numeric" 
																	  type="text" name="cvv" required
																	  placeholder="&#149;&#149;&#149;">
													</div>
												</div>
												<div class="clear"> </div>
											</div>
											<div class="w3_agileits_card_number_grids">
												<div class="w3_agileits_card_number_grid_left">
													<div class="controls">
														<label class="control-label">Expery Month</label>
														<Select class="billing-address-name form-control" type="text" name="emonth" required>
														<option value="" disabled >-- Month --</option>
													@isset($month)
													@foreach($month as $month)
													<option value="{{$month->mnth_id}}">{{$month->month}} </option>
													@endforeach
													@endisset
												</select>
													</div>
												</div>
												<div class="w3_agileits_card_number_grid_right">
													<div class="controls">
														<label class="control-label">Expiry Year</label>
														<Select class="billing-address-name form-control" type="text" name="eyear" required>
														<option value="" disabled >-- Year --</option>
														@isset($year)
													@foreach($year as $year)
													<option value="{{$year->yid}}">{{$year->year}} </option>
													@endforeach
													@endisset
												</select>
														
													</div>
												</div>
												<div class="clear"> </div>
											</div>
										</div>
										<button class="btn btn-primary" type="submit">Make  payment</button>
									</div>
								</section>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<!-- credit-card -->
		<script type="text/javascript" src="http://127.0.0.1:8000/pay/js/creditly.js"></script>
		<script type="text/javascript">
			$(function() {
			  var creditly = Creditly.initialize(
				  '.creditly-wrapper .expiration-month-and-year',
				  '.creditly-wrapper .credit-card-number',
				  '.creditly-wrapper .security-code',
				  '.creditly-wrapper .card-type');

			  $(".creditly-card-form .submit").click(function(e) {
				e.preventDefault();
				var output = creditly.validate();
				if (output) {
				  // Your validated credit card output
				  console.log(output);
				}
			  });
			});
		</script>
	<!-- //credit-card -->
	<!-- tabs -->
	<script src="http://127.0.0.1:8000/pay/js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true,   // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function(event) { // Callback function if tab is switched
				var $tab = $(this);
				var $info = $('#tabInfo');
				var $name = $('span', $info);
				$name.text($tab.text());
				$info.show();
				}
			});
		});
	</script>
	<!-- //tabs -->
</body>
</html>
@endif