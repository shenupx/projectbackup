@extends('layouts.donheader')
@section('content')
<div class="outer-w3-agile col-xl mt-3">
    <h4 class="tittle-w3-agileits mb-4">Change Password</h4>
    <form action="/passchange" method="get">
    @csrf
        <div class="form-group">
            <label for="curpass">Current Password </label>
            <input type="password" class="form-control" name="curpass" id="curpass" pattern=".{8,}" title="Eight or more characters" placeholder="Current Password" required> 
        </div>
                <div class="form-group">
            <label for="newpass">New Password</label>
            <input type="password" class="form-control" id="newpass" name="newpass" pattern=".{8,}" title="Eight or more characters" placeholder="New Password" require> 
        </div>
        <div class="form-group">
            <label for="newpass">Confirm Password</label>
            <input type="password" class="form-control" id="conpass" name="conpass" pattern=".{8,}" title="Eight or more characters" placeholder="Confirm Password" required> 
        </div>
        <button class="btn btn-primary btn-lg btn-block " type="submit">Change Password</button>

    </form>
</div>
@endsection