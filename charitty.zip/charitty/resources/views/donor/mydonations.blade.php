@extends('layouts.donheader')
@section('content')


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">My donations</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Date</th>
            <th scope="col">Amount</th>
            <th scope="col">To</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    @foreach($mydon as $use)
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$use->created_at}}</td>
            <td>{{$use->namount}}</td>
            <td>{{$use->event_name}}</td>
            </tr>
            
            @endforeach
    </tbody>
</table>



@endsection