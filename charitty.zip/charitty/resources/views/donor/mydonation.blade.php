
@extends('layouts.donheader')
@section('content')



<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Requested Item</th>
            <th scope="col">Quatity</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    @foreach($data as $use)
    
        <tr>
            <th scope="row">1</th>
            <td>{{$use->name}}</td>
            <td>{{$use->item}}</td>
            <td>{{$use->quantity}}</td>
            
            @if($use->collectstat==0)
        <td><a href="{{route('collect',$use->donation_id)}} " class="btn btn-success">Collected</a></td>
        @else
        <td><button type="button" disabled class="btn btn-danger">Collected</button></td>
        @endif
    </tr>
@endforeach
    </tbody>
</table>

@endsection