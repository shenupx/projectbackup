@extends('layouts.donheader')
@section('content')

<script src="js/jquery.js"></script>

<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
<h4 class="card-header">Donate </h4> <br>
<form action="/storedonation" method="post">
@csrf
    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">I Donate </label>
        <div class="col-sm-10">
        <select id="item_id" name="item_id" class="form-control" required>
    <option value="" disabled>Select item</option>
       

        @foreach($items as $cc)
        <option value="{{$cc->item_id}}">{{$cc->item}} </option>
        @endforeach
        <br> <option value="0">Others </option>
</select>

</div>
            </div>
            <script>
        
        jQuery(document).ready(function(){
            jQuery('select').change(function(){
                if(jQuery('select option:selected').val() == "0"){
                    jQuery('html select').after("<label>Specify Item to donate</label><input type='text' name='specific' class='form-control' id='specific' placeholder='Specify Your Need' required />");
                    
                }
                // else if(jQuery('select option:selected').val() == "8"){
                //     jQuery('html select').after("<label>Enter Amount</label><input type='text' name='specific' class='form-control' id='specific' placeholder='Specify Your Need' />");

                // }
                else{   

                }
            })
        });
    </script> 
   
            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="quatity" name="quatity" placeholder="Enter How Much You Want" required>
                </div>
            </div>          
            <div class="form-group row">
                <label for="days" class="col-sm-2 col-form-label">To</label>
                <div class="col-sm-10">
                <select id="organization" name="organization" class="form-control" required>
    <option value="" disabled>Select Organization</option>
       

        @foreach($user as $user)
        <option value="{{$user->id}}">{{$user->name}} </option>
        @endforeach
        <br> <option value="0">Anybody </option>
</select> 
<br><br></div></div>
<div class="form-group row">
                <label for="days" class="col-sm-2 col-form-label">Select Current Location</label>
                <div class="col-sm-10">
                <select id="district_id" name="district_id" class="form-control" required>
    <option value="" disabled >Select Current District</option>
       

        @foreach($dist as $dist)
        <option value="{{$dist->district_id}}">{{$dist->district_name}} </option>
        @endforeach
        
</select> 
<br><br>
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">SEND</button>
                </div>
            </div>
        </form>
    </div>

@endsection