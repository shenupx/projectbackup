
@extends('layouts.donheader')
@section('content')


<section class="cards-section">
<div class="card-columns">
@foreach($members as $evt)

<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/member/{{$evt->image}}" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title">{{$evt->name}}</h5>
    <p class="card-text">Date of Birth : {{$evt->dob}}</p>
    <a href="#" class="btn more mt-3" data-toggle="modal" data-target="#exampleModal{{$evt->mem_id}}">Read More</a>
            <!-- Modal -->
    <div class="modal fade" id="exampleModal{{$evt->mem_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel1">{{$evt->name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                            </button>
                </div>
                <div class="modal-body">
                    <img class="card-img-top" src="../../../storage/member/{{$evt->image}}" alt="Card image cap">
                    <p class="paragraph-agileits-w3layouts ">Date of Birth: {{$evt->dob}}</p>
                    <p class="paragraph-agileits-w3layouts ">Gender : {{$evt->gender}}</p>
                    
                    <p class="paragraph-agileits-w3layouts ">Adhar Number :{{$evt->adharno}}</p>
                    <p class="paragraph-agileits-w3layouts ">Yearly Expense :{{$evt->yexpense}}</p>
                    <a href="{{route('sponsor',$evt->mem_id)}}" class="btn more mt-3" >Become a Sponsor</a>
                   

                   

                </div>
            </div>
        </div>
    </div>
    <!-- /Modal -->
        </div>
    </div>
    </div>
    @endforeach
</section>


@endsection