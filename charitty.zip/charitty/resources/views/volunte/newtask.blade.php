@extends('layouts.volheader')
@section('content')
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> New Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Donor name</th>
            <th scope="col">Item Name</th>
            <th scope="col">District</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    
    @foreach($myreq as $reg)
            
        <tr>
            <th scope="row">1</th>
            <td>{{$donname}}</td>
            <td>{{$reg->item}}</td>
            <td>{{$reg->district_name}}</td>
            <td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal{{$reg->req_id}}">Get Details</button></td>
        </tr>
            <div class="modal fade" id="exampleModal{{$reg->req_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Donor Name: {{$donname}}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="paragraph-agileits-w3layouts mt-3">
                Item Name: {{$reg->item}}  </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                District Name : {{$reg->district_name}} </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                email Id: {{$reg->email}} </p>
                <p class="paragraph-agileits-w3layouts mt-3">
                Phone : {{$reg->phone}} </p>
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="{{route('acceptreq',$reg->req_id)}}" class="btn btn-primary">Accept</a>
                <a href="{{route('acceptreq',$reg->req_id)}}" class="btn btn-danger">Reject</a>
            </div>
        </div>
    </div>
    </tbody>
    @endforeach
</table>
@endsection