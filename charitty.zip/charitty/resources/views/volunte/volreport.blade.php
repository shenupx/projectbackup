@extends('layouts.volheader')
@section('content')
<meta name="csrf-token" content="{{ csrf_token()}}">
<!-- <link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" /> -->

<script src="js/jquery.js"></script>
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="card-header">Report Street Peoples</h4> <br>

    <form action="/savereport" method="post" enctype="multipart/form-data">
    @csrf
    <div class="form-group row">
    <label for="state" class="col-sm-2 col-form-label"> State </label>
    <div class="col-sm-10">
		<select name="state" id="state" class="form-control" required>
		<option value=""  >Select your State</option>
		@isset($data)
		@foreach($data as $state)
		<option value="{{$state->state_id}}">{{$state->state_name}} </option>
		@endforeach
		@endisset
        </select> </br>  </br>
</div>
</div>
<div class="form-group row">
    <label for="district" class="col-sm-2 col-form-label"> District </label>
    <div class="col-sm-10">
    <select name="district" id="district" class="form-control" required>
           <option value=""  >Select your District</option>
    </select> </br>  </br>
</div>
</div>  
<div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Details</label>
    <div class="col-sm-10">
        <textarea class="form-control" id="details" name="details" placeholder=" Details" required></textarea>
    </div>
</div>    
    <div class="form-group row">
    <label for="" class="col-sm-2 col-form-label">land Mark </label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="lmark" name="lmar" placeholder="Land Mark" required>
        </div>    
</div>         
<div class="form-group row">
    <label for="" class="col-sm-2 col-form-label">Upload Image </label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="image" name="image" placeholder="" required>
        </div>    
</div>
    <div class="form-group row">
        <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Report</button>
        </div>
        </div>
    </form>
</div>
<script src="js/validate/jquery.js"></script>
		<script src="js/ajax.js"></script>
   
@endsection