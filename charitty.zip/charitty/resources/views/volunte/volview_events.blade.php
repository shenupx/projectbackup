@extends('layouts.volheader')
@section('content')


<section class="cards-section">
<div class="card-columns">
@foreach($event as $evt)

<div style="float:left">
<div class="card " >
<img class="card-img-top" src="../../../storage/event/{{$evt->icon}}" alt="Card image cap">
<div class="card-body">
    <h5 class="card-title">{{$evt->event_name}}</h5>
    <p class="card-text">{{$evt->event_detail}}</p>
    <a href="#" class="btn more mt-3" data-toggle="modal" data-target="#exampleModal{{$evt->event_id}}">Read More</a>
            <!-- Modal -->
    <div class="modal fade" id="exampleModal{{$evt->event_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel1">{{$evt->event_name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                            </button>
                </div>
                <div class="modal-body">
                    <img class="card-img-top" src="../../../storage/event/{{$evt->icon}}" alt="Card image cap">
                    <p class="paragraph-agileits-w3layouts ">{{$evt->type}}</p>
                    <p class="paragraph-agileits-w3layouts ">{{$evt->event_detail}}</p>
                    @if($evt->tye_id==1)
                    <p class="paragraph-agileits-w3layouts ">Goal Rs.{{$evt->amount}}</p>
                    <p class="paragraph-agileits-w3layouts ">Target Date{{$evt->edate}}</p>
                    <a href="" class="btn more mt-3" >Donate Now</a>
                    @else
                    <p class="paragraph-agileits-w3layouts ">No.of Volunteers Needed :{{$evt->no_person}}</p>
                    <p class="paragraph-agileits-w3layouts ">Event Date:{{$evt->edate}}</p>
                    <a href="" class="btn more mt-3" >Become a Volunteer</a>

                    @endif

                </div>
            </div>
        </div>
    </div>
    <!-- /Modal -->
        </div>
    </div>
   
    </div>
    @endforeach
</section>


@endsection