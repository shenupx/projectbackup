@extends('layouts.volheader')
@section('content')
<section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                      
<?php
use App\Register;
$sess=session()->get('email');
$a=Register::where('email',$sess)->get();

foreach($a as $object)
{
    $id=$object->id;
    $name=$object->name;
    $email=$object->email;
    $phone=$object->phone;
    $state=$object->state;
    $dist=$object->dist;
  
   //echo "<p>" .+ echo $name; .+"{{csrf_field(0}} </p>"; 
}
?>

<p> Name: <?php echo $name; ?> {{csrf_field()}} </p>
<p> Email: <?php echo $email; ?> {{csrf_field()}} </p>
<p> Phone : <?php echo $phone; ?> {{csrf_field()}} </p>
<p> State: <?php echo $state; ?> {{csrf_field()}} </p>
<p> District: <?php echo $dist; ?> {{csrf_field()}} </p>
<a href="">Edit</a>
</div>
</div>
</div>
</section>
</section>
@endsection