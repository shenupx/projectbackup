@extends('layouts.volheader')

<script>
function showdiv()
{
	document.getElementById('view').style.display='none';
	document.getElementById('edit').style.display='block';
}
</script>
@section('content')

<div class="container-fluid">
<div class="row">
<!-- Profile -->
@foreach($user as $use)
<div id="view" style="display:block;" class="outer-w3-agile col-xl mt-8" >

    <div class="profile-main-w3ls">
        <div class="profile-pic wthree">
            <img src="../../../storage/profile/{{$use->img}}" class="img-fluid" alt="Responsive image">
            <h3>{{$use->name}}</h3>
            <p>{{$use->email}}</p>
        </div>
        <div class="w3-message">
            <h5>About Me</h5>
            <p> Phone : {{$use->phone}} </p>
            <p> Date of Birth : {{$use->dob}} </p>
            <p> Gender : {{$use->gender}} </p>
            <p> District : {{$use->district_name}} </p> 
            <p> State : {{$use->state_name}} </p> 
            <p> Occupation : {{$use->occup}} </p> 
            <p> Name of Institute/Employer : {{$use->wname}} </p> 
            <p> Adhar Number : {{$use->adharno}} </p> 
            <div class="w3ls-touch">
           <button class="btn btn-primary" type="submit" onclick="return showdiv();">Edit</button>


            </div>
        </div>

    </div>
</div>
</div>
<!-- edit profile -->
<div id="edit" style="display:none;" >
<div class="container-fluid">
<div class="outer-w3-agile mt-2">
                    <h4 class="tittle-w3-agileits mb-8">Edit Your Profile</h4>
                    <form action="{{route('volupdate',$use->id)}}" enctype="multipart/form-data" method="post">
                    @method('PATCH')
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Name</label>
                                <input type="text" name="name" class="form-control" value="{{$use->name}}" id="name" placeholder="Name" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme">Email</label>
                                <input type="text" name="email" value="{{$use->email}}" class="form-control" value="{{$use->email}}" id="email" placeholder="Email" required="">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="phone">Phone</label>
                                <input type="text" name="phone" value="{{$use->phone}}" class="form-control" id="phone" placeholder="Phone Number" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="dob">Date of Birth</label>
                                <input type="date" name="dob" value="{{$use->dob}}" class="form-control" id="dob" placeholder="Date of Birth" required="">
                            </div>
                        </div>
                        <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="gender">Gender</label>
                                <select id="gender" name="gender" class="form-control">
                                    <option selected="">{{$use->gender}}</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="scheme"> Occupation </label>
                                <select id="occup" name="occup" class="form-control">
                                <option selected="">{{$use->occup}}</option>
                                <option value="student">Student</option>
                                <option value="employee">Employe</option>
									 <option value="other">Other</option>
                                </select>                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="wname">Institute/Employer Name</label>
                                <input type="text" name="wname" value="{{$use->wname}}" class="form-control" id="wname" placeholder="Institute/Employer Name" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="adhar">Aadhar Number</label>
                                <input type="text" name="adharno" value="{{$use->adharno}}" class="form-control" id="adharno" placeholder="Aadhaar Number" required="">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="wname">Profile Photo</label>
                                <input type="file" name="img" value="" class="form-control" id="img" placeholder="Upload Profile" required="">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="adhar">Aadhar Copy</label>
                                <input type="file" name="adimg" value="" class="form-control" id="adimg" placeholder="Aadhaar Image" required="">
                            </div>
                        </div>
                            <!-- <div class="form-group col-md-6">
                                <label for="state">State</label>
                                <input type="text" name="district" class="form-control" id="amount" placeholder="Award (Maximum Amount)" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="district">District</label>
                            <input type="text" class="form-control" name="detail" id="detail" placeholder="Details" required="">
                        </div> -->
                        <button class="btn btn-primary " type="reset">Reset</button>  <button class="btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
                </div>
                </div>
<!-- Edit Profile ends -->
@endforeach
<!--// Profiile -->
</div>
</div>

@endsection