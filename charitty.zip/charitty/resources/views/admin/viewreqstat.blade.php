@extends('layouts.adheader')
@section('content')


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Request Status</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col"></th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
    <tbody>
    
    @foreach($taskt as $reg)
    @if($reg->accept==0)
        <tr>
            <th scope="row">1</th>
            <td>{{$reg->name}}</td>
            <td>{{$reg->email}}</td>
            <td>{{$reg->phone}}</td> 
            <td><a href="" class="btn btn-warning" >Request Prograssing</a></td>
        </tr>
        @elseif($reg->accept==1)
        <tr>
            <th scope="row">1</th>
            <td>{{$reg->name}}</td>
            <td>{{$reg->email}}</td>
            <td>{{$reg->phone}}</td> 
            <td><a href="" class="btn btn-danger" >Request Denied</a></td>
        </tr>
        @else
        <tr>
            <th scope="row">1</th>
            <td>{{$reg->name}}</td>
            <td>{{$reg->email}}</td>
            <td>{{$reg->phone}}</td> 
            <td><a href="" class="btn btn-success" >Request Accepted</a></td>
        </tr>
        @endif
@endforeach
@endsection