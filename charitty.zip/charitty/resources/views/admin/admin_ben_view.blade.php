
@extends('layouts.adheader')
@section('content')
<section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt top">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                            <h1>view Oraganizations </h1>
                            
                            </div>
</div>
</div>
</section>
</section

@endsection