@extends('layouts.adheader')
@section('content')


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Assign Task</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col"></th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
    <tbody>
    
    @foreach($voluntee as $reg)
                       
        <tr>
            <th scope="row">1</th>
            <td>{{$reg->name}}</td>
            <td>{{$reg->email}}</td>
            <td>{{$reg->phone}}</td> 
            <td><a href="/reqtask?id={{$reg->id}}&donid={{$donid}}" class="btn btn-primary" >Request Task</a></td>
        </tr>
@endforeach
@endsection