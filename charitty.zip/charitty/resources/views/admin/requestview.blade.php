@extends('layouts.adheader')
@section('content')

<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Requested Item</th>
            <th scope="col">Quatity</th>
            <th scope="col">Details</th>
        </tr>
    </thead><?php $pos=0; ?>
    <tbody>
    @foreach($data as $use)
    @if($use->active==1)
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$use->name}}</td>
            <td>{{$use->item}}</td>
            <td>{{$use->quatity}}</td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal{{$use->request_id}}">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal{{$use->request_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{$use->name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Item Name : {{$use->item}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Quatititty : {{$use->quatity}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Speicific : {{$use->specific}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Within : {{$use->days}} </p>
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <a href="{{route('grantreq',$use->request_id)}}" class="btn btn-primary">Grant</a>
                </div>
            </div>
        </div>
        @elseif($use->active==0)
        <tr>
            <th scope="row">1</th>
            <td>{{$use->name}}</td>
            <td>{{$use->item}}</td>
            <td>{{$use->quatity}}</td>
<td><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal{{$use->request_id}}">Get Details</button></td>
            </tr>
                <div class="modal fade" id="exampleModal{{$use->request_id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{$use->name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Item Name : {{$use->item}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Quatititty : {{$use->quatity}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Speicific : {{$use->specific}} </p>
                    <p class="paragraph-agileits-w3layouts mt-3">
                    Within : {{$use->days}} </p>
                </div>
                <div class="modal-footer">
                <!-- <button type="button" class="btn btn-success">Verify</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <p class="btn btn-secondary"> Request Granted</p>
                </div>
            </div>
        </div>
        @endif
        @endforeach
    </tbody>
</table>

@endsection