@extends('layouts.adheader')
@section('content')

<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Scholarship Applications</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">SlNo</th>
            <th scope="col">Scheme Name</th>
            <th scope="col">Starting Date</th>
            <th scope="col">Ending Date</th>
            <th scope="col">View</th>
        </tr>
    </thead>
    <tbody><?php $pos=0; ?>
    
    @foreach($apps as $reg)
                       
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$reg->nscheme}}</td>
            <td>{{$reg->startdate}}</td>
            <td>{{$reg->enddate}}</td>
            <td><a href="{{route('viewapp',$reg->scheme_id)}} " class="btn btn-primary" >View Applications</a></td>
        </tr>
           
   
    </tbody>
    @endforeach
</table>
        
@endsection
