
@extends('layouts.adheader')
@section('content')
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Donations</h4>
<table class="table">
    <thead class="thead-dark">
        <tr><?php $pos=0; ?>
            <th scope="col">Sl.No</th>
            <th scope="col">Donor Name</th>
            <th scope="col">Item </th>
            <th scope="col">Quatity</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    @foreach($donation as $donation)           
        <tr>
            <th scope="row"><?php print ++$pos; ?></th>
            <td>{{$name}}</td>
            <td>{{$donation->item}}</td>
            <td>{{$donation->quantity}}</td>
            <td><a href="{{route('donationdetails',$donation->donation_id)}}" class="btn btn-dark" >Get Details</a></td>
        </tr>
        </tbody>
    @endforeach
</table>
@endsection