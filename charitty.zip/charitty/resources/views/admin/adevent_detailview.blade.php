@extends('layouts.adheader')
@section('content')

@foreach($newo as $evt)

<h3>{{$evt->event_name}}</h3>
<p>Event Type: {{$evt->type}}</p>
<p> Event Details: {{$evt->event_detail}}</p>

@if($evt->tye_id==1)
    <p>Target Amount: {{$evt->amount}}</p>
    <p>Target Date: {{$evt->tdate}}</p>
@else
    <p>No.of Volunteers Needed: {{$evt->no_person}}</p>
    <p>Event Date: {{$evt->edate}}</p>
@endif
<a href="/viewevent" class="btn btn-primary">Back</a>
<a href="{{route('eventedit',$evt->event_id)}}" class="btn btn-primary">Edit Event</a>
@endforeach
@endsection