@extends('layouts.adheader')
@section('content')
<script src="js/jquery.js"></script>
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
@foreach($newo as $newo)
    <h4 class="card-header">Edit Events </h4> <br>
    <form action="{{route('eventupdate',$newo->event_id)}}" method="post">
    @method('PATCH')
    @csrf
    
    <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Event Name</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" value="{{$newo->event_name}}" id="ename" name="ename" placeholder="Event Name" required="">
            </div>
        </div>    
        <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Event Type</label>
            <div class="col-sm-10">
            <select id="eventid" name="eventid" class="form-control">
                                <option value="{{$newo->tye_id}}"  selected>{{$newo->type}}</option>
									@isset($type)

									@foreach($type as $cc)
									<option value="{{$cc->tye_id}}">{{$cc->type}} </option>
									@endforeach
									@endisset
                                   <!-- <br> <option value="0">Others </option> -->
                                <</select>
                                </div>   </div>
        
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "1"){
                                        jQuery('html select').after("<label>Specify Target Amount</label><input type='text' name='target' value='{{$newo->amount}}' class='form-control' id='target' placeholder='Enter Target Amount'/> <label>Target Date</label><input type='date' value='{{$newo->tdate}}' class='form-control' id='tdate' name='tdate' placeholder='Target Date' required='' />");
                                        
                                    }
                                    else if(jQuery('select option:selected').val() == "2"){
                                        jQuery('html select').after("<label>Specify Number of Volunteers needed</label><input type='text' value='{{$newo->no_person}}' name='novol' class='form-control' id='novol' placeholder='Enter No.of Volunteers Needed' /> <label>Event Date</label><input type='date' value='{{$newo->edate}}' class='form-control' id='edate' name='edate' placeholder='Event Date' required='' />");
                                    }
                                })
                            });
                        </script>
         
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Event Details</label>
            <div class="col-sm-10">
                <textarea class="form-control" value="{{$newo->event_detail}}" id="eventdetail" name="eventdetail" placeholder="Enter Event Details" required=""></textarea>
            </div>
        </div>                 
        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Update Event</button>
            </div>
        </div>
        @endforeach
    </form>
</div>
@endsection