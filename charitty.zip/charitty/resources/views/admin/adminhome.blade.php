@extends('layouts.adheader')
@section('content')
Hellow I am admin :)

@endsection
