@extends('layouts.adheader')
<script src="js/jquery.validate.min.js"></script>
	<script src="js/passtrength.js"></script>
@section('content')
                       
<div class="outer-w3-agile col-xl mt-3">
    <h4 class="tittle-w3-agileits mb-4">Change Password</h4>
    <form action="/changepass" method="get" id="ad_changepass">
    @csrf
        <div class="form-group">
            <label for="curpass">Current Password </label>
            <input type="hidden" name="email" id="email" value="{{session()->get('email')}}" hidden >
            <input type="password" class="form-control" pattern=".{8,}" title="Eight or more characters"  name="curpass" id="curpass" placeholder="Current Password" required> 
        </div>
                <div class="form-group">
            <label for="newpass">New Password</label>
            <input type="password" class="form-control" pattern=".{8,}" title="Eight or more characters" id="newpass" name="newpass" placeholder="New Password" required> 
        </div>
        <div class="form-group">
            <label for="newpass">Confirm Password</label>
            <input type="password" class="form-control" pattern=".{8,}" title="Eight or more characters" id="conpass" name="conpass" placeholder="Confirm Password" required> 
        </div>
        <button class="btn btn-primary btn-lg btn-block " type="submit">Change Password</button>

    </form>
    <script>
jQuery().ready(function(){
    //alert("test");
    jQuery("#ad_changepass").validate({
			rules:{
                curpass:{
                    required:true,
                    minlength:8,
                    pwcheck: true,
                    remote:"/passcheck"
            }
        },
        messages:{
            curpass:{
                required:"Plese provide Your Password",
                minlength:"Your Password must be Atleast 8 charachters long",
                pwcheck:"Atleast 1 character and 1 digit",
                remote:"Password Doesnot Match"
                
            }
        }

			});
		});
	</script>
    
</div>
@endsection


