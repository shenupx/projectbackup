@extends('layouts.adheader')
@section('content')


<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4"> Events</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Event Name</th>
            <th scope="col">Event Type</th>
            <th scope="col">Details</th>
        </tr>
    </thead>
    <tbody>
    
    @foreach($event as $evt)
            <tr>
            <th scope="row">1</th>
            <td>{{$evt->event_name}}</td>
            <td>{{$evt->type}}</td>
            <td><a href="{{route('eventdetail',$evt->event_id)}}" class="btn btn-primary">Get Details</a></td>
        </tr>
    </tbody>
    @endforeach
</table>

@endsection
