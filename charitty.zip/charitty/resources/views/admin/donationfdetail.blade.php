@extends('layouts.adheader')
@section('content')

<div class="container-fluid">
<div class="row">
<!-- Profile -->
<div class="outer-w3-agile col-xl mt-3">
    <div class="profile-main-w3ls">
        <div class="profile-pic wthree">
        
            <h3>Donor Name : {{$name}}</h3> 
            @foreach($donation as $don)
            @if($don->item_id ==0)
            
        </div>
        <div class="w3-message">
            
            <p> Item Name :{{$don->specitem}}</p> 
            <p> Quatity : {{$don->quantity}}</p> 
            <p> Current Place : {{$don->district_name}}</p> 
            
            <div class="w3ls-touch">
            <a href="{{route('viewvolnteer',$don->donation_id)}}" class="btn btn-primary">Search Volunteer</a>
            @else
        <div class="w3-message">
            
            <p> Item Name :{{$don->item}}</p> 
            <p> Quatity : {{$don->quantity}}</p> 
            <p> Current Place : {{$don->district_name}} </p> 
            <div class="w3ls-touch">
            <!-- <input type="hidden" name="id" id="id" value="{{$don->donation_id}}" /> -->
            @if($don->deliverystat==0)
            <a href="{{route('viewvolnteer',$don->donation_id)}}" class="btn btn-primary">Search Volunteer</a>
            @else
            <button  class="btn btn-primary" disabled >Task Completed</button>
            @endif
            @endif
@endforeach
            </div>
        </div>

    </div>
</div>
<!--// Profiile -->
</div>
</div>

@endsection