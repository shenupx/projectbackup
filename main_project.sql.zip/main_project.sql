-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2019 at 07:03 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmembers`
--

CREATE TABLE `addmembers` (
  `mem_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adharno` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `yexpense` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spon_stat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `couse_id` bigint(20) UNSIGNED DEFAULT NULL,
  `iname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addmembers`
--

INSERT INTO `addmembers` (`mem_id`, `name`, `id`, `dob`, `gender`, `adharno`, `yexpense`, `spon_stat`, `image`, `couse_id`, `iname`, `created_at`, `updated_at`) VALUES
(1, 'Neethu', 3, '1999-12-05', 'female', '876567876545', '15000', '1', 'face2.jpg', 8, 'mount carmel higher secondary', '2019-04-29 10:45:14', '2019-04-29 10:45:14'),
(2, 'Anila', 3, '1998-03-12', 'female', '678987656765', '25000', '0', 'face6.jpg', 10, 'Unity', '2019-04-29 10:47:45', '2019-04-29 10:47:45'),
(3, 'Kiran', 3, '2004-01-01', 'male', '86286843282', '15000', '0', 'face27.jpg', 7, 'mount carmel higher secondary', '2019-04-29 10:48:42', '2019-04-29 10:48:42'),
(4, 'Job', 3, '1990-04-23', 'male', '86286843282', '150000', '0', '5.jpg', 12, 'ajce', '2019-04-29 10:52:01', '2019-04-29 10:52:01'),
(5, 'T D Kannan Nair', 6, '1893-04-23', 'male', '86286843282', '15000', '0', 'download.jpg', NULL, NULL, '2019-05-06 11:02:48', '2019-05-06 11:02:48');

-- --------------------------------------------------------

--
-- Table structure for table `addscholars`
--

CREATE TABLE `addscholars` (
  `scheme_id` bigint(20) UNSIGNED NOT NULL,
  `nscheme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `couse_id` bigint(20) UNSIGNED NOT NULL,
  `percent` bigint(20) NOT NULL,
  `nop` bigint(20) NOT NULL,
  `award` bigint(20) NOT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addscholars`
--

INSERT INTO `addscholars` (`scheme_id`, `nscheme`, `couse_id`, `percent`, `nop`, `award`, `detail`, `startdate`, `enddate`, `created_at`, `updated_at`) VALUES
(1, 'unarvu', 7, 85, 5, 20000, 'Scholarships are given based on the mark and Organization status', '2019-05-01', '2019-06-30', '2019-04-29 10:56:49', '2019-04-29 10:56:49'),
(2, 'Kanivu', 8, 90, 2, 50000, 'Scholarships are based on marks of the student and status of the organization. \r\none student at a time', '2019-04-01', '2019-05-31', '2019-04-29 10:58:31', '2019-04-29 10:58:31');

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `bank_id` bigint(20) UNSIGNED NOT NULL,
  `bankname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acholder` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acnumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` bigint(20) UNSIGNED DEFAULT NULL,
  `card_id` bigint(20) UNSIGNED DEFAULT NULL,
  `coname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cardnumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cvv` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mnth_id` bigint(20) UNSIGNED DEFAULT NULL,
  `yid` bigint(20) UNSIGNED DEFAULT NULL,
  `balance` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`bank_id`, `bankname`, `branchname`, `acholder`, `acnumber`, `ifsc`, `id`, `card_id`, `coname`, `cardnumber`, `cvv`, `mnth_id`, `yid`, `balance`, `created_at`, `updated_at`) VALUES
(1, 'Federal Bank', 'Sreekandapuram', 'Little flower organization', '12345678901', 'FDBN000767', 3, NULL, NULL, NULL, NULL, NULL, NULL, '50000', '2019-05-01 11:46:22', '2019-05-01 11:46:22'),
(2, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'neenu joseph', '1212121212', '121', 3, 8, '70000', NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'admin', '0000000000', '000', 1, 6, '29100', NULL, NULL),
(4, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-05-01 14:16:45', '2019-05-01 14:16:45'),
(5, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-05-01 14:16:45', '2019-05-01 14:16:45'),
(6, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-05-01 14:16:46', '2019-05-01 14:16:46'),
(7, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-05-01 14:16:49', '2019-05-01 14:16:49'),
(8, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-05-01 14:17:21', '2019-05-01 14:17:21');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `contact_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`contact_id`, `name`, `email`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Tina Jose', 'tinajose@mca.ajce.in', 'your site is good for charity', '2019-04-29 01:55:29', '2019-04-29 01:55:29');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `couse_id` bigint(20) UNSIGNED NOT NULL,
  `course` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`couse_id`, `course`) VALUES
(1, '1st '),
(2, '2nd'),
(3, '3rd'),
(4, '4th'),
(5, 'UP Section'),
(6, 'High school'),
(7, 'SSLC'),
(8, 'plus two'),
(9, 'Plus one'),
(10, 'Bsc'),
(11, 'ITI'),
(12, 'Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `days`
--

CREATE TABLE `days` (
  `day_id` bigint(20) UNSIGNED NOT NULL,
  `days` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `days`
--

INSERT INTO `days` (`day_id`, `days`) VALUES
(1, '0-3 Days'),
(2, '3-7 Days'),
(3, '2 Weeks'),
(4, '3 Weeks'),
(5, '1 Month'),
(6, '2 Month');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `donation_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `specitem` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` bigint(20) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `volid` bigint(20) DEFAULT NULL,
  `collectstat` int(11) DEFAULT '0',
  `deliverystat` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`donation_id`, `email`, `item_id`, `specitem`, `quantity`, `id`, `district_id`, `volid`, `collectstat`, `deliverystat`, `created_at`, `updated_at`) VALUES
(1, 'shencypxavier@gmail.com', 4, NULL, 35, 6, 1, 4, 1, 1, '2019-05-13 01:35:15', '2019-05-13 01:35:15'),
(2, 'shencypxavier@gmail.com', 2, NULL, 12, 3, 1, 4, 0, 0, '2019-05-17 04:44:48', '2019-05-17 04:44:48'),
(3, 'shencypxavier@gmail.com', 2, NULL, 12, 3, 1, NULL, 0, 0, '2019-05-17 04:45:29', '2019-05-17 04:45:29'),
(4, 'shencypxavier@gmail.com', 6, NULL, 32, 3, 1, 4, 0, 0, '2019-05-18 01:13:22', '2019-05-18 01:13:22');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `event_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tye_id` bigint(20) UNSIGNED NOT NULL,
  `event_detail` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_person` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edate` date DEFAULT NULL,
  `etime` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eplace` varchar(90) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `damount` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `active` int(50) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `tye_id`, `event_detail`, `amount`, `no_person`, `edate`, `etime`, `eplace`, `icon`, `damount`, `active`, `created_at`, `updated_at`) VALUES
(1, 'helping hand', 1, 'help cancer patients whose admitted at RCC Trivandrum', '20500', NULL, '2019-05-21', NULL, NULL, '2.jpg', '21100', 1, '2019-04-28 01:22:12', '2019-04-28 01:22:12'),
(2, 'Hand for sri lanka', 1, 'give a hand for sri lanka', '50000', NULL, '2019-05-23', NULL, NULL, 'w4.jpg', '50000', 1, '2019-04-28 07:14:55', '2019-04-28 07:14:55'),
(3, 'thirike', 2, 'Campaign for special school students', NULL, '25', '2019-05-01', NULL, NULL, 'n2.jpg', '1', 1, '2019-04-28 23:24:36', '2019-04-28 23:24:36'),
(4, 'Neera', 2, 'collecting pure drinking water and supply those who need', NULL, '50', '2019-06-01', '10 am', 'Palakkad town hall', '6.jpg', '0', 1, '2019-04-28 23:57:10', '2019-04-28 23:57:10'),
(5, 'Oruma', 2, 'Organ Donation Awareness Campaign', NULL, '50', '2019-06-28', '8.30 am', 'Amal Jyothi College of Engineering', 's6.jpg', '0', 1, '2019-04-29 00:01:48', '2019-04-29 00:01:48');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iqty` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item`, `iqty`, `created_at`, `updated_at`) VALUES
(1, 'Bag', '10', NULL, NULL),
(2, 'Bed', '12', NULL, NULL),
(3, 'Bedsheet', '50', NULL, NULL),
(4, 'Powder', '80', NULL, NULL),
(5, 'Bucket', '100', NULL, NULL),
(6, 'Bath Soap', '220', NULL, NULL),
(7, 'Mug', '556', '2019-04-29 22:44:07', '2019-04-29 22:44:07'),
(8, 'Cash', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_14_172905_create_logins_table', 1),
(4, '2019_03_18_151740_create_tbl_state_table', 1),
(5, '2019_03_18_152955_create_tbl_district_table', 1),
(6, '2019_03_20_143448_create_registers_table', 1),
(7, '2019_04_02_035355_create_addscholars_table', 1),
(8, '2019_04_09_153948_create_addmembers_table', 1),
(9, '2019_04_10_062208_create_items_table', 1),
(10, '2019_04_12_150110_create_requestneeds_table', 1),
(11, '2019_04_28_040928_create_events_table', 2),
(12, '2019_04_29_070017_create_contacts_table', 3),
(13, '2019_04_29_095740_create_reports_table', 4),
(14, '2019_05_01_164724_create_banks_table', 5),
(15, '2019_05_01_172832_create_payments_table', 6),
(16, '2019_05_06_180521_create_scholar_apps_table', 7),
(17, '2019_05_13_050510_create_donations_table', 8),
(18, '2019_05_14_044736_create_tbl_taskrequests_table', 9),
(19, '2019_05_16_150014_create_sponsorships_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pay_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` bigint(20) UNSIGNED DEFAULT NULL,
  `id` bigint(20) UNSIGNED DEFAULT NULL,
  `namount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`pay_id`, `email`, `event_id`, `id`, `namount`, `created_at`, `updated_at`) VALUES
(1, 'shensypxavier@gmail.com', 1, NULL, '100', '2019-05-01 14:40:24', '2019-05-01 14:40:24'),
(2, 'shencypxavier@gmail.com', 1, NULL, '200', '2019-05-02 01:40:44', '2019-05-02 01:40:44'),
(3, 'shencypxavier@gmail.com', 2, NULL, '300', '2019-05-04 01:16:55', '2019-05-04 01:16:55'),
(4, 'shencypxavier@gmail.com', 2, NULL, '200', '2019-05-04 01:17:43', '2019-05-04 01:17:43'),
(5, 'shencypxavier@gmail.com', 2, NULL, '100', '2019-05-04 01:57:15', '2019-05-04 01:57:15'),
(6, 'shencypxavier@gmail.com', 2, NULL, '100', '2019-05-04 02:04:13', '2019-05-04 02:04:13'),
(7, 'shencypxavier@gmail.com', 1, NULL, '100', '2019-05-06 23:29:02', '2019-05-06 23:29:02'),
(8, 'shencypxavier@gmail.com', 2, NULL, '1000', '2019-05-16 04:26:24', '2019-05-16 04:26:24'),
(9, 'shencypxavier@gmail.com', 2, NULL, '1000', '2019-05-16 04:30:42', '2019-05-16 04:30:42'),
(10, 'shencypxavier@gmail.com', 1, NULL, '21000', '2019-05-18 01:06:31', '2019-05-18 01:06:31');

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE `registers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdate` date DEFAULT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btype` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ocb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adharno` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occup` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adimg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `district_id`, `type`, `sdate`, `owner`, `btype`, `ocb`, `dob`, `gender`, `adharno`, `occup`, `wname`, `img`, `adimg`, `remember_token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'shensypxavier@mca.ajce.in', NULL, '$2y$10$Vcalc45qnq/g54SKma774uWinCsQyCiqoHgBK6L8oAgSJfJeBm5.6', '9072294059', 1, '0', NULL, NULL, NULL, NULL, '1898-12-04', 'female', '8628684328', 'employee', 'ajce', 'face5.jpg', 'aml.PNG', NULL, 1, '2019-04-26 23:10:13', '2019-05-13 10:34:55'),
(2, 'shensy xavier', 'shencypxavier@gmail.com', NULL, '$2y$10$DAPbQPsjMrfeVA3WSZXNm.4/DrW6cpjekQnej2qO3rGovKsfjK.mC', '9072294055', 3, '1', NULL, NULL, NULL, NULL, '1994-06-24', 'female', '8628684328', 'student', 'ajce', 'face2.jpg', 'ap.PNG', NULL, 1, '2019-04-26 23:15:29', '2019-04-27 04:11:32'),
(3, 'Little Flower Orphanage', 'shensypxavier@gmail.com', NULL, '$2y$10$UkAi1IqaGP.UeN4ALAP/xeNrDiT8KczYzvek7WTh0W.N2qdNwTVga', '9072294055', 3, '3', NULL, 'CMC Sisters', 'orphanage', NULL, NULL, NULL, NULL, NULL, NULL, 'images.jpeg', 's.PNG', NULL, 1, '2019-04-26 23:22:54', '2019-05-01 22:24:03'),
(4, 'anju benny', 'anjubenny@mca.ajce.in', NULL, '$2y$10$DHpbiyBbx9ea.8E5j.1FBu4vbWwuioiss29HvYii4ISU2wWVaVNeW', '9072294055', 1, '2', NULL, NULL, NULL, NULL, '1994-12-01', 'female', '6876835391', 'other', 'house wife', 'face6.jpg', '1.PNG', NULL, 1, '2019-04-26 23:28:01', '2019-05-01 20:59:09'),
(5, 'Minu', 'minuelizp@gmail.com', NULL, '$2y$10$Tp8wlOFKTBiXtOkDzDPZWugrplYUryMS8MHYMLBVNoXanINCKBz5q', '9072294055', 4, '2', NULL, NULL, NULL, NULL, '1996-02-07', 'female', '8628684328', 'student', 'ajce', '5.jpg', 'download.jfif', NULL, 1, '2019-05-02 00:24:59', '2019-05-02 01:43:15'),
(6, 'marymatha', 'marymatha@gmail.com', NULL, '$2y$10$AFlCZ3wouFacP4QZaNzoeeAdzLUeI5y0/IV2OIocqHcPge2I0Zl2u', '9874563212', 2, '3', NULL, 'jobin', 'oldhome', NULL, NULL, NULL, NULL, NULL, NULL, '2.jpg', 'fees.PNG', NULL, 1, '2019-05-02 00:27:55', '2019-05-06 23:35:06');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `reportid` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `details` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lmark` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`reportid`, `district_id`, `details`, `lmark`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 'i found a child in street \r\naddress given below\r\nnew bustand \r\nkannur , thavakkara', 'New Busstand', 'h13.jpg', '2019-04-29 05:21:22', '2019-04-29 05:21:22');

-- --------------------------------------------------------

--
-- Table structure for table `requestneeds`
--

CREATE TABLE `requestneeds` (
  `request_id` bigint(20) UNSIGNED NOT NULL,
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `specific` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quatity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_id` bigint(20) UNSIGNED NOT NULL,
  `active` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `requestneeds`
--

INSERT INTO `requestneeds` (`request_id`, `item_id`, `specific`, `quatity`, `day_id`, `active`, `id`, `email`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '12', 2, 1, 3, 'shensypxavier@mca.ajce.in', '2019-04-29 23:36:31', '2019-04-29 23:36:31'),
(2, 8, 'we need 10000 rupees for the medicalcheckup of members', '10000', 1, 1, 3, 'shencypxavier@gmail.com', '2019-04-29 23:41:59', '2019-04-29 23:41:59'),
(3, 8, 'we need 5000 rupees for maintenance', '5000', 1, 1, 3, '', '2019-04-29 23:46:19', '2019-04-29 23:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `scholar_apps`
--

CREATE TABLE `scholar_apps` (
  `sapp_id` bigint(20) UNSIGNED NOT NULL,
  `mem_id` bigint(20) UNSIGNED NOT NULL,
  `percent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme_id` bigint(20) UNSIGNED NOT NULL,
  `certificate` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scholar_apps`
--

INSERT INTO `scholar_apps` (`sapp_id`, `mem_id`, `percent`, `scheme_id`, `certificate`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, '78', 2, 'ap.PNG', 1, '2019-05-06 12:50:12', '2019-05-06 12:50:12'),
(2, 3, '88', 1, 'ap.PNG', 0, '2019-05-07 23:48:30', '2019-05-07 23:48:30'),
(3, 4, '85', 1, 'ap.PNG', 1, '2019-05-08 00:01:46', '2019-05-08 00:01:46');

-- --------------------------------------------------------

--
-- Table structure for table `sponsorships`
--

CREATE TABLE `sponsorships` (
  `spons_id` bigint(20) UNSIGNED NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `mem_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sponsorships`
--

INSERT INTO `sponsorships` (`spons_id`, `id`, `mem_id`, `created_at`, `updated_at`) VALUES
(2, 2, 1, '2019-05-17 01:28:23', '2019-05-17 01:28:23'),
(9, 2, 1, '2019-05-17 01:28:42', '2019-05-17 01:28:42'),
(10, 2, 1, '2019-05-17 01:29:46', '2019-05-17 01:29:46'),
(11, 2, 1, '2019-05-17 01:30:37', '2019-05-17 01:30:37'),
(12, 2, 1, '2019-05-17 01:32:12', '2019-05-17 01:32:12'),
(13, 2, 2, '2019-05-17 01:45:36', '2019-05-17 01:45:36'),
(14, 2, 2, '2019-05-17 01:46:09', '2019-05-17 01:46:09'),
(15, 2, 2, '2019-05-17 01:46:53', '2019-05-17 01:46:53'),
(16, 2, 3, '2019-05-17 02:05:28', '2019-05-17 02:05:28'),
(17, 2, 3, '2019-05-17 04:09:41', '2019-05-17 04:09:41'),
(18, 2, 3, '2019-05-17 04:10:21', '2019-05-17 04:10:21'),
(19, 2, 3, '2019-05-17 04:10:40', '2019-05-17 04:10:40'),
(20, 2, 3, '2019-05-17 04:11:13', '2019-05-17 04:11:13'),
(21, 2, 3, '2019-05-17 04:12:17', '2019-05-17 04:12:17'),
(22, 2, 5, '2019-05-17 04:27:37', '2019-05-17 04:27:37'),
(23, 2, 1, '2019-05-17 22:43:14', '2019-05-17 22:43:14'),
(24, 2, 1, '2019-05-17 22:44:26', '2019-05-17 22:44:26'),
(25, 2, 1, '2019-05-17 22:45:17', '2019-05-17 22:45:17'),
(26, 2, 1, '2019-05-17 22:46:51', '2019-05-17 22:46:51'),
(27, 2, 1, '2019-05-17 22:46:53', '2019-05-17 22:46:53'),
(28, 2, 1, '2019-05-17 22:47:04', '2019-05-17 22:47:04'),
(29, 2, 1, '2019-05-17 22:49:04', '2019-05-17 22:49:04'),
(30, 2, 2, '2019-05-17 22:56:35', '2019-05-17 22:56:35'),
(31, 2, 2, '2019-05-17 23:02:14', '2019-05-17 23:02:14'),
(32, 2, 2, '2019-05-17 23:03:40', '2019-05-17 23:03:40'),
(33, 2, 2, '2019-05-17 23:05:43', '2019-05-17 23:05:43'),
(34, 2, 2, '2019-05-17 23:06:41', '2019-05-17 23:06:41'),
(35, 2, 2, '2019-05-17 23:12:47', '2019-05-17 23:12:47'),
(36, 2, 3, '2019-05-17 23:16:01', '2019-05-17 23:16:01'),
(37, 2, 3, '2019-05-17 23:16:19', '2019-05-17 23:16:19'),
(38, 2, 3, '2019-05-17 23:16:54', '2019-05-17 23:16:54'),
(39, 2, 5, '2019-05-18 01:11:13', '2019-05-18 01:11:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cardtype`
--

CREATE TABLE `tbl_cardtype` (
  `card_id` bigint(20) UNSIGNED NOT NULL,
  `card` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cardtype`
--

INSERT INTO `tbl_cardtype` (`card_id`, `card`) VALUES
(1, 'Federal Bank Debit Card'),
(2, 'Federal Bank Credit Card'),
(3, 'Other Bank DebitCard'),
(4, 'Other Bank Credit Card');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `state_id` bigint(20) UNSIGNED NOT NULL,
  `district_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `state_id`, `district_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Kannur', NULL, NULL),
(2, 3, 'Bangaluru', NULL, NULL),
(3, 1, 'Wayanad', NULL, NULL),
(4, 2, 'Theni', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_month`
--

CREATE TABLE `tbl_month` (
  `mnth_id` bigint(20) UNSIGNED NOT NULL,
  `month` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_month`
--

INSERT INTO `tbl_month` (`mnth_id`, `month`) VALUES
(1, '01-January'),
(2, '02-February'),
(3, '03-March'),
(4, '04-April'),
(5, '05-May'),
(6, '06-June'),
(7, '07-July'),
(8, '08-August'),
(9, '09-September'),
(10, '10-October'),
(11, '11-November'),
(12, '12-December');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `state_id` bigint(20) UNSIGNED NOT NULL,
  `state_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_state`
--

INSERT INTO `tbl_state` (`state_id`, `state_name`, `created_at`, `updated_at`) VALUES
(1, 'Kerala', NULL, NULL),
(2, 'Tamil Nadu', NULL, NULL),
(3, 'Karnataka', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_taskrequests`
--

CREATE TABLE `tbl_taskrequests` (
  `req_id` bigint(20) UNSIGNED NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `donation_id` bigint(20) UNSIGNED NOT NULL,
  `reqstatus` bigint(20) DEFAULT NULL,
  `accept` int(20) DEFAULT '0',
  `onduty` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_taskrequests`
--

INSERT INTO `tbl_taskrequests` (`req_id`, `id`, `donation_id`, `reqstatus`, `accept`, `onduty`, `created_at`, `updated_at`) VALUES
(4, 4, 1, 0, 1, 4, '2019-05-14 00:14:16', '2019-05-14 00:14:16'),
(5, 4, 2, 0, 0, 0, '2019-05-17 23:28:53', '2019-05-17 23:28:53'),
(6, 4, 2, 0, 0, 0, '2019-05-17 23:30:34', '2019-05-17 23:30:34'),
(7, 4, 2, 0, 0, 0, '2019-05-17 23:30:50', '2019-05-17 23:30:50'),
(8, 4, 2, 0, 0, 0, '2019-05-17 23:31:04', '2019-05-17 23:31:04'),
(9, 4, 4, 0, 1, 4, '2019-05-18 01:21:01', '2019-05-18 01:21:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_year`
--

CREATE TABLE `tbl_year` (
  `yid` bigint(20) UNSIGNED NOT NULL,
  `year` int(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_year`
--

INSERT INTO `tbl_year` (`yid`, `year`) VALUES
(1, 2019),
(2, 2020),
(3, 2021),
(4, 2022),
(5, 2023),
(6, 2024),
(7, 2025),
(8, 2026),
(9, 2027),
(10, 2028);

-- --------------------------------------------------------

--
-- Table structure for table `type_events`
--

CREATE TABLE `type_events` (
  `tye_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_events`
--

INSERT INTO `type_events` (`tye_id`, `type`) VALUES
(1, 'fund rasing Program'),
(2, 'non fund raising program');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmembers`
--
ALTER TABLE `addmembers`
  ADD PRIMARY KEY (`mem_id`),
  ADD KEY `addmembers_couse_id_foreign` (`couse_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `addscholars`
--
ALTER TABLE `addscholars`
  ADD PRIMARY KEY (`scheme_id`),
  ADD KEY `addscholars_couse_id_foreign` (`couse_id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `banks_id_foreign` (`id`),
  ADD KEY `banks_card_id_foreign` (`card_id`),
  ADD KEY `banks_mnth_id_foreign` (`mnth_id`),
  ADD KEY `banks_yid_foreign` (`yid`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`couse_id`);

--
-- Indexes for table `days`
--
ALTER TABLE `days`
  ADD PRIMARY KEY (`day_id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donation_id`),
  ADD KEY `donations_item_id_foreign` (`item_id`),
  ADD KEY `donations_id_foreign` (`id`),
  ADD KEY `donations_district_id_foreign` (`district_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `events_tye_id_foreign` (`tye_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `payments_event_id_foreign` (`event_id`),
  ADD KEY `payments_id_foreign` (`id`);

--
-- Indexes for table `registers`
--
ALTER TABLE `registers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registers_email_unique` (`email`),
  ADD KEY `registers_district_id_foreign` (`district_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`reportid`),
  ADD KEY `reports_district_id_foreign` (`district_id`);

--
-- Indexes for table `requestneeds`
--
ALTER TABLE `requestneeds`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `requestneeds_item_id_foreign` (`item_id`),
  ADD KEY `requestneeds_day_id_foreign` (`day_id`),
  ADD KEY `requestneeds_id_foreign` (`id`);

--
-- Indexes for table `scholar_apps`
--
ALTER TABLE `scholar_apps`
  ADD PRIMARY KEY (`sapp_id`),
  ADD KEY `scholar_apps_mem_id_foreign` (`mem_id`),
  ADD KEY `scheme_id` (`scheme_id`);

--
-- Indexes for table `sponsorships`
--
ALTER TABLE `sponsorships`
  ADD PRIMARY KEY (`spons_id`),
  ADD KEY `sponsorships_id_foreign` (`id`),
  ADD KEY `sponsorships_mem_id_foreign` (`mem_id`);

--
-- Indexes for table `tbl_cardtype`
--
ALTER TABLE `tbl_cardtype`
  ADD PRIMARY KEY (`card_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`district_id`),
  ADD KEY `tbl_district_state_id_foreign` (`state_id`);

--
-- Indexes for table `tbl_month`
--
ALTER TABLE `tbl_month`
  ADD PRIMARY KEY (`mnth_id`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `tbl_taskrequests`
--
ALTER TABLE `tbl_taskrequests`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `tbl_taskrequests_id_foreign` (`id`),
  ADD KEY `tbl_taskrequests_donation_id_foreign` (`donation_id`);

--
-- Indexes for table `tbl_year`
--
ALTER TABLE `tbl_year`
  ADD PRIMARY KEY (`yid`);

--
-- Indexes for table `type_events`
--
ALTER TABLE `type_events`
  ADD PRIMARY KEY (`tye_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addmembers`
--
ALTER TABLE `addmembers`
  MODIFY `mem_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `addscholars`
--
ALTER TABLE `addscholars`
  MODIFY `scheme_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `bank_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `contact_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `couse_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `days`
--
ALTER TABLE `days`
  MODIFY `day_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `donation_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pay_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `registers`
--
ALTER TABLE `registers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `reportid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `requestneeds`
--
ALTER TABLE `requestneeds`
  MODIFY `request_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `scholar_apps`
--
ALTER TABLE `scholar_apps`
  MODIFY `sapp_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sponsorships`
--
ALTER TABLE `sponsorships`
  MODIFY `spons_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `tbl_cardtype`
--
ALTER TABLE `tbl_cardtype`
  MODIFY `card_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `district_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_month`
--
ALTER TABLE `tbl_month`
  MODIFY `mnth_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `state_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_taskrequests`
--
ALTER TABLE `tbl_taskrequests`
  MODIFY `req_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_year`
--
ALTER TABLE `tbl_year`
  MODIFY `yid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `type_events`
--
ALTER TABLE `type_events`
  MODIFY `tye_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `addmembers`
--
ALTER TABLE `addmembers`
  ADD CONSTRAINT `addmembers_couse_id_foreign` FOREIGN KEY (`couse_id`) REFERENCES `course` (`couse_id`),
  ADD CONSTRAINT `addmembers_ibfk_1` FOREIGN KEY (`id`) REFERENCES `registers` (`id`);

--
-- Constraints for table `addscholars`
--
ALTER TABLE `addscholars`
  ADD CONSTRAINT `addscholars_couse_id_foreign` FOREIGN KEY (`couse_id`) REFERENCES `course` (`couse_id`);

--
-- Constraints for table `banks`
--
ALTER TABLE `banks`
  ADD CONSTRAINT `banks_card_id_foreign` FOREIGN KEY (`card_id`) REFERENCES `tbl_cardtype` (`card_id`),
  ADD CONSTRAINT `banks_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `banks_mnth_id_foreign` FOREIGN KEY (`mnth_id`) REFERENCES `tbl_month` (`mnth_id`),
  ADD CONSTRAINT `banks_yid_foreign` FOREIGN KEY (`yid`) REFERENCES `tbl_year` (`yid`);

--
-- Constraints for table `donations`
--
ALTER TABLE `donations`
  ADD CONSTRAINT `donations_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `tbl_district` (`district_id`),
  ADD CONSTRAINT `donations_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `donations_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_tye_id_foreign` FOREIGN KEY (`tye_id`) REFERENCES `type_events` (`tye_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`),
  ADD CONSTRAINT `payments_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`);

--
-- Constraints for table `registers`
--
ALTER TABLE `registers`
  ADD CONSTRAINT `registers_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `tbl_district` (`district_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `tbl_district` (`district_id`);

--
-- Constraints for table `requestneeds`
--
ALTER TABLE `requestneeds`
  ADD CONSTRAINT `requestneeds_day_id_foreign` FOREIGN KEY (`day_id`) REFERENCES `days` (`day_id`),
  ADD CONSTRAINT `requestneeds_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `requestneeds_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`);

--
-- Constraints for table `scholar_apps`
--
ALTER TABLE `scholar_apps`
  ADD CONSTRAINT `scholar_apps_ibfk_1` FOREIGN KEY (`scheme_id`) REFERENCES `addscholars` (`scheme_id`),
  ADD CONSTRAINT `scholar_apps_mem_id_foreign` FOREIGN KEY (`mem_id`) REFERENCES `addmembers` (`mem_id`);

--
-- Constraints for table `sponsorships`
--
ALTER TABLE `sponsorships`
  ADD CONSTRAINT `sponsorships_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`),
  ADD CONSTRAINT `sponsorships_mem_id_foreign` FOREIGN KEY (`mem_id`) REFERENCES `addmembers` (`mem_id`);

--
-- Constraints for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD CONSTRAINT `tbl_district_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `tbl_state` (`state_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_taskrequests`
--
ALTER TABLE `tbl_taskrequests`
  ADD CONSTRAINT `tbl_taskrequests_donation_id_foreign` FOREIGN KEY (`donation_id`) REFERENCES `donations` (`donation_id`),
  ADD CONSTRAINT `tbl_taskrequests_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
