<?php

namespace App\Http\Controllers;

//use App\Login;
use App\Register;
use Auth;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //return view("helow world");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       // return view('authenti.login');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'email' => 'required',
            'password' => 'required',
         ]);
        $email = $request->get('email');
        session(['email' => $email]);
        $value = session('email');
        $password = $request->get('password');
        $a = Register::where('email', $email)->get();//where login is the model
       // return $a;
  
     foreach ($a as $object)
       {
           if($object->password == $password)
           {
                //return $object;
                 if($object->type == 0)
                 {
                    session_start();
                     return view('admin.adminhome')->with('sess',$value);
                  }
                  elseif($object->type == 1)
                  {
                    session_start();
                    $request->session()->put('email',$email); 
                     return view('donor.donhome')->with('sess',$value);
                  }
                  elseif($object->type == 2)
                  {
                    session_start();
                     return view('volunte.volhome')->with('sess',$value);
                  }
                  else
                  {
                    session_start();
                     return view('ben.benhome')->with('sess',$value);
                  }
           }
            else
            {
                return redirect('/log_in')->with('success','Invalid User name / Password !');
            }
         
        }
  
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(Login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(Login $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(Login $login)
    {
        //
    }
    public function logout(Request $request)
    {
    //   session_start();
    //   session_destroy();
    //    session()->flush();
         Auth::logout();
      return redirect('/log_in');
    }
}
