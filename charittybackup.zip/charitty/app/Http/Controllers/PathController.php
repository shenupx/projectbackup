<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PathController extends Controller
{
    public function register()
    {
        return view('authenti.registration');
    }
 public function log_in()
    {
         return view('authenti.login');
    }
    

}
