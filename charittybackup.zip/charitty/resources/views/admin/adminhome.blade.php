hai am admin
<a href="/logout" >logout</a>