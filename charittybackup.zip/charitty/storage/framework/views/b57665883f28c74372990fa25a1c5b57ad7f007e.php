<?php /* H:\main project\charitty\resources\views/admin/adminhome.blade.php */ ?>
hai am admin
<a href="/logout" >logout</a>