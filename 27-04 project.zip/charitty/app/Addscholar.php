<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addscholar extends Model
{
    protected $fillable = ['nscheme','couse_id','nop','award','detail'];
}
