<?php

namespace App\Http\Controllers;

use App\Requestneeds;
use Illuminate\Http\Request;
use DB;

class RequestneedsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $sess=session()->get('email');
        $user=DB::table('registers')
        ->select('registers.id')
        ->where('registers.email', '=', $sess)
        ->get();
        $requestneed=new requestneeds(['item_id'=>$request->input('item_id'),
        'specific'=>$request->input('specific'),
        'quatity'=>$request->input('quatity'),
        'day_id'=>$request->input('day_id'),
        'active'=>1,
        'rid'=>$user
        ]);       
        return $requestneed;
        // $requestneed->save();
        // return back()->with('success','Request Send Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function show(Requestneeds $requestneeds)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function edit(Requestneeds $requestneeds)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Requestneeds $requestneeds)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Requestneeds  $requestneeds
     * @return \Illuminate\Http\Response
     */
    public function destroy(Requestneeds $requestneeds)
    {
        //
    }
}
