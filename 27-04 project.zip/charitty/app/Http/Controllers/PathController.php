<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Register;
use DB;
use App\Addscholar;


class PathController extends Controller
{
    public function register()
    {
     $state=DB::table('tbl_state')->get();
     return view('authenti.registration',['data'=>$state]);
        //return view('authenti.registration');
    }
 public function log_in()
    {
         return view('authenti.login');
    } public function donprofile()
    {
         return view('donor.donprofile');
    }
//  public function adbenview()
// {
//      return view('admin.admin_ben_view');
// }
public function benprofile()
{
     return view('ben.benprofile');
}
public function benregi()
{
     return view('ben.benreg');
}
public function commonregi()
{
     //$data['rid']=$regid;
     return view('authenti.comreg');
}
public function beneditp()
{
     //$data['rid']=$regid;
     return view('ben.ben_editp');
}   
public function adminh()
{
     return view('admin.adminhome');
}
public function adprofile()
{
     return view('admin.adprofile');
}
public function volprofile()
{

     return view('volunte.volprofile');
}
public function adscholar()
{
     $course=DB::table('course')->get();
     return view('admin.adscholar',['course'=>$course]);
}
public function adchpass()
{
     return view('admin.adchangepass');
}
public function donchangepass()
{
     return view('donor.donchangepass');
}
public function volchangepass()
{
     return view('volunte.volchangepass');
}
public function orgchangepass()
{
     return view('ben.benchangepass');
}
public function benaddmem()
{
     $sess=session()->get('email');
     $a = Register::where('email', $sess)->get();
     $course=DB::table('course')->get();
     //$id=$a->id;
     foreach($a as $obje)
     {
          if($obje->btype=='orphanage')
          {
               
               return view('ben.benaddstud',['course'=>$course]);
          }
          else
          {
               return view('ben.benaddmem');
          }
     }
}
public function scholarview()
{
     $scholar=DB::table('addscholars')
     ->join('course','course.couse_id','=','addscholars.couse_id')
     ->select('addscholars.*','course.course')
     ->get();
     // $scholar=DB::table('addscholars')->get();
     return view('ben.scholarview',['data'=>$scholar]);
     
}
public function requestneeds()
{
     $item=DB::table('items')->get();
     $days=DB::table('days')->get();
     // return view('authenti.registration',['data'=>$state]);
     return view('ben.request',['item'=>$item,'data'=>$days]);
}
public function additem()
{
     $item=DB::table('items')->get();
     return view('admin.add_item',['item'=>$item]);
}
public function requestview()
{
     $reques=DB::table('requestneeds')
        ->join('items','requestneeds.item_id','=','items.item_id')
        ->join('days','requestneeds.day_id','=','days.day_id')
        ->select('requestneeds.*','items.item','days.days')
        ->where('requestneeds.active', '=',1)
        ->get();
        //return $reques;

       // return view('donor.donprofile',compact('user')); 
       // return view('donor.donprofile',['data'=>$user]); 
     return view('admin.requestview',['data'=>$reques]);
}
}//end class
