<?php

namespace App\Http\Controllers;

use App\Addscholar;
use Illuminate\Http\Request;
use DB;


class AddscholarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nschem=$request->input('nscheme');
        $newid=$request->input('couse_id');
        
        if($newid==0)
        {
            $course=$request->input('cou');
            $check=DB::table('course')->where(['course'=>$course])->get();
            if(count($check)==0)
            {
                $user=DB::insert('insert into course (course) values (?)', [$course]);
                $couse_id=DB::table('course')->max('couse_id');
            }
        }
        else
        {
            $couse_id=$newid;
        }
        // return $couse_id;
            $nop=$request->input('nop');
            $award=$request->input('award');
            $detail=$request->input('detail');
            $data=new Addscholar(['nscheme'=>$nschem,'couse_id'=>$couse_id,'nop'=>$nop,'award'=>$award,'detail'=>$detail]);
            $data->save();
            return redirect()->back() ->with('alert','Added the Scholarship Scheme successfully!');
        

        //$c_id=products::max('product_id');

        // $scholar=new Addscholar(['nscheme'=>$request->input('nscheme'),
        // 'couse_id'=>$request->input('couse_id'),
        // 'nop'=>$request->input('nop'),
        // 'award'=>$request->input('award'),
        // 'detail'=>$request->input('detail')
        // ]);
        // //return $scholar;
        // $scholar->save();
        // redirect('/adscholar');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Addscholar  $addscholar
     * @return \Illuminate\Http\Response
     */
    public function show(Addscholar $addscholar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Addscholar  $addscholar
     * @return \Illuminate\Http\Response
     */
    public function edit(Addscholar $addscholar)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Addscholar  $addscholar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Addscholar $addscholar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Addscholar  $addscholar
     * @return \Illuminate\Http\Response
     */
    public function destroy(Addscholar $addscholar)
    {
        //
    }
}
