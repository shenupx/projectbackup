<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Requestneeds extends Model
{
    protected $fillable = ['item_id','specific','quatity','day_id','active','id'];
}
