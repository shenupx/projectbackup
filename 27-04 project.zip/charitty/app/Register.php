<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    protected $fillable = ['name','email','password','phone','district_id','type','dob','owner','btype','ocb',
    'dob','gender','adharno','occup','wname','img','adimg',
    'remember_token','status'];
}
