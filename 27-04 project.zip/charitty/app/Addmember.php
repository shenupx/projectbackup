<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Addmember extends Model
{
    protected $fillable = ['name','dob','adharno','yexpense','spon_stat','image','couse_id','iname'];
}
