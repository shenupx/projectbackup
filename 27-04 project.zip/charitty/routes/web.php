<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
}); //for index page
Route::get('/about', function () {
    return view('about');
}); //for normal user about
Route::get('/gallery', function () {
    return view('gallery');
});//for normal user gallery
Route::get('/contact', function () {
    return view('contact');
}); //for normal user contact
Route::get('/news', function () {
    return view('news');
}); //for normal user news
Route::get('/validate', function () {
    return view('validations');
}) ;//for validate 
Route::get('/nregister','PathController@register');
//Route::get('/benregi','PathController@benregi');
//Route::get('/commonregi/{regid}','PathController@commonregi'); //redirect to register page

Route::get('/adbenview','RegisterController@regview'); 
Route::get('/benprofile','PathController@benprofile'); 
Route::get('/volprofile','PathController@volprofile'); 
Route::get('/log_in','PathController@log_in'); //redirect to login page

Route::resource('newreg','RegisterController'); //for register controller

Route::resource('logc','LoginController'); //for login controller
Route::get('/logout','\App\Http\Controllers\LoginController@logout');
Route::resource('commonreg','CommonregController');
Route::resource('benreg','BenregController');
Route::post('/city/ajax','DistrictController@cityajax');
Route::match(['GET','Post'],'check','RegisterController@checkEmail');
Route::match(['GET','Post'],'logincheck','RegisterController@checkLogin');
Route::match(['GET','Post'],'passcheck','RegisterController@checkpasswd');


Route::any('benedit{id}','RegisterController@edit')->name('benedit'); //ben edit page
Route::any('adminedit{id}','RegisterController@adminedit')->name('adminedit');

Route::any('approve{id}','RegisterController@checkstat')->name('approve');
Route::any('block{id}','RegisterController@blockuser')->name('block');
Route::get('/adorgview','RegisterController@adorgview');
Route::get('/advolview','RegisterController@advolview');
Route::get('/addonview','RegisterController@addonview');
// Route::any('myprofile{email}','RegisterController@adminprofile')->name('myprofile');
Route::get('/adprofile','PathController@adprofile');


//Route::get('beneditp','PathController@beneditp')

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
// Admin routes
Route::any('adminupdate{id}','RegisterController@adminupdate')->name('adminupdate');
Route::get('/adminhome','PathController@adminh');
Route::any('approve{id}','RegisterController@checkstat')->name('approve');
Route::any('block{id}','RegisterController@blockuser')->name('block');
Route::get('/adscholar','PathController@adscholar');
Route::get('/adchpass','PathController@adchpass');
Route::any('/changepass','RegisterController@changepass');
Route::any('/additem','PathController@additem');
Route::any('/additems','ItemController@store');
Route::any('/requestview','PathController@requestview');
//Route::any('chanpass','RegisterController@changepass')->name('changepass');
// Admin routes ends

// Donor Routes Starts
Route::get('/donhome','PathController@donh');
Route::get('/donprofile','RegisterController@profile');
Route::any('donupdate{id}','RegisterController@donproupdate')->name('donupdate');
Route::any('/passchange','RegisterController@donchangepass');
Route::any('/donchangepass','PathController@donchangepass');

// Route::get('/donprofile','PathController@donprofile');
// Donor Routes Ends

// Volunteer Routes Starts
Route::get('/volhome','PathController@volh'); 
Route::get('/volprofile','RegisterController@volprofile');
Route::any('volupdate{id}','RegisterController@volproupdate')->name('volupdate');
Route::any('/volchangepass','PathController@volchangepass');
Route::any('/volpass','RegisterController@volchangepass');

// Volunteer Routes Ends

// Organization Routes Starts 
Route::get('/benhome','PathController@benh');
Route::any('/orgchangepass','PathController@orgchangepass');
Route::get('/benprofile','RegisterController@benprofile');
Route::any('benproupdate{id}','RegisterController@benproupdate')->name('benupdate');
Route::any('/benpass','RegisterController@benpasschange');
Route::get('/benaddmem','PathController@benaddmem');
Route::any('/addmem','AddmemberController@store');
Route::any('/requestneeds','PathController@requestneeds');
Route::any('/sendreqt','RequestneedsController@store');
// Organization Routes Ends
// Scholarship Controller
Route::any('/scholar','AddscholarController@store');
Route::get('/scholarview','PathController@scholarview');
// Scholarship Controller Ends
