@extends('layouts.userheader')
<meta name="csrf-token" content="{{ csrf_token()}}">
<link href="regis/css/style.css" rel="stylesheet" type="text/css" media="all" />
<script>
function showdiv()
{
	var selectbox = document.getElementById('type');
	var inputus = selectbox.options[selectbox.selectedIndex].value;
	if (inputus == 1|| inputus == 2)
	{
		document.getElementById('comreg').style.display='block';
		document.getElementById('benfi').style.display='none';
	}
	else
	{
		document.getElementById('benfi').style.display='block';
		document.getElementById('comreg').style.display='none';
	}
	return false;
}
</script>
   @section('content')

	<!-- Main Content -->
	<div class="main">
		<div class="main-w3l">
			<!-- <h3 class="logo-w3">Register Now</h3> -->
			<div class="w3layouts-main">
				<h2><span>Register now</span></h2>
					<form  action="{{route('newreg.store')}}" method="post" enctype="multipart/form-data" id="reg_form">
						@csrf
						<label for="name" style="align:left;"> Name </label>
						<input placeholder="Full Name" name="name" id="name" type="text" required="">
						<label for="email"> Email </label>
						<input placeholder="Email" name="email" id="email" type="text" required="">
						<label for="password"> Password </label>
						<input placeholder="Password" name="password" type="password"  id="myPassword" required="">
						<label for="phone"> Phone Number </label>
						<input  name="status" type="hidden" value="0"  id="status">
						<input placeholder="Phone Number" name="phone" id="phone" type="text" required="">
						<label for="state"> State </label>
						<select name="state" id="state">
									<option value="0" disabled selected>Select your State</option>
									@isset($data)

									@foreach($data as $state)
									<option value="{{$state->state_id}}">{{$state->state_name}} </option>
									@endforeach
									@endisset
						</select> </br>  </br>
						<label for="district"> District </label>
						<select name="district" id="district">
									<option value="0" disabled selected>Select your District</option>
						</select> </br>  </br>
						<label for="type"> Select User Type </label>
						<select name="type" id="type" onchange="return showdiv();">
									<option value="sel"  disabled selected>Select your type</option>
                            <option value="1">Donor</option>
                            <option value="2">Volunteer</option>
									 <option value="3">Organization</option>
								</select> </br>  </br>

								<!-- benfi started -->
								<div id="benfi" style="display:none;" >
								<label for="sdate"> Date of Starting </label>
						<input placeholder="Starting Date" name="sdate" id="sdate" type="date" >
						<label for="owner"> Owner Name </label>
						<input placeholder="Owner Name" name="owner" id="owner" type="text" >
						<label for="btype"> Select Your Organization Type</label>
                        <select name="btype" id="btype">
									<option value="sel"  disabled selected>Select Type</option>
                            <option value="orphanage">Orphanage</option>
                            <option value="oldhome">Oldage Home</option>
								</select> </br>  </br>
								<label for="place"> Enter your Place </label>
								<input placeholder="Place" name="place" id="place" type="text" >
								<label for="cero"> OCB Certificate Number</label>
								<input placeholder="Place" name="ocb" id="ocb" type="text" >
						
								</div>	
								<!-- benfi ended -->

								<!-- common registration start -->
								<div id="comreg" style="display:none;" >
								<label for="dob"> Date of Birth </label>
								<input placeholder="Date of Birth" name="dob" id="dob" type="date" >
								<label for="gender"> Select Your Gender </label>
								<select name="gender" id="gender">
									<option value="sel"  disabled selected>Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
									 <option value="other">Other</option>
								</select>
								<label for="aadhar"> Aadhar Number </label>
                        <input placeholder="Aadhar Number" name="adharno" id="adharno"   type="number" >
                        <label for="occup"> Your Occupation </label>
                        <select name="occup" id="occup">
									<option value="sel"  disabled selected>Select Occupation</option>
                            <option value="student">Student</option>
                            <option value="employee">Employe</option>
									 <option value="other">Other</option>
								</select> </br>  </br>
								<label for="wname"> Employer/Institute Name </label>
                        <input placeholder="Institute/Employer Name" name="wname" id="wname" type="text" >
								<label for="img"> Upload Your Image  </label>
								<input placeholder="Photo" name="img" id="img" type="file">
								<label for="adimg"> Upload Your Aadhar Copy for verification </label>
								<input placeholder="Aadhar Copy" name="adimg" id="adimg" type="file" >
						</div>
						<!-- common registration ends -->
						<input type="submit" value="Register" name="submit">
					</form>
					<script src="js/validate/jquery.js"></script>
					<script src="js/ajax.js"></script>
   
	<script src="js/jquery.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/passtrength.js"></script>

			</div>

   @endsection