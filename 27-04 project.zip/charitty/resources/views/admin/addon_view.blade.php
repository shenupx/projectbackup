
@extends('layouts.adheader')
@section('content')

<section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Donor</h3>
          	
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">                       
                          <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
                	  	  <hr>
                              <thead>
                              <tr>
                                  <th><i class="fa fa-bullhorn"></i> Name</th>
                                  <th class="hidden-phone"><i class="fa fa-question-circle"></i> Email</th>
                                  <th><i class="fa fa-bookmark"></i> Phone</th>
                                  <th><i class="fa fa-edit"></i> Status</th>
                                  <th></th>
                              </tr>
                              </thead>
                              <tbody>
                              @foreach($regdetails as $reg)
                              @if($reg->status==1 && $reg->type==1)
                              <tr>
                                  <td><a href="basic_table.html#">{{$reg->name}}</a></td>
                                  <td class="hidden-phone">{{$reg->email}}</td>
                                  <td>{{$reg->phone}}</td>
                                  <td><a href="{{route('block',$reg->id)}}"><span class="btn btn-danger">Block</span></a></td>
                                 @endif                               </tr>
                              </tbody>
                              @endforeach
                          </table>
                          
                      <!-- <form class="form-horizontal style-form" method="get">
                     
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control">
                              </div>
                          </div>
                          </form> </div></div></div> -->
                          </section>
                          </section>
<!-- <section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt top">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                            <h1>view Oraganizations </h1>

                            </div> -->
</div>
</div>
</section>
</section

@endsection