@extends('layouts.adheader')
@section('content')
<script src="js/jquery.js"></script>
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="card-header">Add Item </h4> <br>
    <form action="/additems" method="post">
    @csrf
        <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Item Name</label>
            <div class="col-sm-10">
            <select id="item" name="item" class="form-control">
                                <option value="#" disabled selected>Select item</option>
									@isset($item)

									@foreach($item as $cc)
									<option value="{{$cc->item_id}}">{{$cc->item}} </option>
									@endforeach
									@endisset
                                   <br> <option value="0">Others </option>
                                <</select>
                                </div>   </div>
        
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Enter new Item</label><input type='text' name='nite' class='form-control' id='nite' placeholder='Enter item Name' />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>
         
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="iqty" name="iqty" placeholder="No.of Items" required="">
            </div>
        </div>          
                               
        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Add Item</button>
            </div>
        </div>
    </form>
</div>
@endsection