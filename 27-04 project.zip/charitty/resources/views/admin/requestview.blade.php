@extends('layouts.adheader')
@section('content')
@foreach($data as $use)
<div class="outer-w3-agile mt-3">
<h4 class="tittle-w3-agileits mb-4">Requests</h4>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Sl.No</th>
            <th scope="col">Organization Name</th>
            <th scope="col">Requested Item</th>
            <th scope="col">Quatity</th>
            <th scope="col">Time</th>
            <th scope="col">Status</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>{{$use->name}</td>
            <td>@mdo</td>
        </tr>
    </tbody>
</table>
@endforeach
@endsection