@extends('layouts.adheader')
@section('content')
<section id="main-content">
          <section class="wrapper">
              	
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">
                  <div class="form-panel">
                  	  <h4 class="mb"><i class="fa fa-angle-right"></i> Edit Profile </h4>
                      <form class="form-horizontal style-form" method="get" action="{{route('adminupdate',$regist->id)}}">
                      @method('PATCH')
                        @csrf
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Name</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" value="{{$regist->name}}" name="name" >
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Email</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" value="{{$regist->email}}" name="email" >
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Phone</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" value="{{$regist->phone}}" name="phone" >
                              </div>
                          </div>
                          <input type="submit" class="btn btn-theme03" name="submit" value="UPDATE">
                        



</form>
</div>
</div>
</div>
</section>
</section>
@endsection