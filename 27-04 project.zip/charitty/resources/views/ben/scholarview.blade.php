@extends('layouts.benheader')
@section('content')
@isset($data)

<h4 class="tittle-w3-agileits mb-4">Available Scholarships</h4>

@foreach($data as $dd)

<div class="outer-w3-agile mt-6"> 
       <div class="card-header">
            <h4 class="py-md-6 py-xl-1 py-4">{{$dd->nscheme}}</h4>
        </div>
        <div class="card-body">
            <h5 class="card-title pricing-card-title">
                <span class="align-top">Rs</span>{{$dd->award}}
                <small class="text-muted">/ Year</small>
            </h5>
            
           
        </div>
    </div>
    
      @endforeach
    @endisset


   
@endsection