@extends('layouts.benheader')
	@section('content')
	<section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt">
			  		<div class="col-lg-12">
                      <div class="content-panel">
	<!-- <div class="row mt">
	<div class="col-lg-12">
	<div class="form-panel">
	<h4 class="mb"><i class="fa fa-angle-right"></i> Form Elements</h4>
	<form class="form-horizontal style-form" method="get">
		<div class="form-group">
		<label class="col-sm-2 col-sm-2 control-label">Default</label>
		<div class="col-sm-10">
		<input type="name" class="form-control">
		</div>
		</div> -->
	<form method="post" action="{{route('newreg.update',$register->id)}}">
  @method('PATCH')
  @csrf
  <label for="name">Name:</label>
  <input type="text" name="name" value="{{$register->name}}" /><br/>
  <label for="price">Email:</label>
  <input type="text" name="email" value="{{$register->email}}" /><br/>
  <label for="price">Password:</label>
  <input type="text" name="body" disabled value="{{$register->password}}" /><br/>
  <button type="submit"> UPDATE </button>
</form>
</div>
</div>
</div>
</section>
</section>
@endsection