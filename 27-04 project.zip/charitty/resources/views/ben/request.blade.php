@extends('layouts.benheader')
@section('content')
<script src="js/jquery.js"></script>

                        <div class="outer-w3-agile col-xl mt-3 mr-xl-3">
                            <h4 class="card-header">Request </h4> <br>
                            <form action="/sendreqt" method="post">
                            @csrf
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">I Need</label>
                                    <div class="col-sm-10">
                                    <select id="item_id" name="item_id" class="form-control">
                                <option value="#" disabled selected>Select item</option>
									@isset($item)

									@foreach($item as $cc)
									<option value="{{$cc->item_id}}">{{$cc->item}} </option>
									@endforeach
									@endisset
                                   <br> <option value="0">Others </option>
                                <</select>
        
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Specify Your Needs</label><input type='text' name='specific' class='form-control' id='specific' placeholder='Specify Your Need' />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="quatity" name="quatity" placeholder="Enter How Much You Want" required="">
                                    </div>
                                </div>          
                                <div class="form-group row">
                                    <label for="days" class="col-sm-2 col-form-label">Within</label>
                                    <div class="col-sm-10">
                                    <select id="day_id" name="day_id" class="form-control">
                                <option value="#" disabled selected>Select Days</option>
									@isset($data)

									@foreach($data as $dd)
									<option value="{{$dd->day_id}}">{{$dd->days}} </option>
									@endforeach
									@endisset
                                <</select>          
                                             </div>
                                </div>                        
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">SEND</button>
                                    </div>
                                </div>
                            </form>
                        </div>

@endsection