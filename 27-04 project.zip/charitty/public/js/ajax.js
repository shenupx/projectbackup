$(document).ready(function () {
    $('#state').on('change', function () {
        //alert("error");
        var distID = $(this).val();
        if (distID) {
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                method:'post',
                url: '/city/ajax',
                type: "GET",
                data: {
                    'distID': distID
                },
                success: function (data) {
                    console.log(data);

                    $('select[name="district"]').empty();
                    $('select[name="district"]').append('<option value="0">-- Select District --</option>');
                    $.each(data, function (key, value) {
                        console.log(value.district_name);
                        
                        $('select[name="district"]').append('<option value="' + value.district_id + '">' + value.district_name + '</option>');
                    });


                }
            });
        } else {
            $('select[name="city"]').empty();
        }
    });
});