<?php /* H:\main project\charitty\resources\views/ben/ben_editp.blade.php */ ?>
	<?php $__env->startSection('content'); ?>
	<section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt">
			  		<div class="col-lg-12">
                      <div class="content-panel">
	<!-- <div class="row mt">
	<div class="col-lg-12">
	<div class="form-panel">
	<h4 class="mb"><i class="fa fa-angle-right"></i> Form Elements</h4>
	<form class="form-horizontal style-form" method="get">
		<div class="form-group">
		<label class="col-sm-2 col-sm-2 control-label">Default</label>
		<div class="col-sm-10">
		<input type="name" class="form-control">
		</div>
		</div> -->
	<form method="post" action="<?php echo e(route('newreg.update',$register->id)); ?>">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <label for="name">Name:</label>
  <input type="text" name="name" value="<?php echo e($register->name); ?>" /><br/>
  <label for="price">Email:</label>
  <input type="text" name="email" value="<?php echo e($register->email); ?>" /><br/>
  <label for="price">Password:</label>
  <input type="text" name="body" disabled value="<?php echo e($register->password); ?>" /><br/>
  <button type="submit"> UPDATE </button>
</form>
</div>
</div>
</div>
</section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>