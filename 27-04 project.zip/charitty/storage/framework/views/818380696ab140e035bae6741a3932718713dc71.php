<?php /* H:\main project\charitty\resources\views/admin/adchangepass.blade.php */ ?>
<script src="js/jquery.validate.min.js"></script>
	<script src="js/passtrength.js"></script>
<?php $__env->startSection('content'); ?>
                       
<div class="outer-w3-agile col-xl mt-3">
    <h4 class="tittle-w3-agileits mb-4">Change Password</h4>
    <form action="/changepass" method="get" id="ad_changepass">
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="curpass">Current Password </label>
            <input type="hidden" name="email" id="email" value="<?php echo e(session()->get('email')); ?>" hidden >
            <input type="password" class="form-control" name="curpass" id="curpass" placeholder="Current Password" required=""> 
        </div>
                <div class="form-group">
            <label for="newpass">New Password</label>
            <input type="password" class="form-control" id="newpass" name="newpass" placeholder="New Password" required=""> 
        </div>
        <div class="form-group">
            <label for="newpass">Confirm Password</label>
            <input type="password" class="form-control" id="conpass" name="conpass" placeholder="Confirm Password" required=""> 
        </div>
        <button class="btn btn-primary btn-lg btn-block " type="submit">Change Password</button>

    </form>
    <script>
jQuery().ready(function(){
    //alert("test");
    jQuery("#ad_changepass").validate({
			rules:{
                curpass:{
                    required:true,
                    minlength:8,
                    pwcheck: true,
                    remote:"/passcheck"
            }
        },
        messages:{
            curpass:{
                required:"Plese provide Your Password",
                minlength:"Your Password must be Atleast 8 charachters long",
                pwcheck:"Atleast 1 character and 1 digit",
                remote:"Password Doesnot Match"
                
            }
        }

			});
		});
	</script>
    
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>