<?php /* H:\main project\charitty\resources\views/ben/scholarview.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<?php if(isset($data)): ?>

<h4 class="tittle-w3-agileits mb-4">Available Scholarships</h4>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="outer-w3-agile mt-6"> 
       <div class="card-header">
            <h4 class="py-md-6 py-xl-1 py-4"><?php echo e($dd->nscheme); ?></h4>
        </div>
        <div class="card-body">
            <h5 class="card-title pricing-card-title">
                <span class="align-top">Rs</span><?php echo e($dd->award); ?>

                <small class="text-muted">/ Year</small>
            </h5>
            
           
        </div>
    </div>
    
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>