<?php /* H:\main project\charitty\resources\views/ben/request.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<script src="js/jquery.js"></script>

                        <div class="outer-w3-agile col-xl mt-3 mr-xl-3">
                            <h4 class="card-header">Request </h4> <br>
                            <form action="/sendreqt" method="post">
                            <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">I Need</label>
                                    <div class="col-sm-10">
                                    <select id="item_id" name="item_id" class="form-control">
                                <option value="#" disabled selected>Select item</option>
									<?php if(isset($item)): ?>

									<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($cc->item_id); ?>"><?php echo e($cc->item); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                   <br> <option value="0">Others </option>
                                <</select>
        
                                
                                <script>
                         
                            jQuery(document).ready(function(){
                                jQuery('select').change(function(){
                                    if(jQuery('select option:selected').val() == "0"){
                                        jQuery('html select').after("<label>Specify Your Needs</label><input type='text' name='specific' class='form-control' id='specific' placeholder='Specify Your Need' />");
                                        
                                    }
                                    else{
                                        //jQuery('label').remove();
                                    }
                                })
                            });
                        </script>                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputPassword3" class="col-sm-2 col-form-label">Quantity</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="quatity" name="quatity" placeholder="Enter How Much You Want" required="">
                                    </div>
                                </div>          
                                <div class="form-group row">
                                    <label for="days" class="col-sm-2 col-form-label">Within</label>
                                    <div class="col-sm-10">
                                    <select id="day_id" name="day_id" class="form-control">
                                <option value="#" disabled selected>Select Days</option>
									<?php if(isset($data)): ?>

									<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($dd->day_id); ?>"><?php echo e($dd->days); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
                                <</select>          
                                             </div>
                                </div>                        
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">SEND</button>
                                    </div>
                                </div>
                            </form>
                        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.benheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>