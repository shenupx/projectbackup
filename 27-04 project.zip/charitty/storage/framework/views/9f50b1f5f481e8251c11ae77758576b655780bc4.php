<?php /* H:\main project\charitty\resources\views/admin/adprofile.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<section id="main-content">
          <section class="wrapper">
<?php
use App\Register;
$sess=session()->get('email');
$a=Register::where('email',$sess)->get();

foreach($a as $object)
{
    $id=$object->id;
    $name=$object->name;
    $email=$object->email;
    $phone=$object->phone;
    $dist=$object->dist;
  
   //echo "<p>" .+ echo $name; .+"{{csrf_field(0}} </p>"; 
}

?>	
                    

        <div class="container-fluid">
<div class="row">
<!-- Profile -->
<div class="outer-w3-agile col-xl mt-3">
    <div class="profile-main-w3ls">
        <div class="profile-pic wthree">
            <img src="admin/images/profile.jpg" class="img-fluid" alt="Responsive image">
            <h3><?php echo $name;?></h3> <?php echo e(csrf_field()); ?>

            <p>Admin</p>
        </div>
        <div class="w3-message">
            <h5>About Me</h5>
            <p> Email :<?php echo $email;?> </p> <?php echo e(csrf_field()); ?>

            <p> Phone :<?php echo $phone;?> </p> <?php echo e(csrf_field()); ?>

            <div class="w3ls-touch">
            <a href="<?php echo e(route('adminedit',$id)); ?>" class="btn btn-primary">EDIT</a>

            </div>
        </div>

    </div>
</div>
<!--// Profiile -->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>