<?php /* H:\main project\charitty\resources\views/admin/adorg_view.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Organizations</h3>
          	
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">                       
                          <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
                	  	  <hr>
                              <thead>
                              <tr>
                                  <th><i class="fa fa-bullhorn"></i> Name</th>
                                  <th class="hidden-phone"><i class="fa fa-question-circle"></i> Email</th>
                                  <th><i class="fa fa-bookmark"></i> Phone</th>
                                  <th><i class=" fa fa-edit"></i> Status</th>
                                  <th></th>
                              </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $regdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($reg->status==1 && $reg->type==3): ?>
                              <tr>
                                  <td><a href="basic_table.html#"><?php echo e($reg->name); ?></a></td>
                                  <td class="hidden-phone"><?php echo e($reg->email); ?></td>
                                  <td><?php echo e($reg->phone); ?></td>
                                  <td><a href="<?php echo e(route('block',$reg->id)); ?>"><span class="btn btn-danger">Block</span></a></td>
                                 <?php endif; ?>                               </tr>
                              </tbody>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                          
                      <!-- <form class="form-horizontal style-form" method="get">
                     
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control">
                              </div>
                          </div>
                          </form> </div></div></div> -->
                          </section>
                          </section>
<!-- <section id="main-content">
          <section class="wrapper">
    		  		<div class="row mt top">
			  		<div class="col-lg-12">
                      <div class="content-panel">
                            <h1>view Oraganizations </h1>

                            </div> -->
</div>
</div>
</section>
</section

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>