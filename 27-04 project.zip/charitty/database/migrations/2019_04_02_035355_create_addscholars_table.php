<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddscholarsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addscholars', function (Blueprint $table) {
            $table->bigIncrements('scheme_id');
            $table->string('nscheme');
            $table->biginteger('couse_id')->unsigned();
            $table->foreign('couse_id')->references('couse_id')->on('course');
            $table->biginteger('nop');
            $table->biginteger('award');
            $table->string('detail');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addscholars');
    }
}
