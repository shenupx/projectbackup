<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRequestneedsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('requestneeds', function (Blueprint $table) {
            $table->bigIncrements('request_id');
            $table->biginteger('item_id')->unsigned();
            $table->foreign('item_id')->references('item_id')->on('items');
            $table->string('specific')->nullable();
            $table->string('quatity');
            $table->biginteger('day_id')->unsigned();
            $table->foreign('day_id')->references('day_id')->on('days');
            $table->integer('active');
            $table->biginteger('id')->unsigned();
            $table->foreign('id')->references('id')->on('registers');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('requestneeds');
    }
}
